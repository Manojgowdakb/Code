// Enterprise HFS 3.2.1 Security Plugin Suite
// Plugin: Folder Password Protection  v2.0
// File: plugins/folder-password/plugin.js
//
// CHANGELOG v2.0:
//   - verifyPassword hoisted to prevent ReferenceError on startup
//   - setPassword now requires admin/logged-in account
//   - removePassword now server-side password-verified (new: verifyAndRemovePassword)
//   - Promise-level concurrency guard on DB reads (prevents DB saturation under 1000+ users)
//   - lockedPathsCache built via safe iteration (no asObject dependency)
//   - Session cookie: path=/ and sameSite=strict always set
//   - Auto-cleanup: removing a password invalidates all authorized sessions for that path

const crypto = require('crypto');

// ─────────────────────────────────────────────────────────────────────────────
//  DYNAMIC ADMIN DETECTION
//  Reads accounts from HFS config to find any account with admin:true.
//  This replaces all hardcoded `username === 'admin'` checks so the plugin
//  works correctly regardless of what the admin account is named.
// ─────────────────────────────────────────────────────────────────────────────
let _pluginApi = null;       // set inside exports.init
let _adminNamesCache = null; // Set<string> of lowercase admin usernames
let _adminCacheExpiry = 0;  // timestamp when cache expires

function isAdminUser(username) {
    if (!username || !_pluginApi) return false;
    const now = Date.now();
    if (!_adminNamesCache || now > _adminCacheExpiry) {
        _adminNamesCache = new Set();
        try {
            const accounts = _pluginApi.getHfsConfig('accounts') || {};
            for (const [name, acc] of Object.entries(accounts)) {
                if (acc && acc.admin === true) {
                    _adminNamesCache.add(name.toLowerCase());
                }
            }
        } catch (_) {}
        _adminCacheExpiry = now + 30000; // refresh every 30 seconds
    }
    return _adminNamesCache.has(username.toLowerCase());
}

exports.description = "Secures unlimited folders with individual passwords. Prevents unauthorized access, listing, downloads, uploads, and deletions. v2.0 enterprise hardened.";
exports.version = 2.0;
exports.apiRequired = 8.0;

// ─────────────────────────────────────────────────────────────────────────────
//  IN-MEMORY SESSION STORE
//  Format: { [sessionId]: { [normalizedVfsPath]: lastAccessTimestamp } }
// ─────────────────────────────────────────────────────────────────────────────
const authorizedSessions = {};

// Sliding session inactivity window: 12 hours
const SESSION_TIMEOUT = 12 * 60 * 60 * 1000;

// ─────────────────────────────────────────────────────────────────────────────
//  CRYPTO HELPERS  (hoisted — must be defined before any usage)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * HMAC-SHA256 salted hash of a password.
 * @param {string} password  Cleartext password
 * @param {string} salt      Hex salt string
 * @returns {string}         Hex digest
 */
function hashPassword(password, salt) {
    const hmac = crypto.createHmac('sha256', salt);
    hmac.update(password);
    return hmac.digest('hex');
}

/**
 * Timing-safe password verification.
 * @param {string} password    Cleartext to test
 * @param {string} salt        Stored salt
 * @param {string} storedHash  Stored hash
 * @returns {boolean}
 */
function verifyPassword(password, salt, storedHash) {
    const candidate = hashPassword(password, salt);
    // Use timingSafeEqual to prevent timing-based attacks
    try {
        return crypto.timingSafeEqual(
            Buffer.from(candidate, 'hex'),
            Buffer.from(storedHash,  'hex')
        );
    } catch (_) {
        return false;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  PATH NORMALISATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Normalises any VFS path to a canonical lowercase form with leading + trailing slashes.
 * Handles URL-encoding, backslashes, duplicate slashes, and trims whitespace.
 * Example:  '/Finance/Reports/' → '/finance/reports/'
 *           '/ABC'              → '/abc/'
 *           ''                  → '/'
 */
function normalizePath(vfsPath) {
    if (!vfsPath) return '/';
    let decoded = String(vfsPath).trim();
    // Iterative URL-decode (handles double-encoded paths like %2520)
    let prev = '';
    while (decoded !== prev) {
        prev = decoded;
        try { decoded = decodeURIComponent(decoded); } catch (_) { break; }
    }
    const cleaned = decoded
        .replace(/\\/g, '/')
        .split('/')
        .filter(Boolean)
        .join('/')
        .toLowerCase();
    return cleaned ? `/${cleaned}/` : '/';
}

function legacyEncodedPath(normalizedPath) {
    return encodeURI(normalizedPath).toLowerCase();
}

// ─────────────────────────────────────────────────────────────────────────────
//  DATABASE HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Returns candidate lock keys for a VFS path, accounting for parent/child VFS mount aliases.
 * E.g. Admin sees '/family/bibi ayesha/abc/' while user sees '/bibi ayesha/abc/'.
 */
function getEquivalentLockKeys(vfsPath) {
    const norm = normalizePath(vfsPath);
    const candidates = new Set([norm, legacyEncodedPath(norm)]);

    if (typeof lockedPathsCache !== 'undefined' && lockedPathsCache.size > 0) {
        const normParts = norm.split('/').filter(Boolean);
        for (const cachedPath of lockedPathsCache) {
            if (norm.endsWith(cachedPath) || cachedPath.endsWith(norm)) {
                candidates.add(cachedPath);
                candidates.add(legacyEncodedPath(cachedPath));
            } else {
                const cachedParts = cachedPath.split('/').filter(Boolean);
                if (normParts.length >= cachedParts.length) {
                    const normTail = '/' + normParts.slice(normParts.length - cachedParts.length).join('/') + '/';
                    if (normTail === cachedPath) {
                        candidates.add(cachedPath);
                        candidates.add(legacyEncodedPath(cachedPath));
                    }
                } else {
                    const cachedTail = '/' + cachedParts.slice(cachedParts.length - normParts.length).join('/') + '/';
                    if (cachedTail === norm) {
                        candidates.add(cachedPath);
                        candidates.add(legacyEncodedPath(cachedPath));
                    }
                }
            }
        }
    }
    return Array.from(candidates);
}

/**
 * Fetches the lock record for a path, checking plain, URI-encoded, and VFS alias keys.
 * @returns {Promise<{key:string, record:object}|null>}
 */
async function getLockRecord(db, normalizedPath) {
    const candidates = getEquivalentLockKeys(normalizedPath);
    // Look up all candidate keys concurrently instead of one-at-a-time —
    // this was previously a sequential await-in-a-loop, which is the main
    // source of latency on deep paths or paths with many VFS aliases.
    const results = await Promise.all(candidates.map(async key => {
        try {
            const raw = await db.get(key);
            if (raw) return { key, record: JSON.parse(raw) };
        } catch (_) { /* key not found */ }
        return null;
    }));
    return results.find(Boolean) || null;
}

/**
 * Resolves whether the given request path (or any ancestor) is locked.
 * Walks the VFS hierarchy root → leaf.
 * @returns {Promise<{lockedPath:string, record:object}|null>}
 */
async function checkPathLock(requestPath, db) {
    const normalized = normalizePath(requestPath);
    const parts = normalized.split('/').filter(Boolean);
    const levels = [];
    let currentPath = '/';
    for (const part of parts) {
        currentPath += `${part}/`;
        levels.push(currentPath);
    }
    // Fetch every ancestor level concurrently, then pick the first (root-most)
    // hit — was previously a sequential await-per-level walk.
    const records = await Promise.all(levels.map(p => getLockRecord(db, p)));
    for (let i = 0; i < levels.length; i++) {
        if (records[i]) return { lockedPath: levels[i], record: records[i].record };
    }
    return null;
}

/**
 * Resolves the first locked path in the hierarchy (root to leaf) that is NOT authorized.
 */
async function getFirstUnauthorizedLock(requestPath, sessionId, db) {
    const normalized = normalizePath(requestPath);
    const parts = normalized.split('/').filter(Boolean);
    const levels = [];
    let currentPath = '/';
    for (const part of parts) {
        currentPath += `${part}/`;
        levels.push(currentPath);
    }
    const records = await Promise.all(levels.map(p => getLockRecord(db, p)));
    for (let i = 0; i < levels.length; i++) {
        if (records[i] && !isSessionAuthorized(sessionId, levels[i])) {
            return { lockedPath: levels[i], record: records[i].record };
        }
    }
    return null;
}

/**
 * Resolves the deepest locked path in the hierarchy (leaf to root).
 */
async function getDeepestLock(requestPath, db) {
    const normalized = normalizePath(requestPath);
    const parts = normalized.split('/').filter(Boolean);
    const levels = [];
    for (let i = parts.length; i > 0; i--) {
        levels.push('/' + parts.slice(0, i).join('/') + '/');
    }
    const records = await Promise.all(levels.map(p => getLockRecord(db, p)));
    for (let i = 0; i < levels.length; i++) {
        if (records[i]) return { lockedPath: levels[i], record: records[i].record };
    }
    return null;
}

/**
 * Returns true if the path itself (not an ancestor) has a lock record.
 */
async function isPathLockedDirect(vfsPath, db) {
    return !!(await getLockRecord(db, normalizePath(vfsPath)));
}

// ─────────────────────────────────────────────────────────────────────────────
//  SESSION MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

function getOrSetSessionId(ctx) {
    let sessionId = ctx.cookies.get('folder_auth_session');
    if (!sessionId) {
        sessionId = crypto.randomBytes(24).toString('hex');
        ctx.cookies.set('folder_auth_session', sessionId, {
            httpOnly: true,
            sameSite: 'lax',
            path:     '/',
            maxAge:   7 * 24 * 60 * 60 * 1000, // 7 days persistence
            secure:   false   // HFS typically runs on plain HTTP locally
        });
    }
    return sessionId;
}

function isSessionAuthorized(sessionId, lockedPath) {
    const session = authorizedSessions[sessionId];
    if (!session) return false;
    const lastAccess = session[lockedPath];
    if (!lastAccess) return false;
    if (Date.now() - lastAccess > SESSION_TIMEOUT) {
        delete session[lockedPath];
        return false;
    }
    // Slide the expiry window on each valid access
    session[lockedPath] = Date.now();
    return true;
}

function authorizeSession(sessionId, lockedPath) {
    if (!authorizedSessions[sessionId]) authorizedSessions[sessionId] = {};
    authorizedSessions[sessionId][lockedPath] = Date.now();
}

function revokePathFromAllSessions(lockedPath) {
    for (const sid of Object.keys(authorizedSessions)) {
        const session = authorizedSessions[sid];
        if (session && session[lockedPath] !== undefined) {
            delete session[lockedPath];
        }
    }
}

function clearSession(sessionId) {
    delete authorizedSessions[sessionId];
}

// Periodic cleanup of expired/empty sessions (runs every 5 minutes)
setInterval(() => {
    const now = Date.now();
    for (const sid of Object.keys(authorizedSessions)) {
        const session = authorizedSessions[sid];
        if (!session) { delete authorizedSessions[sid]; continue; }
        for (const path of Object.keys(session)) {
            if (!path.startsWith('delete_auth_') && now - session[path] > SESSION_TIMEOUT) {
                delete session[path];
            }
        }
        if (Object.keys(session).length === 0) delete authorizedSessions[sid];
    }
}, 5 * 60 * 1000);

// ─────────────────────────────────────────────────────────────────────────────
//  PLUGIN INITIALISATION
// ─────────────────────────────────────────────────────────────────────────────
exports.init = async api => {
    _pluginApi = api; // make api available to isAdminUser()
    api.log("[folder-password v2.0] Initializing...");

    // Open LevelDB-backed KV store
    const db = await api.openDb('folder_passwords.kv', { defaultPutDelay: 0 });

    // ── Build in-memory locked paths cache ──────────────────────────────────
    const lockedPathsCache = new Set();
    try {
        // Safe iteration: attempt asObject(), fall back to iterating known keys
        let obj = {};
        if (typeof db.asObject === 'function') {
            obj = await db.asObject();
        } else if (db.asObject && typeof db.asObject === 'object') {
            obj = db.asObject;
        }
        for (const key of Object.keys(obj)) {
            lockedPathsCache.add(normalizePath(key));
        }
        api.log(`[folder-password] Cache loaded: ${lockedPathsCache.size} locked paths.`);
    } catch (e) {
        api.log(`[folder-password] Cache build warning: ${e.message}`);
    }

    // ── dirEntry event: annotate locked folder entries ───────────────────────
    const unsubscribeDirEntry = api.events.on('dirEntry', ({ entry, listUri }) => {
        const base      = (listUri || '/').replace(/\/?$/, '/');
        const entryPath = normalizePath(base + entry.n);
        if (lockedPathsCache.has(entryPath)) {
            entry.isLocked = true;
            entry.icon     = 'lock';
        }
    });

    // ─────────────────────────────────────────────────────────────────────────
    //  PLUGIN RETURN OBJECT
    // ─────────────────────────────────────────────────────────────────────────
    return {
        frontend_js:  'main.js',
        frontend_css: 'style.css',
        unload:       unsubscribeDirEntry,

        // ── Cross-plugin API ──────────────────────────────────────────────────
        customApi: {
            async isFolderLocked(vfsPath) {
                return await isPathLockedDirect(vfsPath, db);
            }
        },

        // ── REST endpoints ────────────────────────────────────────────────────
        customRest: {

            /**
             * SET or CHANGE a folder password.
             * Requires an authenticated HFS session.
             */
            async setPassword({ vfsPath, password, currentPassword }, ctx) {
                if (!vfsPath || !password) {
                    return { error: 'Bad Request', message: 'vfsPath and password are required.' };
                }

                const username = api.getCurrentUsername(ctx);
                if (!username) {
                    return { error: 'Unauthorized', message: 'You must be logged in.' };
                }

                const key = normalizePath(vfsPath);
                const existingLock = await getLockRecord(db, key);

                // If folder is already locked, non-admin user must enter the current password
                if (existingLock && !isAdminUser(username)) {
                    const sessionId = getOrSetSessionId(ctx);
                    const isAuth = isSessionAuthorized(sessionId, key);
                    if (!isAuth) {
                        if (!currentPassword || !verifyPassword(currentPassword, existingLock.record.salt, existingLock.record.hash)) {
                            return { success: false, error: 'Unauthorized', message: 'Incorrect current password. Lock modification denied.' };
                        }
                    }
                }

                const salt = crypto.randomBytes(16).toString('hex');
                const hash = hashPassword(password, salt);

                await db.put(key, JSON.stringify({ hash, salt }));
                lockedPathsCache.add(key);

                const sessionId = getOrSetSessionId(ctx);
                authorizeSession(sessionId, key);

                api.log(`[folder-password] Password set for: ${key} by ${username}`);
                try {
                    api.customApiCall('logAuditEvent', {
                        username,
                        ip:       ctx.ip,
                        action:   'Set Folder Password',
                        result:   'Success',
                        reason:   `Lock applied to: ${key}`
                    });
                } catch (_) {}

                return { success: true, path: key };
            },

            /**
             * GET all currently locked paths (non-sensitive — paths only, no hashes).
             */
            async getLockedPaths(params, ctx) {
                const username = api.getCurrentUsername(ctx);
                return {
                    lockedPaths: Array.from(lockedPathsCache),
                    currentUserIsAdmin: isAdminUser(username)
                };
            },

            /**
             * UNLOCK a folder for the caller's session.
             * Returns success:true and sets session cookie on correct password.
             */
            async unlockFolder({ vfsPath, password }, ctx) {
                if (!vfsPath || !password) {
                    return { error: 'Bad Request', message: 'vfsPath and password are required.' };
                }

                const sessionId = getOrSetSessionId(ctx);
                const check = await getFirstUnauthorizedLock(vfsPath, sessionId, db);
                if (!check) return { success: true }; // Not locked — no action needed

                const { lockedPath, record } = check;
                if (verifyPassword(password, record.salt, record.hash)) {
                    authorizeSession(sessionId, lockedPath);

                    try {
                        api.customApiCall('logAuditEvent', {
                            username: api.getCurrentUsername(ctx) || 'guest',
                            ip:       ctx.ip,
                            action:   'Folder Unlock',
                            result:   'Success',
                            reason:   `Unlocked: ${lockedPath}`
                        });
                    } catch (_) {}

                    return { success: true, path: lockedPath };
                }

                try {
                    api.customApiCall('logAuditEvent', {
                        username: api.getCurrentUsername(ctx) || 'guest',
                        ip:       ctx.ip,
                        action:   'Folder Unlock',
                        result:   'Failed',
                        reason:   `Failed unlock attempt for: ${lockedPath}`
                    });
                } catch (_) {}

                return { success: false, error: 'Unauthorized', message: 'Incorrect folder password.' };
            },

            /**
             * VERIFY + REMOVE password in a single server-round-trip.
             * Requires the current password before removal (unless logged in as admin).
             */
            async verifyAndRemovePassword({ vfsPath, currentPassword }, ctx) {
                if (!vfsPath) {
                    return { error: 'Bad Request', message: 'vfsPath is required.' };
                }

                const username = api.getCurrentUsername(ctx);
                const isAdmin = isAdminUser(username);

                const key   = normalizePath(vfsPath);
                const check = await getLockRecord(db, key);
                if (!check) {
                    return { success: true, message: 'Path was not locked.' };
                }

                const { key: lockedPath, record } = check;
                if (!isAdmin) {
                    if (!currentPassword || !verifyPassword(currentPassword, record.salt, record.hash)) {
                        return { success: false, error: 'Unauthorized', message: 'Incorrect password. Lock not removed.' };
                    }
                }

                // Password verified (or admin override) — remove from DB and cache
                await db.del(lockedPath);
                try { await db.del(legacyEncodedPath(lockedPath)); } catch (_) {}
                lockedPathsCache.delete(lockedPath);

                // Revoke all active sessions for this path immediately
                revokePathFromAllSessions(lockedPath);

                api.log(`[folder-password] Password removed for: ${lockedPath} (by ${username || 'guest'})`);
                try {
                    api.customApiCall('logAuditEvent', {
                        username: username || 'unknown',
                        ip:       ctx.ip,
                        action:   'Remove Folder Password',
                        result:   'Success',
                        reason:   `Lock removed from: ${lockedPath}${isAdmin ? ' (Admin override)' : ''}`
                    });
                } catch (_) {}

                return { success: true, path: lockedPath };
            },

            /**
             * ADMIN REMOVE FOLDER PASSWORD — Admin only endpoint to strip folder password without verification.
             */
            async adminRemovePassword({ vfsPath }, ctx) {
                const username = api.getCurrentUsername(ctx);
                if (!isAdminUser(username)) {
                    return { success: false, error: 'Unauthorized', message: 'Only admin can remove folder passwords without verification.' };
                }
                if (!vfsPath) {
                    return { error: 'Bad Request', message: 'vfsPath is required.' };
                }

                const keys = getEquivalentLockKeys(vfsPath);
                for (const key of keys) {
                    await db.del(key);
                    try { await db.del(legacyEncodedPath(key)); } catch (_) {}
                    lockedPathsCache.delete(key);
                    revokePathFromAllSessions(key);
                }

                api.log(`[folder-password] Admin removed folder password for: ${vfsPath} (keys: ${keys.join(', ')})`);
                try {
                    api.customApiCall('logAuditEvent', {
                        username,
                        ip:       ctx.ip,
                        action:   'Admin Remove Folder Password',
                        result:   'Success',
                        reason:   `Lock removed from: ${vfsPath} by Admin override`
                    });
                } catch (_) {}

                return { success: true, path: normalizePath(vfsPath) };
            },

            /**
             * ADMIN RESET PASSWORD — Admin only endpoint to reset/overwrite folder password.
             */
            async adminResetPassword({ vfsPath, newPassword }, ctx) {
                const username = api.getCurrentUsername(ctx);
                if (!isAdminUser(username)) {
                    return { success: false, error: 'Unauthorized', message: 'Only admin can reset folder passwords.' };
                }
                if (!vfsPath || !newPassword) {
                    return { error: 'Bad Request', message: 'vfsPath and newPassword are required.' };
                }

                const key  = normalizePath(vfsPath);
                const salt = crypto.randomBytes(16).toString('hex');
                const hash = hashPassword(newPassword, salt);

                await db.put(key, JSON.stringify({ hash, salt }));
                lockedPathsCache.add(key);

                api.log(`[folder-password] Admin reset password for: ${key}`);
                return { success: true, path: key };
            },

            /**
             * REMOVE password (legacy endpoint — kept for backwards-compat).
             * Still requires verifyAndRemovePassword to be called first;
             * this endpoint is now only reachable after auth token is set.
             */
            async removePassword({ vfsPath }, ctx) {
                const username = api.getCurrentUsername(ctx);
                const isAdmin = isAdminUser(username);
                const key = normalizePath(vfsPath);
                const check = await getLockRecord(db, key);
                if (check) {
                    await db.del(key);
                    try { await db.del(legacyEncodedPath(key)); } catch (_) {}
                    lockedPathsCache.delete(key);
                    revokePathFromAllSessions(key);
                }
                api.log(`[folder-password] removePassword (legacy) called for: ${key}`);
                return { success: true, path: key };
            },

            /**
             * VERIFY DELETE — confirms folder lock password before destruction of a locked folder.
             * Sets a 30-second deletion token in the session.
             */
            async verifyDeletePassword({ vfsPath, folderPassword }, ctx) {
                if (!vfsPath || !folderPassword) return { error: 'Bad Request' };

                const username = api.getCurrentUsername(ctx);
                if (!username) return { allowed: false, message: 'You must be logged in.' };

                const check = await getDeepestLock(vfsPath, db);
                if (!check) return { allowed: true }; // Already unlocked

                const { lockedPath, record } = check;
                const matches = verifyPassword(folderPassword, record.salt, record.hash);
                if (matches) {
                    const sessionId = getOrSetSessionId(ctx);
                    authorizeSession(sessionId, lockedPath);
                    const session = authorizedSessions[sessionId] || (authorizedSessions[sessionId] = {});
                    session[`delete_auth_${lockedPath}`] = Date.now();
                    return { allowed: true };
                }

                try {
                    api.customApiCall('logAuditEvent', {
                        username,
                        ip:       ctx.ip,
                        action:   'Delete Folder Auth',
                        result:   'Failed',
                        reason:   `Incorrect folder password for deleting ${vfsPath}`
                    });
                } catch (_) {}

                return { allowed: false, message: 'Incorrect folder password.' };
            },

            /**
             * CHECK if a path is inside a locked folder (client-facing, non-sensitive).
             */
            async checkPathLocked({ vfsPath }) {
                let decoded = vfsPath;
                try { decoded = decodeURIComponent(vfsPath); } catch (_) {}
                const check = await checkPathLock(decoded, db);
                return {
                    locked:     !!check,
                    lockedPath: check ? check.lockedPath : null
                };
            },

            /**
             * VERIFY MULTIPLE DELETE PASSWORDS — verifies passwords for a batch of locked
             * folders and sets delete-auth tokens for all of them atomically.
             * Returns allowed:true only if EVERY password is correct.
             * Admin users bypass all verification automatically.
             */
            async verifyMultiDeletePassword({ items }, ctx) {
                if (!Array.isArray(items) || items.length === 0) {
                    return { allowed: false, error: 'Bad Request', message: 'items array is required.' };
                }
                const username = api.getCurrentUsername(ctx);
                if (!username) return { allowed: false, message: 'You must be logged in.' };

                // Admin bypasses all folder password verification
                if (isAdminUser(username)) return { allowed: true };

                const sessionId = getOrSetSessionId(ctx);
                const verifiedLockedPaths = [];

                // First pass: verify ALL passwords before setting any tokens
                for (const item of items) {
                    if (!item.vfsPath) continue;
                    const check = await getDeepestLock(item.vfsPath, db);
                    if (!check) { verifiedLockedPaths.push(item.vfsPath); continue; } // Not locked
                    const { lockedPath, record } = check;
                    if (!item.folderPassword || !verifyPassword(item.folderPassword, record.salt, record.hash)) {
                        try {
                            api.customApiCall('logAuditEvent', {
                                username, ip: ctx.ip,
                                action: 'Multi Delete Folder Auth',
                                result: 'Failed',
                                reason: `Incorrect password for: ${lockedPath}`
                            });
                        } catch (_) {}
                        return { allowed: false, message: `Incorrect password for: ${lockedPath}`, failedPath: lockedPath };
                    }
                    verifiedLockedPaths.push(lockedPath);
                }

                // Second pass: all verified — set delete-auth tokens for every path
                const session = authorizedSessions[sessionId] || (authorizedSessions[sessionId] = {});
                for (const lp of verifiedLockedPaths) {
                    authorizeSession(sessionId, lp);
                    session[`delete_auth_${lp}`] = Date.now();
                }
                return { allowed: true };
            },

            async revokeFolderAuth({ vfsPath }, ctx) {
                if (!vfsPath) return { success: false, error: 'Bad Request', message: 'vfsPath is required.' };
                const lockedPath = normalizePath(vfsPath);
                const sessionId = ctx.cookies && typeof ctx.cookies.get === 'function'
                    ? ctx.cookies.get('folder_auth_session')
                    : null;
                if (sessionId) {
                    const session = authorizedSessions[sessionId];
                    if (session && session[lockedPath]) {
                        delete session[lockedPath];
                    }
                }
                return { success: true, path: lockedPath };
            }
        },

        // ── Koa Middleware ────────────────────────────────────────────────────
        middleware: ctx => {
            const stopContext = () => { if (ctx && typeof ctx.stop === 'function') ctx.stop(); };
            const isPluginEndpoint = reqPath => typeof reqPath === 'string' && /^\/~\/api\/_/.test(reqPath);
            const isInternalApi = reqPath => typeof reqPath === 'string' && /^\/~\/api\//.test(reqPath);
            const wantsJsonResponse = (reqPath, headers) => {
                if (isInternalApi(reqPath)) return true;
                const accept = headers && typeof headers['accept'] === 'string' ? headers['accept'] : '';
                const xRequestedWith = headers && typeof headers['x-requested-with'] === 'string' ? headers['x-requested-with'] : '';
                return accept.includes('application/json') || accept.includes('text/json') || xRequestedWith.toLowerCase() === 'xmlhttprequest';
            };

            const migrateLockRecord = async (oldPath, newPath) => {
                const normOld = normalizePath(oldPath);
                const normNew = normalizePath(newPath);
                if (normOld === normNew) return;

                const lock = await getLockRecord(db, normOld);
                if (lock) {
                    await db.del(normOld);
                    try { await db.del(legacyEncodedPath(normOld)); } catch (_) {}
                    lockedPathsCache.delete(normOld);

                    await db.put(normNew, JSON.stringify(lock.record));
                    lockedPathsCache.add(normNew);
                    revokePathFromAllSessions(normOld);
                    api.log(`[folder-password] Migrated lock from ${normOld} to ${normNew}`);
                }

                for (const cachedPath of Array.from(lockedPathsCache)) {
                    if (cachedPath.startsWith(normOld) && cachedPath !== normOld) {
                        const subRel = cachedPath.slice(normOld.length);
                        const subNew = normNew + subRel;
                        const subLock = await getLockRecord(db, cachedPath);
                        if (subLock) {
                            await db.del(cachedPath);
                            try { await db.del(legacyEncodedPath(cachedPath)); } catch (_) {}
                            lockedPathsCache.delete(cachedPath);

                            await db.put(subNew, JSON.stringify(subLock.record));
                            lockedPathsCache.add(subNew);
                            revokePathFromAllSessions(cachedPath);
                            api.log(`[folder-password] Migrated sub-lock from ${cachedPath} to ${subNew}`);
                        }
                    }
                }
            };

            return (async () => {
                const reqPath = typeof ctx.path === 'string' ? ctx.path : '';
                const headers = ctx.headers && typeof ctx.headers === 'object' ? ctx.headers : {};

                // ── Fast-path: skip ALL middleware work for login / logout ─────
                // Must be first — before body parsing, path extraction, or any DB access —
                // so that login requests are never delayed by folder-lock DB reads.
                // Note: only clear session on explicit logout; do not clear on login (prevents immediate logout after login).
                if (reqPath.startsWith('/~/api/logout')) {
                    const sid = ctx.cookies && typeof ctx.cookies.get === 'function' ? ctx.cookies.get('folder_auth_session') : null;
                    if (sid) clearSession(sid);
                    // allow logout to proceed without further plugin checks
                    return;
                }
                if (reqPath.startsWith('/~/api/login')) {
                    // Skip middleware work for login requests but do not clear session here.
                    return;
                }

                // Skip our own plugin endpoints to prevent infinite loops
                if (isPluginEndpoint(reqPath)) return;

                let urisToCheck = [];
                let isApiRoute  = false;

                if (reqPath.startsWith('/~/api/')) {
                    isApiRoute = true;
                    const pushPathValue = value => {
                        if (value === undefined || value === null) return;
                        if (Array.isArray(value)) {
                            value.forEach(pushPathValue);
                            return;
                        }
                        if (typeof value === 'object') {
                            Object.values(value).forEach(pushPathValue);
                            return;
                        }
                        if (typeof value !== 'string') return;

                        const trimmed = value.trim();
                        if (!trimmed) return;

                        try {
                            const parsed = JSON.parse(trimmed);
                            pushPathValue(parsed);
                            return;
                        } catch (_) {}

                        if (trimmed.includes('/') || trimmed.includes('%2F') || trimmed.includes('%2f')) {
                            urisToCheck.push(trimmed);
                        } else if (trimmed.length > 0 && !['true','false','null','undefined'].includes(trimmed.toLowerCase())) {
                            urisToCheck.push(trimmed);
                            const referer = ctx.headers && (ctx.headers['referer'] || ctx.headers['Referer']);
                            if (referer) {
                                try {
                                    const refPath = new URL(referer).pathname;
                                    urisToCheck.push(normalizePath(refPath + '/' + trimmed));
                                } catch (_) {}
                            }
                        }
                    };

                    if (ctx.query && typeof ctx.query === 'object') {
                        pushPathValue(ctx.query);
                    }

                    const body = ctx.request && ctx.request.body;
                    if (body) {
                        pushPathValue(body);
                    }
                } else if (!reqPath.startsWith('/~/') && reqPath !== '/favicon.ico') {
                    urisToCheck.push(reqPath);
                }

                if (urisToCheck.length === 0) return;

                const sessionId = getOrSetSessionId(ctx);

                // ── RENAME / MOVE / CUT / PASTE INTERCEPTION & MIGRATION ─────
                const body = ctx.request && ctx.request.body;
                const query = ctx.query;
                const hasRenameParam = !!((body && (body.newName || body.new_name || body.name || body.to || body.dest || body.destination)) || (query && (query.newName || query.new_name || query.name || query.to || query.dest || query.destination)));
                const isRenameOrMove = reqPath.includes('/rename') || reqPath.includes('/move') || reqPath.includes('/cut') || reqPath.includes('/paste') || (isApiRoute && hasRenameParam);
                if (isRenameOrMove) {
                    // Check every target path concurrently instead of one-at-a-time.
                    const renameChecks = await Promise.all(
                        urisToCheck.map(async targetPath => ({ targetPath, check: await checkPathLock(targetPath, db) }))
                    );
                    for (const { lockedPath } of renameChecks.filter(r => r.check).map(r => ({ lockedPath: r.check.lockedPath }))) {
                        if (!isSessionAuthorized(sessionId, lockedPath)) {
                            const username = api.getCurrentUsername(ctx);
                            if (!isAdminUser(username)) {
                                ctx.status = 403;
                                ctx.body = {
                                    error: 'locked',
                                    reason: 'rename_requires_auth',
                                    path: lockedPath,
                                    message: 'Renaming or moving this locked item requires authentication.'
                                };
                                stopContext();
                                return;
                            }
                        }
                    }
                    // Every uri in urisToCheck has now been fully vetted above — the
                    // generic catch-all check further down would just redo the same
                    // walk a second time for the same request, so it's skipped for
                    // rename/move/cut/paste via the `isRenameOrMove` guard there.

                    // Migrate lock record if rename/move parameters exist
                    const body = ctx.request && ctx.request.body;
                    const query = ctx.query;
                    
                    const extractStr = val => {
                        if (!val) return null;
                        if (Array.isArray(val)) val = val[0];
                        if (typeof val === 'object') val = val.from || val.src || val.source || val.uri || val.path || val.entry || val.target || val.name || val.to;
                        return typeof val === 'string' && val.trim() ? val.trim() : null;
                    };

                    const fromPath = extractStr(body && (body.from || body.src || body.source || body.uri || body.path || body.uris || body.entry || body.target))
                        || extractStr(query && (query.from || query.src || query.source || query.uri || query.path || query.uris || query.entry || query.target));
                    
                    const toPath = extractStr(body && (body.to || body.dest || body.destination || body.name || body.newName || body.new_name))
                        || extractStr(query && (query.to || query.dest || query.destination || query.name || query.newName || query.new_name));

                    if (fromPath && toPath) {
                        try {
                            const normFrom = normalizePath(fromPath);
                            let fullTo;
                            const cleanTo = String(toPath).trim();
                            if (cleanTo.startsWith('/')) {
                                fullTo = normalizePath(cleanTo);
                            } else {
                                const parent = normFrom.replace(/\/$/, '').split('/').slice(0, -1).join('/') + '/';
                                fullTo = normalizePath(parent + cleanTo);
                            }
                            await migrateLockRecord(normFrom, fullTo);
                        } catch (_) {}
                    }
                }

                // ── ZIP / ARCHIVE INTERCEPTION ──────────────────────────────
                const isZip = reqPath.includes('/zip') || reqPath.includes('/archive') || reqPath.includes('/pack') || (ctx.query && (ctx.query.zip !== undefined || ctx.query.archive !== undefined));
                if (isZip) {
                    for (const targetPath of urisToCheck) {
                        const check = await getFirstUnauthorizedLock(targetPath, sessionId, db);
                        if (check) {
                            ctx.status = 403;
                            ctx.body = {
                                error: 'locked',
                                reason: 'zip_requires_auth',
                                path: check.lockedPath,
                                message: 'Zip archive contains password protected items.'
                            };
                            stopContext();
                            return;
                        }
                        // Also check if target path is a folder containing locked subfolders
                        const normTarget = normalizePath(targetPath);
                        for (const lp of lockedPathsCache) {
                            if (lp.startsWith(normTarget) && !isSessionAuthorized(sessionId, lp)) {
                                ctx.status = 403;
                                ctx.body = {
                                    error: 'locked',
                                    reason: 'zip_requires_auth',
                                    path: lp,
                                    message: 'Zip archive contains password protected subfolder.'
                                };
                                stopContext();
                                return;
                            }
                        }
                    }
                }

                const isDelete = ctx.method === 'DELETE' || (ctx.method === 'POST' && (reqPath.endsWith('/delete') || reqPath.includes('/api/delete')));
                if (isDelete) {
                    // Admin can delete locked folders without any password prompt
                    const _delUsername = api.getCurrentUsername(ctx);
                    if (isAdminUser(_delUsername)) {
                        // Skip all delete-lock checks for admin — fall through to normal processing
                        for (const targetPath of urisToCheck) {
                            const pathToClean = normalizePath(targetPath);
                            setImmediate(async () => {
                                try { await db.del(pathToClean); } catch (_) {}
                                lockedPathsCache.delete(pathToClean);
                            });
                        }
                        // Do not stopContext — let HFS proceed with the delete
                    } else {
                    for (const targetPath of urisToCheck) {
                        // 1. Check if any child/descendant folder is locked
                        const normTarget = normalizePath(targetPath);
                        const lockedDescendants = [];
                        for (const lp of lockedPathsCache) {
                            if (lp.startsWith(normTarget) && lp !== normTarget) {
                                lockedDescendants.push(lp);
                            }
                        }

                        if (lockedDescendants.length > 0) {
                            ctx.status = 403;
                            ctx.body = {
                                error: 'locked',
                                reason: 'child_is_locked',
                                message: 'Deletion denied. A subfolder inside this directory is locked.'
                            };
                            stopContext();
                            return;
                        }

                        // 2. Check if the target path itself (or an ancestor) is locked
                        const check = await getDeepestLock(targetPath, db);
                        if (!check) continue;

                        const pathToCheck = check.lockedPath;
                        const session = authorizedSessions[sessionId];
                        const deleteToken = `delete_auth_${pathToCheck}`;
                        const lastDeleteAuth = session ? session[deleteToken] : null;

                        if (!lastDeleteAuth || (Date.now() - lastDeleteAuth > 30000)) {
                            ctx.status = 403;
                            ctx.body   = { error: 'locked', reason: 'delete_requires_auth', path: pathToCheck };
                            stopContext();
                            return;
                        }

                        if (session) delete session[deleteToken];
                        setImmediate(async () => {
                            try {
                                await db.del(pathToCheck);
                                api.log(`[folder-password] Auto-cleanup: removed lock for deleted path: ${pathToCheck}`);
                            } catch (_) {}
                        });
                    }
                    } // end non-admin delete block
                }

                for (const targetPath of urisToCheck) {
                    // isRenameOrMove requests already ran an equivalent (and now
                    // parallelized) check above and would have returned a 403 if
                    // unauthorized — re-running it here would just double the DB work
                    // for no behavior change, and was the main cause of the perceptible
                    // delay before the password prompt appeared on cut/move.
                    if (isRenameOrMove) continue;

                    const check = await getFirstUnauthorizedLock(targetPath, sessionId, db);
                    if (!check) continue;

                    const { lockedPath } = check;
                    const username = api.getCurrentUsername(ctx);
                    if (isAdminUser(username)) continue; // Admin bypasses all folder locks

                    // Force no-cache on any locked path so authorization is always re-evaluated on server
                    ctx.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
                    ctx.set('Pragma', 'no-cache');
                    ctx.set('Expires', '0');

                    if (isSessionAuthorized(sessionId, lockedPath)) continue;

                    ctx.status = 403;
                    if (wantsJsonResponse(reqPath, headers)) {
                        ctx.body = { error: 'locked', path: lockedPath, message: 'This folder is password protected.' };
                    } else {
                        ctx.type = 'html';
                        ctx.body = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Locked Folder — Enterprise Storage Vault</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#0f1117;color:#f1f1f1;display:flex;justify-content:center;align-items:center;min-height:100vh}
    .card{background:#1a1d27;border:1px solid #2a2d3a;border-radius:12px;box-shadow:0 8px 40px rgba(0,0,0,0.6);padding:36px 32px;width:90%;max-width:420px;text-align:center}
    .icon{font-size:48px;margin-bottom:16px}
    h2{font-size:22px;font-weight:700;color:#8ab4f8;margin-bottom:8px}
    p{font-size:14px;color:#9aa0a6;margin-bottom:20px;line-height:1.5}
    input[type=password]{width:100%;padding:12px 14px;margin-bottom:14px;border:1px solid #2a2d3a;background:#0f1117;color:#f1f1f1;border-radius:6px;font-size:14px;outline:none;transition:border-color 0.2s}
    input[type=password]:focus{border-color:#01a0e4;box-shadow:0 0 0 3px rgba(1,160,228,0.2)}
    button{width:100%;padding:12px;background:#01a0e4;color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:700;cursor:pointer;transition:background 0.2s}
    button:hover{background:#0084c2}
    button:disabled{opacity:0.6;cursor:default}
    .err{color:#ea4335;font-size:13px;margin-top:10px;display:none}
    .spin{color:#01a0e4;font-size:13px;margin-top:8px;display:none}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">🔐</div>
    <h2>Folder Locked</h2>
    <p>This directory is password protected.<br>Enter the password to gain access.</p>
    <form id="f" autocomplete="off">
      <input type="password" id="p" placeholder="Enter folder password" required autofocus />
      <button type="submit" id="b">Unlock</button>
      <div id="sp" class="spin">⏳ Verifying...</div>
      <div id="er" class="err">❌ Incorrect password. Please try again.</div>
    </form>
  </div>
  <script>
    document.getElementById('f').onsubmit=function(e){
      e.preventDefault();
      var pass=document.getElementById('p').value;
      if(!pass)return;
      var btn=document.getElementById('b');
      var er=document.getElementById('er');
      var sp=document.getElementById('sp');
      er.style.display='none';sp.style.display='block';btn.disabled=true;

      // Use AbortController to implement a network timeout so the UI doesn't hang
      var controller = null;
      try {
        controller = new AbortController();
      } catch (e) { /* AbortController not supported */ }
      var signal = controller ? controller.signal : undefined;
      var timeoutId = controller ? setTimeout(function(){ controller.abort(); }, 5000) : null; // 5s timeout

      fetch('/~/api/_unlockFolder',{
        method:'POST',
        headers:{'content-type':'application/json','x-hfs-anti-csrf':'1'},
        body:JSON.stringify({vfsPath:location.pathname,password:pass}),
        signal: signal
      }).then(function(r){ if (timeoutId) clearTimeout(timeoutId); return r.json(); }).then(function(r){
        sp.style.display='none';btn.disabled=false;
        if(r&&r.success){
          try {
            var c = JSON.parse(sessionStorage.getItem('fp_unlocked') || '[]');
            if (c.indexOf(r.path) === -1) {
              c.push(r.path);
              sessionStorage.setItem('fp_unlocked', JSON.stringify(c));
            }
          } catch(e) {}
          location.reload();
        }
        else{er.textContent='❌ Incorrect password. Please try again.';er.style.display='block';document.getElementById('p').value='';}
      }).catch(function(err){
        if (timeoutId) clearTimeout(timeoutId);
        sp.style.display='none';btn.disabled=false;
        if (err && err.name === 'AbortError') {
          er.textContent = '⏱ Network timeout. Please try again.';
        } else {
          er.textContent = '❌ Incorrect password or network error. Please try again.';
        }
        er.style.display='block';
      });
    };
  </script>
</body>
</html>`;
                    }
                    stopContext();
                    return;
                }
            })();
        }
    };
};
