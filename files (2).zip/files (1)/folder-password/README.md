# HFS 3.2.1 Enterprise Security Suite - Folder Password Protection Plugin

## Overview
The **Folder Password Protection** plugin allows administrators to assign individual passwords to any number of folders. Requests to access, browse, search, download, upload, or delete files inside locked folders are blocked on the server side unless the user provides the correct password. Once unlocked, sessions are persisted securely using cookies and sliding memory maps.

---

## Folder Structure
```
plugins/folder-password/
├── plugin.js         # Server-side salted hash database and Koa middleware
├── README.md         # Full documentation and guides
└── public/
    ├── main.js       # Client-side XHR hook and warning modal dialog
    └── style.css     # Password prompt modal stylesheet
```

---

## Architecture Diagram
```
  [Browser Client]
         │
         │  1. Requests resource (e.g. GET /Finance/reports/)
         ▼
  [Koa Middleware] ──(Check Lock database)──► [Is locked path?]
         │                                            │
         ▼ (Yes: Validate Cookie and Session Map)     ▼
  [Browse allowed] ◄────[Session Valid?]◄─────────────┘
         │                      │
         │                      ▼ (No: Block request)
         │               [Return 401 JSON / HTML Form]
         │                      │
         ▼                      ▼
  [Response 200]         [Prompt Password Modal]
```

---

## Installation Guide
1. Locate the HFS configuration/installation folder. On Windows Server 2022, this is next to `hfs.exe`.
2. Copy the `folder-password` folder into the `plugins` folder.
3. Restart HFS or enable the plugin in the HFS Admin Panel under **Plugins**.

---

## Configuration Guide
The folder passwords are set dynamically inside the HFS file list view by the server administrator:
* **Admin Login:** Log in as the server administrator.
* **Adding a Lock:** Right-click any folder inside the list view and select **Set Folder Password**.
* **Changing a Lock:** Right-click a locked folder and select **Change Folder Password**.
* **Removing a Lock:** Right-click a locked folder and select **Remove Folder Password**.

---

## Developer & API Documentation

### Client-to-Server Endpoints

#### 1. Set Folder Password (Admin only)
* **API Route:** `POST /~/api/_setPassword`
* **Request Payload:** `{ "vfsPath": "/Finance/", "password": "securepassword" }`
* **Response Signature:** `{ "success": true, "path": "/finance/" }`

#### 2. Remove Folder Password (Admin only)
* **API Route:** `POST /~/api/_removePassword`
* **Request Payload:** `{ "vfsPath": "/Finance/" }`
* **Response Signature:** `{ "success": true, "path": "/finance/" }`

#### 3. Unlock Folder (Session check)
* **API Route:** `POST /~/api/_unlockFolder`
* **Request Payload:** `{ "vfsPath": "/Finance/report.pdf", "password": "securepassword" }`
* **Response Signature:** `{ "success": true, "path": "/finance/" }`

#### 4. Verify Delete Password
* **API Route:** `POST /~/api/_verifyDeletePassword`
* **Request Payload:** `{ "vfsPath": "/Finance/", "password": "securepassword" }`
* **Response Signature:** `{ "allowed": true }`

#### 5. Non-sensitive Lock Check
* **API Route:** `POST /~/api/_checkPathLocked`
* **Request Payload:** `{ "vfsPath": "/Finance/report.pdf" }`
* **Response Signature:** `{ "locked": true, "lockedPath": "/finance/" }`

---

## Troubleshooting Guide
* **Password prompt does not appear:** Ensure the `main.js` and `style.css` are loaded in your browser console (look for `plugins/folder-password/public` files in network tab).
* **Bypassing the Lock:** If a user is currently logged in as the HFS administrator, they bypass all passwords automatically. Log out of the admin panel to test lock enforcement as a normal user/guest.
* **Deletions fail without prompt:** Deletions of locked paths require double-confirming the password. Make sure the confirm modal is filled out properly.

---

## Security Guide
* **Hierarchical Enforcement:** Setting a lock on `/Finance/` automatically protects `/Finance/Subfolder/` and `/Finance/file.txt`.
* **Race Condition & Cache Integrity:** Cookie-based sessions are evaluated on every request, preventing race conditions or cache leaks.
* **Salted Hashes:** Salted SHA-256 prevents rainbow table attacks on the backend `folder_passwords.kv` database.
