// Enterprise HFS 3.2.1 Security Plugin Suite
// Plugin: Folder Password Protection
// File: plugins/folder-password/test.js

const assert = require('assert').strict;
const path = require('path');

// 1. Mock HFS API Object & LevelDB Store
class MockDb {
    constructor() {
        this.store = {};
    }
    async get(key) {
        if (this.store[key] === undefined) throw new Error("Not found");
        return this.store[key];
    }
    async put(key, val) {
        this.store[key] = val;
    }
    async del(key) {
        delete this.store[key];
    }
    asObject() {
        return this.store;
    }
}

class MockHfsApi {
    constructor() {
        this.db = new MockDb();
        this.loggedUsername = '';
        this.logs = [];
        this.auditLogs = [];
        const self = this;
        this.events = {
            on(event, callback) {
                if (event === 'dirEntry') self.dirEntryCb = callback;
                return () => {};
            }
        };
        this.misc = {
            isLocalHost(ctx) { return true; },
            HOUR: 3600000,
            netMatches(ip, mask) { return true; }
        };
    }

    openDb(filename) {
        return this.db;
    }

    getCurrentUsername(ctx) {
        return this.loggedUsername;
    }

    log(...args) {
        this.logs.push(args.join(' '));
    }

    customApiCall(method, params) {
        if (method === 'logAuditEvent') {
            this.auditLogs.push(params);
        }
        return [];
    }

    ctxBelongsTo(ctx, accounts) {
        const username = this.getCurrentUsername(ctx);
        return accounts.includes(username);
    }

    require(filePath) {
        if (filePath === './auth') {
            return {
                srpCheck(username, password) {
                    return password === 'correct_account_password' ? { username } : null;
                }
            };
        }
        return {};
    }
}

// Mock Koa Cookie interface
class MockCookies {
    constructor() {
        this.store = {};
    }
    get(name) {
        return this.store[name];
    }
    set(name, val, opts) {
        this.store[name] = val;
    }
}

// Mock Koa Context Class
class MockContext {
    constructor(options = {}) {
        this.method = options.method || 'GET';
        this.path = options.path || '/';
        this.headers = options.headers || { 'accept': 'application/json' };
        this.cookies = options.cookies || new MockCookies();
        this.status = options.status || 200;
        this.body = options.body || null;
        this.request = options.request || {};
        this.query = options.query || {};
        this.state = options.state || { considerAsGui: true };
        this.ip = options.ip || '127.0.0.1';
        this.stopped = false;
    }
    stop() {
        this.stopped = true;
    }
    set(name, val) {
        this.headers[name.toLowerCase()] = val;
    }
}

// 2. Main Test Runner
async function runTests() {
    console.log("=== Running Folder Password Protection Plugin Tests ===");

    const api = new MockHfsApi();
    const pluginPath = path.resolve(__dirname, 'plugin.js');
    const plugin = require(pluginPath);

    // Call init
    const initialized = await plugin.init(api);

    assert.equal(plugin.version, 2.0);
    assert.equal(initialized.frontend_js, 'main.js');
    assert.equal(initialized.frontend_css, 'style.css');

    const mockCtx = new MockContext();

    // Test Case 1: Admin Sets Password
    console.log("Running Test Case 1: Admin sets password for folder /HR/...");
    api.loggedUsername = 'admin';
    let res = await initialized.customRest.setPassword({ vfsPath: '/HR/', password: 'hrpass123', accountPassword: 'correct_account_password' }, mockCtx);
    assert.equal(res.success, true);
    assert.equal(res.path, '/hr/');
    console.log("Test Case 1 Passed!");

    // Test Case 2: Hierarchical Locking Verification
    console.log("Running Test Case 2: Hierarchical locking (Subfolders)...");
    api.loggedUsername = 'guest';
    
    // Requesting subfolder inside /HR/ (which is /HR/recruitment/)
    const mockCtxSub = new MockContext({
        method: 'GET',
        path: '/HR/recruitment/files/',
        cookies: new MockCookies()
    });

    await initialized.middleware(mockCtxSub);
    // Guest has no session, must be BLOCKED!
    assert.equal(mockCtxSub.status, 403);
    assert.equal(mockCtxSub.stopped, true);
    assert.equal(mockCtxSub.body.error, 'locked');
    assert.equal(mockCtxSub.body.path, '/hr/'); // Points to locked parent root!
    console.log("Test Case 2 Passed!");

    // Test Case 3: Unlock Folder with Correct Password
    console.log("Running Test Case 3: Unlock folder with correct password...");
    const mockCtxUnlock = new MockContext({
        method: 'POST',
        cookies: mockCtxSub.cookies // Maintain same cookie session
    });

    res = await initialized.customRest.unlockFolder({ vfsPath: '/HR/recruitment/files/', password: 'hrpass123' }, mockCtxUnlock);
    assert.equal(res.success, true);
    assert.equal(res.path, '/hr/');
    console.log("Test Case 3 Passed!");

    // Test Case 4: Access Unlocked Folder (Session Persistence)
    console.log("Running Test Case 4: Access folder after unlocking (Session Persists)...");
    const mockCtxSub2 = new MockContext({
        method: 'GET',
        path: '/HR/recruitment/files/',
        cookies: mockCtxSub.cookies // Same cookie session
    });

    await initialized.middleware(mockCtxSub2);
    // Session is valid, must be ALLOWED (status remains 200, not stopped)
    assert.equal(mockCtxSub2.status, 200);
    assert.equal(mockCtxSub2.stopped, false);
    console.log("Test Case 4 Passed!");

    // Test Case 5: Delete Protection (Requires double confirmation password)
    console.log("Running Test Case 5: Delete locked folder protection...");
    
    // Attempting delete request
    const mockCtxDel = new MockContext({
        method: 'POST',
        path: '/HR/api/delete',
        cookies: mockCtxSub.cookies // Same session which unlocked browsing
    });

    await initialized.middleware(mockCtxDel);
    // Browsing was unlocked, but DELETION must still be blocked (requires deletion confirmation token)
    assert.equal(mockCtxDel.status, 403);
    assert.equal(mockCtxDel.stopped, true);
    assert.equal(mockCtxDel.body.reason, 'delete_requires_auth');
    console.log("Test Case 5 Passed!");

    // Test Case 6: Authorize Deletion with password
    console.log("Running Test Case 6: Authorize deletion with password...");
    const mockCtxDelVerify = new MockContext({
        cookies: mockCtxSub.cookies
    });
    
    let delAuthRes = await initialized.customRest.verifyDeletePassword({ vfsPath: '/HR/', folderPassword: 'hrpass123' }, mockCtxDelVerify);
    assert.equal(delAuthRes.allowed, true);

    // Resending delete request
    const mockCtxDel2 = new MockContext({
        method: 'POST',
        path: '/HR/api/delete',
        cookies: mockCtxSub.cookies // Same session with confirmation token
    });

    await initialized.middleware(mockCtxDel2);
    // Now it should be allowed to proceed
    assert.equal(mockCtxDel2.status, 200);
    assert.equal(mockCtxDel2.stopped, false);
    console.log("Test Case 6 Passed!");

    // Test Case 7: Deleting a sub-file inside a locked parent folder (path mismatch bug)
    console.log("Running Test Case 7: Delete a sub-file inside a locked parent folder...");
    
    // First, verify delete password using the sub-file path (which is what frontend sends when deleting)
    const mockCtxDelSubVerify = new MockContext({
        cookies: mockCtxSub.cookies
    });
    let delSubAuthRes = await initialized.customRest.verifyDeletePassword({
        vfsPath: '/HR/recruitment/files/confidential.pdf',
        folderPassword: 'hrpass123'
    }, mockCtxDelSubVerify);
    assert.equal(delSubAuthRes.allowed, true);

    // Send the delete API request targeting the sub-file
    const mockCtxDelSub = new MockContext({
        method: 'POST',
        path: '/~/api/delete',
        cookies: mockCtxSub.cookies,
        request: {
            body: {
                uris: ['/HR/recruitment/files/confidential.pdf']
            }
        }
    });

    await initialized.middleware(mockCtxDelSub);
    // Since we fixed the path mismatch bug, this request should proceed successfully (status 200, not stopped)
    assert.equal(mockCtxDelSub.status, 200);
    assert.equal(mockCtxDelSub.stopped, false);
    console.log("Test Case 7 Passed!");

    // Test Case 8: Nested locks support
    console.log("Running Test Case 8: Nested locks (different password for parent and child)...");
    api.loggedUsername = 'admin';
    // Set lock on child /HR/recruitment/
    let resChild = await initialized.customRest.setPassword({ vfsPath: '/HR/recruitment/', password: 'recruitmentpass456' }, mockCtx);
    assert.equal(resChild.success, true);
    assert.equal(resChild.path, '/hr/recruitment/');

    api.loggedUsername = 'guest';
    // Accessing child /HR/recruitment/ without any unlocked parent session
    const mockCtxChildLocked = new MockContext({
        method: 'GET',
        path: '/HR/recruitment/files/',
        cookies: new MockCookies()
    });
    
    await initialized.middleware(mockCtxChildLocked);
    // Should get blocked at the parent folder /hr/
    assert.equal(mockCtxChildLocked.status, 403);
    assert.equal(mockCtxChildLocked.body.path, '/hr/');

    // Unlock parent folder first
    let unlockParentRes = await initialized.customRest.unlockFolder({ vfsPath: '/HR/', password: 'hrpass123' }, mockCtxChildLocked);
    assert.equal(unlockParentRes.success, true);
    assert.equal(unlockParentRes.path, '/hr/');

    // Try accessing child again with parent unlocked
    const mockCtxChildLocked2 = new MockContext({
        method: 'GET',
        path: '/HR/recruitment/files/',
        cookies: mockCtxChildLocked.cookies
    });
    await initialized.middleware(mockCtxChildLocked2);
    // Now it should block at the child folder /hr/recruitment/
    assert.equal(mockCtxChildLocked2.status, 403);
    assert.equal(mockCtxChildLocked2.body.path, '/hr/recruitment/');

    // Unlock child folder
    let unlockChildRes = await initialized.customRest.unlockFolder({ vfsPath: '/HR/recruitment/', password: 'recruitmentpass456' }, mockCtxChildLocked2);
    assert.equal(unlockChildRes.success, true);
    assert.equal(unlockChildRes.path, '/hr/recruitment/');

    // Try accessing child third time with parent and child unlocked
    const mockCtxChildUnlocked = new MockContext({
        method: 'GET',
        path: '/HR/recruitment/files/',
        cookies: mockCtxChildLocked2.cookies
    });
    await initialized.middleware(mockCtxChildUnlocked);
    // Now it should succeed
    assert.equal(mockCtxChildUnlocked.status, 200);
    assert.equal(mockCtxChildUnlocked.stopped, false);
    console.log("Test Case 8 Passed!");

    // Test Case 9: Locked child deletion guard
    console.log("Running Test Case 9: Prevent parent deletion if child is locked...");
    // Let's set a lock on /HR/recruitment/ again (it's already set)
    // Try to delete parent folder /HR/
    const mockCtxDeleteParent = new MockContext({
        method: 'POST',
        path: '/~/api/delete',
        cookies: new MockCookies(),
        request: {
            body: {
                uris: ['/HR/']
            }
        }
    });

    await initialized.middleware(mockCtxDeleteParent);
    // Deletion should be denied because child folder (/hr/recruitment/) is locked!
    assert.equal(mockCtxDeleteParent.status, 403);
    assert.equal(mockCtxDeleteParent.body.error, 'locked');
    assert.equal(mockCtxDeleteParent.body.reason, 'child_is_locked');
    console.log("Test Case 9 Passed!");

    // Test Case 10: Rename locked folder protection & lock migration
    console.log("Running Test Case 10: Rename locked folder protection & lock migration...");
    api.loggedUsername = 'guest';
    const mockCtxRenameBlocked = new MockContext({
        method: 'POST',
        path: '/~/api/rename',
        cookies: new MockCookies(),
        request: {
            body: { from: '/HR/', to: '/HR_Renamed/' }
        }
    });
    await initialized.middleware(mockCtxRenameBlocked);
    assert.equal(mockCtxRenameBlocked.status, 403);
    assert.equal(mockCtxRenameBlocked.body.error, 'locked');
    assert.equal(mockCtxRenameBlocked.body.reason, 'rename_requires_auth');

    // Admin renames folder
    api.loggedUsername = 'admin';
    const mockCtxRenameAdmin = new MockContext({
        method: 'POST',
        path: '/~/api/rename',
        cookies: new MockCookies(),
        request: {
            body: { from: '/HR/', to: '/HR_Renamed/' }
        }
    });
    await initialized.middleware(mockCtxRenameAdmin);
    assert.equal(mockCtxRenameAdmin.status, 200);

    // Wait for setImmediate lock migration
    await new Promise(r => setTimeout(r, 100));

    // Verify renamed folder /hr_renamed/ is still locked!
    api.loggedUsername = 'guest';
    const mockCtxAccessRenamed = new MockContext({
        method: 'GET',
        path: '/HR_Renamed/',
        cookies: new MockCookies()
    });
    await initialized.middleware(mockCtxAccessRenamed);
    assert.equal(mockCtxAccessRenamed.status, 403);
    assert.equal(mockCtxAccessRenamed.body.path, '/hr_renamed/');
    // Test Case 10B: Relative subfolder rename lock migration
    console.log("Running Test Case 10B: Relative subfolder rename lock migration...");
    api.loggedUsername = 'admin';
    await initialized.customRest.setPassword({ vfsPath: '/Public/Sub/', password: 'subpass' }, new MockContext({ cookies: new MockCookies() }));
    
    const mockCtxRenameSub = new MockContext({
        method: 'POST',
        path: '/~/api/rename',
        cookies: new MockCookies(),
        request: {
            body: { uri: '/Public/Sub/', newName: 'Sub_New/' }
        }
    });
    await initialized.middleware(mockCtxRenameSub);
    assert.equal(mockCtxRenameSub.status, 200);

    api.loggedUsername = 'guest';
    const mockCtxAccessSubRenamed = new MockContext({
        method: 'GET',
        path: '/Public/Sub_New/',
        cookies: new MockCookies()
    });
    await initialized.middleware(mockCtxAccessSubRenamed);
    assert.equal(mockCtxAccessSubRenamed.status, 403);
    assert.equal(mockCtxAccessSubRenamed.body.path, '/public/sub_new/');
    console.log("Test Case 10B Passed!");

    // Test Case 11: Zip Archive protection
    console.log("Running Test Case 11: Zip archive protection on locked folder...");
    const mockCtxZipBlocked = new MockContext({
        method: 'POST',
        path: '/~/api/zip',
        cookies: new MockCookies(),
        request: {
            body: { uris: ['/HR_Renamed/'] }
        }
    });
    await initialized.middleware(mockCtxZipBlocked);
    assert.equal(mockCtxZipBlocked.status, 403);
    assert.equal(mockCtxZipBlocked.body.error, 'locked');
    assert.equal(mockCtxZipBlocked.body.reason, 'zip_requires_auth');
    console.log("Test Case 11 Passed!");

    // Test Case 13: Admin Remove Folder Password Endpoint
    console.log("Running Test Case 13: Admin remove folder password without authentication...");
    api.loggedUsername = 'admin';
    const mockCtxAdminRemove = new MockContext();
    let removeRes = await initialized.customRest.adminRemovePassword({ vfsPath: '/HR_Renamed/' }, mockCtxAdminRemove);
    assert.equal(removeRes.success, true);
    assert.equal(removeRes.path, '/hr_renamed/');

    // Verify folder is no longer locked
    const mockCtxAccessRemoved = new MockContext({
        method: 'GET',
        path: '/HR_Renamed/',
        cookies: new MockCookies()
    });
    await initialized.middleware(mockCtxAccessRemoved);
    assert.equal(mockCtxAccessRemoved.status, 200);
    console.log("Test Case 13 Passed!");

    // Test Case 14: DirEntry lock icon visibility for all users & access difference
    console.log("Running Test Case 14: Verify lock icon is set for all users in dirEntry...");
    await initialized.customRest.setPassword({ vfsPath: '/SecretFolder/', password: 'secretpass' }, mockCtx);
    
    // Test dirEntry with guest / normal user (asd)
    const guestEntry = { n: 'SecretFolder', isFolder: true };
    const guestCtx = new MockContext();
    api.loggedUsername = 'asd';
    api.dirEntryCb({ entry: guestEntry, listUri: '/', ctx: guestCtx });
    assert.equal(guestEntry.icon, 'lock', "Normal user MUST see lock icon on locked folder");
    assert.equal(guestEntry.isLocked, true, "Normal user MUST have isLocked set to true");

    // Test dirEntry with admin
    const adminEntry = { n: 'SecretFolder', isFolder: true };
    const adminCtx = new MockContext();
    api.loggedUsername = 'admin';
    api.dirEntryCb({ entry: adminEntry, listUri: '/', ctx: adminCtx });
    assert.equal(adminEntry.icon, 'lock', "Admin user MUST see lock icon");
    assert.equal(adminEntry.isLocked, true, "Admin user MUST have isLocked set to true");

    // Test access difference: Admin opens without authentication (status 200)
    const mockCtxAdminAccess = new MockContext({ method: 'GET', path: '/SecretFolder/' });
    api.loggedUsername = 'admin';
    await initialized.middleware(mockCtxAdminAccess);
    assert.equal(mockCtxAdminAccess.status, 200, "Admin MUST open locked folder without authentication");

    // Test access difference: Normal user cannot open without authentication (status 403)
    const mockCtxUserAccess = new MockContext({ method: 'GET', path: '/SecretFolder/' });
    api.loggedUsername = 'asd';
    await initialized.middleware(mockCtxUserAccess);
    assert.equal(mockCtxUserAccess.status, 403, "Normal user MUST NOT open locked folder without authentication");
    console.log("Test Case 14 Passed!");

    console.log("All Folder Password Protection Plugin Tests Completed Successfully!");
}

runTests().catch(err => {
    console.error("Test execution failed:", err);
    process.exit(1);
});
