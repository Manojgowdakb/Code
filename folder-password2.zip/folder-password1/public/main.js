// Enterprise HFS 3.2.1 — Folder Password Plugin  v2.2
// plugins/folder-password/public/main.js
//
// v2.2 FIXES:
//  • Set Lock injection: triple-fallback path detection + retry (up to 6×) + periodic scanner
//  • Delete interception via fetch override (shows delete modal on 403 locked response)
//  • Popup quota guard already in custom.html
"use strict";
{
    // ═══════════════════════════════════════════════════════════════
    //  UTILITIES
    // ═══════════════════════════════════════════════════════════════
    const esc = s => String(s).replace(/[&<>'"]/g,
        c => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[c] || c));

    const normPath = v => {
        if (!v) return '/';
        let s = String(v).trim(), p = '';
        while (s !== p) { p = s; try { s = decodeURIComponent(s); } catch(_){break;} }
        const c = s.replace(/\\/g, '/').split('/').filter(Boolean).join('/').toLowerCase();
        return c ? `/${c}/` : '/';
    };

    const nameKey = name => {
        let s = String(name||'').replace(/\+/g,' '), p='';
        while (s !== p) { p=s; try { s=decodeURIComponent(s); } catch(_){break;} }
        return s.replace(/\/+$/,'').toLowerCase();
    };

    // ═══════════════════════════════════════════════════════════════
    //  originalFetch — captured before we override window.fetch
    // ═══════════════════════════════════════════════════════════════
    window._hfsNativeFetch = window._hfsNativeFetch || window.fetch.bind(window);
    const originalFetch = window._hfsNativeFetch;

    let _currentUserIsAdmin = false;
    const isCurrentUserAdmin = () => {
        if (_currentUserIsAdmin) return true;
        if (typeof HFS !== 'undefined' && HFS.state) {
            if (HFS.state.admin === true || HFS.state.isAdmin === true) return true;
            if (HFS.state.username === 'admin') return true;
        }
        return false;
    };

    // ═══════════════════════════════════════════════════════════════
    //  NETWORK HELPERS + REST HELPER
    // ═══════════════════════════════════════════════════════════════
    const fetchWithTimeout = (url, opts = {}, timeoutMs = 10000) => {
        if (typeof AbortController === 'undefined') {
            return Promise.race([
                originalFetch(url, opts),
                new Promise((_, reject) => setTimeout(() => reject(new Error('network-timeout')), timeoutMs))
            ]);
        }
        const controller = new AbortController();
        const signal = controller.signal;
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        return originalFetch(url, Object.assign({}, opts, { signal })).finally(() => clearTimeout(timer));
    };

    // Prevent duplicate concurrent calls for the same REST name
    const _inflight = new Map();

    const rest = (name, params = {}) => {
        if (_inflight.has(name)) return _inflight.get(name);

        // raw(): parse JSON response but never throw on non-2xx or invalid JSON
        const raw = () => fetchWithTimeout(`/~/api/_${name}`, {
            method: 'POST',
            headers: { 'content-type': 'application/json', 'x-hfs-anti-csrf': '1' },
            body: JSON.stringify(params)
        }, 10000).then(async r => {
            // Return empty on server errors (400, 401, 403, 418, 5xx)
            // so callers never crash on unexpected responses
            if (!r.ok && r.status !== 200) return {};
            const t = await r.text();
            try { return t ? JSON.parse(t) : {}; } catch(_) { return {}; }
        }).catch(() => ({}));  // network / timeout → empty, never throws

        const p = (async () => {
            if (typeof HFS !== 'undefined' && typeof HFS.customRestCall === 'function') {
                try {
                    const maybe = HFS.customRestCall(name, params);
                    const resolved = await Promise.resolve(maybe).catch(() => raw());
                    return resolved || {};
                } catch (e) {
                    return raw();
                }
            }
            return raw();
        })().finally(() => { _inflight.delete(name); });

        _inflight.set(name, p);
        return p;
    };

    // ═══════════════════════════════════════════════════════════════
    //  SESSION STORAGE  (persists unlocked paths across page reloads)
    // ═══════════════════════════════════════════════════════════════
    const SS_KEY = 'fp_unlocked';
    const getCache  = () => { try { return new Set(JSON.parse(sessionStorage.getItem(SS_KEY)||'[]')); } catch(_){return new Set();} };
    const setCache  = s   => { try { sessionStorage.setItem(SS_KEY, JSON.stringify([...s])); } catch(_){} };
    const markOk    = p   => { const c=getCache(); c.add(normPath(p)); setCache(c); };
    const isCached  = p   => getCache().has(normPath(p));
    const clearCached = p => { const c=getCache(); c.delete(normPath(p)); setCache(c); };

    // ═══════════════════════════════════════════════════════════════
    //  LOCKED PATHS REGISTRY
    // ═══════════════════════════════════════════════════════════════
    window.enterpriseLockedPaths = new Set();

    const isLocked = vfsPath => {
        const norm = normPath(vfsPath);
        const parts = norm.split('/').filter(Boolean);
        for (let i = parts.length; i > 0; i--) {
            const cur = '/' + parts.slice(0, i).join('/') + '/';
            if (window.enterpriseLockedPaths.has(cur)) return cur;
        }
        return null;
    };

    const isLockedDirect = vfsPath => {
        return window.enterpriseLockedPaths.has(normPath(vfsPath));
    };

    const getRequiredLock = vfsPath => {
        const norm = normPath(vfsPath);
        const parts = norm.split('/').filter(Boolean);
        let cur = '/';
        for (const p of parts) {
            cur += `${p}/`;
            if (window.enterpriseLockedPaths.has(cur)) {
                if (!isCached(cur)) {
                    return cur;
                }
            }
        }
        return null;
    };

    // resilient locked-paths refresh with timeout, backoff and polling control
    const _lockedBackoff = { backoff: 0, intervalId: null };

    const refreshLocked = () => {
        if (!navigator.onLine) return Promise.resolve();
        // rest() already deduplicates in-flight calls via _inflight
        // Note: rest() never throws (returns {} on any error), so .catch is just a safety net
        return rest('getLockedPaths').then(r => {
            if (r && r.lockedPaths && Array.isArray(r.lockedPaths)) {
                // Valid response: update cache
                _lockedBackoff.backoff = 0;
                window.enterpriseLockedPaths = new Set(r.lockedPaths.map(normPath));
                if (typeof r.currentUserIsAdmin === 'boolean') _currentUserIsAdmin = r.currentUserIsAdmin;
            }
            // If r is empty {} (due to 400/401/403 for unauthenticated users),
            // we simply keep whatever paths were already in the cache.
            // This is intentional: the 403 fetch interceptor handles the unlock flow.
        }).catch(() => {
            // Should rarely happen since rest() swallows errors, but keep backoff as safety
            _lockedBackoff.backoff = Math.min(120000, _lockedBackoff.backoff ? _lockedBackoff.backoff * 2 : 5000);
            setTimeout(() => { if (navigator.onLine) refreshLocked(); }, _lockedBackoff.backoff);
        });
    };

    const _startLockedPolling = () => {
        if (_lockedBackoff.intervalId) return;
        _lockedBackoff.intervalId = setInterval(() => { if (navigator.onLine) refreshLocked(); }, 15000);
    };
    const _stopLockedPolling = () => { if (_lockedBackoff.intervalId) { clearInterval(_lockedBackoff.intervalId); _lockedBackoff.intervalId = null; } };

    if (navigator.onLine) { _startLockedPolling(); setTimeout(refreshLocked, 300); }
    window.addEventListener('online', () => { _startLockedPolling(); refreshLocked(); });
    window.addEventListener('offline', () => { _stopLockedPolling(); });

        const getCurrentUri = () => {
        const path = location.pathname || '/';
        /* FIX: use real browser path for API/system pages so HFS.state.uri
           (which may still hold the old locked-folder path) doesn't mislead us */
        if (path.startsWith('/~/api/') || path.startsWith('/~/admin/')) return path;

        if (typeof HFS !== 'undefined' && HFS.state && HFS.state.uri) return HFS.state.uri;
        try {
            const url = new URL(location.href, location.href);
            if (url.searchParams.has('uri')) return url.searchParams.get('uri');
            if (url.searchParams.has('uris')) return url.searchParams.get('uris');
        } catch (_) {}
        if (location.hash && location.hash.startsWith('#')) {
            return location.hash.slice(1);
        }
        return path;
    };

    let lastObservedUri = normPath(getCurrentUri());

    const revokeFolderAuth = async lockedPath => {
        if (!lockedPath) return;
        clearCached(lockedPath);
        try {
            await rest('revokeFolderAuth', { vfsPath: lockedPath });
        } catch (_) {}
    };

        const guardLockedNavigation = uri => {
        const normalized = normPath(uri);
        /* FIX: never run lock-guard on system/API pages (login/logout/etc.) */
        if (normalized.startsWith('/~/api/') || normalized.startsWith('/~/admin/')) return;
        if (normalized === lastObservedUri) return;

        const previousUri = lastObservedUri;
        lastObservedUri = normalized;



        const previousLock = isLocked(previousUri);
        const currentLock  = getRequiredLock(normalized);
        if (previousLock && previousLock !== isLocked(normalized)) {
            const isFile = /\.[a-zA-Z0-9]{1,10}\/$/.test(previousLock);
            if (!isFile) {
                revokeFolderAuth(previousLock);
            }
        }

        const lock = currentLock;
        if (!lock || isCached(lock)) return;

        showUnlock(lock, () => {
            lastObservedUri = normalized;
            if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') {
                HFS.reload();
            } else {
                location.reload();
            }
        }, () => {
            const fallback = previousUri || '/';
            if (location.pathname !== fallback) {
                location.href = fallback;
            } else {
                location.reload();
            }
        });
    };

    const wrapHistoryMethod = name => {
        if (!history || typeof history[name] !== 'function') return;
        const original = history[name].bind(history);
        history[name] = function(state, title, url) {
            try {
                const result = original(state, title, url);
                setTimeout(() => guardLockedNavigation(getCurrentUri()), 0);
                return result;
            } catch (err) {
                if (typeof console !== 'undefined' && typeof console.warn === 'function') {
                    console.warn(`Enterprise folder-password plugin ignored invalid history.${name} call`, err);
                }
                return undefined;
            }
        };
    };
    wrapHistoryMethod('pushState');
    wrapHistoryMethod('replaceState');

    if (typeof HFS !== 'undefined' && typeof HFS.watchState === 'function') {
        let _prevUser = (HFS.state && HFS.state.username) || null;
        HFS.watchState('uri', value => {
            refreshLocked();
            guardLockedNavigation(value || getCurrentUri());
        });
        HFS.watchState('username', value => {
            refreshLocked();
            if (_prevUser && !value) {
                try { sessionStorage.clear(); } catch (_) {}
                if (window.location.pathname !== '/' && window.location.pathname !== '') {
                    window.location.href = window.location.origin + '/';
                }
            }
            _prevUser = value;
        });
    }
    window.addEventListener('popstate', () => {
        refreshLocked();
        guardLockedNavigation(getCurrentUri());
    });
    window.addEventListener('hashchange', () => {
        refreshLocked();
        guardLockedNavigation(getCurrentUri());
    });
    // Throttle navigation guard to reduce CPU/network pressure
    setInterval(() => guardLockedNavigation(getCurrentUri()), 2000);

    // ═══════════════════════════════════════════════════════════════
    //  ENTRY PATH
    // ═══════════════════════════════════════════════════════════════
    const entryPath = entry => {
        if (entry && entry.uri) return entry.uri;
        const base = ((HFS.state && HFS.state.uri) || '/').replace(/\/?$/, '/');
        const name = String((entry && entry.n) || '').replace(/^\/+|\/+$/g, '');
        const isDir= (entry && entry.isFolder) || /\/$/.test((entry && entry.n) || '');
        return base + name + (isDir ? '/' : '');
    };

    // ═══════════════════════════════════════════════════════════════
    //  DELETE-PENDING FLAG
    //  Set when the user clicks "Yes" on HFS's delete confirmation
    //  dialog. Allows showUnlock to show "Confirm Delete" label.
    // ═══════════════════════════════════════════════════════════════
    let _fpDeletePending = false;
    let _fpDeletePendingTimer = null;

    const setDeletePending = () => {
        _fpDeletePending = true;
        clearTimeout(_fpDeletePendingTimer);
        _fpDeletePendingTimer = setTimeout(() => { _fpDeletePending = false; }, 8000);
    };

    // Intercept clicks on HFS confirm-delete dialog buttons (e.g. "Yes", "OK", "Confirm")
    document.addEventListener('click', e => {
        const btn = e.target.closest('button,[role="button"]');
        if (!btn) return;
        const txt = (btn.textContent || '').trim().toLowerCase();
        if (txt === 'yes' || txt === 'ok' || txt === 'confirm' || txt === 'delete') {
            // Only set flag if a HFS confirmation dialog is open (contains delete-related text)
            const dlg = btn.closest('[role="dialog"],[class*="Dialog"],[class*="Modal"],[class*="Confirm"],[class*="confirm"]');
            if (dlg) {
                const dlgText = (dlg.textContent || '').toLowerCase();
                if (dlgText.includes('delete') || dlgText.includes('remove')) {
                    setDeletePending();
                }
            }
        }
    }, true);

    // ═══════════════════════════════════════════════════════════════
    //  MODAL FACTORY
    // ═══════════════════════════════════════════════════════════════
    const mkOverlay = (id, html, onCancel) => {
        if (document.getElementById(id) || document.querySelector('.pwd-modal-overlay')) return null;
        const el = document.createElement('div');
        el.id = id; el.className = 'pwd-modal-overlay'; el.innerHTML = html;
        document.body.appendChild(el);
        el.addEventListener('click', e => {
            if (e.target === el) {
                el.remove();
                if (typeof onCancel === 'function') onCancel();
            }
        });
        return el;
    };

    // ═══════════════════════════════════════════════════════════════
    //  MODAL: UNLOCK (standard folder access)
    // ═══════════════════════════════════════════════════════════════
    const showUnlock = (lockedPath, onOk, onCancel, submitLabel, isMenuAction = false) => {
        const isFile = /\.[a-zA-Z0-9]{1,10}\/$/.test(lockedPath);
        const cleanPath = isFile ? lockedPath.replace(/\/$/, '') : lockedPath;
        const btnLabel = submitLabel || (_fpDeletePending ? 'Confirm Delete' : (isFile ? 'Unlock File' : 'Unlock Folder'));
        const forgotHtml = isCurrentUserAdmin()
            ? `<div style="margin-top:12px;text-align:center;">
                <button type="button" id="ep-ul-forgot" style="font-size:12px;padding:8px;background:transparent;border:1px dashed #01a0e4;color:#01a0e4;width:100%;border-radius:6px;cursor:pointer;font-weight:600;">🔑 Forgot Folder Password? (Admin Reset)</button>
               </div>`
            : '';
        const m = mkOverlay('ep-unlock-modal', `
            <div class="pwd-modal-card">
                <div class="pwd-modal-header">
                    <h2 class="pwd-modal-title">Authentication Required</h2></div>
                <div class="pwd-modal-body">
                    <p class="pwd-modal-text">Enter the password for <strong>${esc(cleanPath)}</strong> to continue.</p>
                    <form id="ep-ul-form" class="pwd-modal-form" autocomplete="off">
                        <input type="password" id="ep-ul-inp" class="pwd-modal-input" placeholder="Enter folder password" required autocomplete="new-password"/>
                        ${forgotHtml}
                        <div id="ep-ul-err" class="pwd-modal-error" style="display:none;">❌ Incorrect password. Please try again.</div>
                        <div id="ep-ul-ld"  class="pwd-modal-loading" style="display:none;">⏳ Verifying password…</div>
                    </form>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-ul-cancel" type="button" class="pwd-modal-btn btn-secondary">Cancel</button>
                    <button type="submit" form="ep-ul-form" class="pwd-modal-btn btn-primary">${btnLabel}</button>
                </div>
            </div>`, onCancel);
        if (!m) return;
        const inp=m.querySelector('#ep-ul-inp'), err=m.querySelector('#ep-ul-err'),
              ld=m.querySelector('#ep-ul-ld'), sub=m.querySelector('[type="submit"]'),
              forgotBtn=m.querySelector('#ep-ul-forgot');
        if (forgotBtn) {
            forgotBtn.onclick = () => {
                m.remove();
                showAdminRemoveLock(lockedPath);
            };
        }
        setTimeout(() => inp && inp.focus(), 120);
        m.querySelector('#ep-ul-cancel').onclick = () => {
            m.remove();
            if (typeof onCancel === 'function') onCancel();
        };
        m.querySelector('#ep-ul-form').onsubmit = e => {
            e.preventDefault();
            const pw = inp.value; if (!pw) return;
            err.style.display='none'; ld.style.display='block'; sub.disabled=true;
            rest('unlockFolder', { vfsPath:lockedPath, password:pw })
            .then(r => {
                ld.style.display='none'; sub.disabled=false;
                if (r && r.success) {
                    markOk(lockedPath);
                    m.remove();
                    if (typeof onOk === 'function') {
                        onOk();
                    } else {
                        if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') HFS.reload();
                        else location.href = lockedPath;
                    }
                    if (isMenuAction) {
                        const isDeleteAction = btnLabel === 'Confirm Delete' || _fpDeletePending;
                        setTimeout(() => {
                            clearCached(lockedPath);
                            revokeFolderAuth(lockedPath);
                        }, isDeleteAction ? 30000 : 1800);
                    }
                } else {
                    err.style.display='block'; inp.value=''; inp.focus();
                }
            })
            .catch(() => { ld.style.display='none'; sub.disabled=false; err.style.display='block'; inp.value=''; inp.focus(); });
        };
    };

    // ═══════════════════════════════════════════════════════════════
    //  MODAL: DELETE AUTHORIZATION
    // ═══════════════════════════════════════════════════════════════
    const showDeleteAuth = (lockedPath, onOk, onCancel) => {
        const isFile = /\.[a-zA-Z0-9]{1,10}\/$/.test(lockedPath);
        const cleanPath = isFile ? lockedPath.replace(/\/$/, '') : lockedPath;
        const m = mkOverlay('ep-del-modal', `
            <div class="pwd-modal-card border-danger">
                <div class="pwd-modal-header">
                    <h2 class="pwd-modal-title">Confirm Delete</h2></div>
                <div class="pwd-modal-body">
                    <p class="pwd-modal-text text-danger">Enter the password to confirm deletion of <strong>${esc(cleanPath)}</strong>.</p>
                    <form id="ep-del-form" class="pwd-modal-form" autocomplete="off">
                        <input type="password" id="ep-del-inp" class="pwd-modal-input" placeholder="Enter folder password" required/>
                        <div id="ep-del-err" class="pwd-modal-error" style="display:none;">❌ Incorrect password. Deletion denied.</div>
                    </form>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-del-cancel" type="button" class="pwd-modal-btn btn-secondary">Cancel</button>
                    <button type="submit" form="ep-del-form" class="pwd-modal-btn btn-danger" style="display: inline-flex; align-items: center; justify-content: center; gap: 6px;"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>Confirm Delete</button>
                </div>
            </div>`, onCancel);
        if (!m) return;
        const inp=m.querySelector('#ep-del-inp'), err=m.querySelector('#ep-del-err');
        setTimeout(() => inp && inp.focus(), 120);
        m.querySelector('#ep-del-cancel').onclick = () => {
            m.remove();
            if (typeof onCancel === 'function') onCancel();
        };
        m.querySelector('#ep-del-form').onsubmit = e => {
            e.preventDefault();
            const pw = inp.value; if (!pw) return;
            err.style.display='none';
            rest('verifyDeletePassword', { vfsPath:lockedPath, folderPassword:pw })
            .then(r => {
                if (r && r.allowed) { clearCached(lockedPath); m.remove(); onOk(); }
                else {
                    err.textContent = (r && r.message) ? `❌ ${r.message}` : '❌ Incorrect password. Deletion denied.';
                    err.style.display='block'; inp.value=''; inp.focus();
                }
            })
            .catch(() => {
                err.textContent = '❌ Network error. Please try again.';
                err.style.display='block'; inp.value=''; inp.focus();
            });
        };
    };

    // ═══════════════════════════════════════════════════════════════
    //  MODAL: REMOVE LOCK
    // ═══════════════════════════════════════════════════════════════
    // ═══════════════════════════════════════════════════════════════
    //  MODAL: ADMIN REMOVE FOLDER PASSWORD (ADMIN ONLY, NO AUTH REQUIRED)
    // ═══════════════════════════════════════════════════════════════
    const showAdminRemoveLock = defaultPath => {
        const m = mkOverlay('ep-admin-rmlock-modal', `
            <div class="pwd-modal-card border-danger">
                <div class="pwd-modal-header">
                    <h2 class="pwd-modal-title" style="color:#ea4335;">Remove Folder Password</h2></div>
                <div class="pwd-modal-body">
                    <div style="color:#01a0e4;font-size:12px;margin-bottom:12px;font-weight:600;">👑 Admin Panel Mode: Remove folder password without authentication</div>
                    <form id="ep-arm-form" class="pwd-modal-form" autocomplete="off">
                        <input type="text" id="ep-arm-inp" class="pwd-modal-input" placeholder="VFS Path (e.g. /demo/)" value="${esc(defaultPath || '')}" required autofocus />
                        <div id="ep-arm-err" class="pwd-modal-error" style="display:none;"></div>
                        <div id="ep-arm-ld"  class="pwd-modal-loading" style="display:none;">⏳ Removing folder password…</div>
                    </form>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-arm-cancel" type="button" class="pwd-modal-btn btn-secondary">Cancel</button>
                    <button type="submit" form="ep-arm-form" class="pwd-modal-btn btn-danger" style="display: inline-flex; align-items: center; justify-content: center; gap: 6px;"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 17c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm6-9h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6-5c1.66 0 3 1.34 3 3v2H9V6c0-1.66 1.34-3 3-3z"/></svg>Remove Folder Password</button>
                </div>
            </div>`);
        if (!m) return;
        const inp=m.querySelector('#ep-arm-inp'), err=m.querySelector('#ep-arm-err'),
              ld=m.querySelector('#ep-arm-ld'), sub=m.querySelector('[type="submit"]');
        setTimeout(() => inp && inp.focus(), 120);
        m.querySelector('#ep-arm-cancel').onclick = () => m.remove();
        m.querySelector('#ep-arm-form').onsubmit = e => {
            e.preventDefault();
            const p = inp.value.trim(); if (!p) return;
            err.style.display='none'; ld.style.display='block'; sub.disabled=true;
            rest('adminRemovePassword', { vfsPath: p })
            .then(r => {
                ld.style.display='none';
                if (r && r.success) {
                    clearCached(p); m.remove();
                    if (window.enterpriseLockedPaths) window.enterpriseLockedPaths.delete(normPath(p));
                    const t = Object.assign(document.createElement('div'), {
                        style:'position:fixed;bottom:24px;right:24px;background:#34a853;color:#fff;padding:12px 20px;border-radius:8px;font-size:13px;font-weight:600;z-index:99999999;box-shadow:0 4px 16px rgba(0,0,0,.3)',
                        textContent:'✅ Folder password removed successfully'
                    });
                    document.body.appendChild(t);
                    setTimeout(() => { t.remove(); refreshLocked().then(applyBadges); if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') HFS.reload(); else location.reload(); }, 600);
                } else {
                    err.textContent = (r && r.message) ? `❌ ${r.message}` : '❌ Error removing password.';
                    err.style.display='block'; sub.disabled=false;
                }
            })
            .catch(ex => { ld.style.display='none'; sub.disabled=false; err.textContent=`❌ ${ex}`; err.style.display='block'; });
        };
    };

    // ═══════════════════════════════════════════════════════════════
    //  MODAL: REMOVE LOCK
    // ═══════════════════════════════════════════════════════════════
    const showRemoveLock = vfsPath => {
        const forgotHtml = isCurrentUserAdmin()
            ? `<div style="margin-top:10px;text-align:center;">
                <button type="button" id="ep-rm-forgot" style="font-size:12px;background:transparent;border:1px dashed #ea4335;color:#ea4335;padding:6px 12px;border-radius:6px;width:100%;cursor:pointer;font-weight:600;">🔑 Admin Forgot Password: Remove Protection</button>
               </div>`
            : '';
        const m = mkOverlay('ep-rmlock-modal', `
            <div class="pwd-modal-card">
                <div class="pwd-modal-header">
                    <h2 class="pwd-modal-title">Remove Protection</h2></div>
                <div class="pwd-modal-body">
                    <p class="pwd-modal-text">Enter the current password for <strong>${esc(vfsPath)}</strong> to remove folder protection.</p>
                    <form id="ep-rm-form" class="pwd-modal-form" autocomplete="off">
                        <input type="password" id="ep-rm-inp" class="pwd-modal-input" placeholder="Enter current password" required autofocus />
                        ${forgotHtml}
                        <div id="ep-rm-err" class="pwd-modal-error" style="display:none;">❌ Incorrect password. Lock removal denied.</div>
                        <div id="ep-rm-ld"  class="pwd-modal-loading" style="display:none;">⏳ Verifying password…</div>
                    </form>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-rm-cancel" type="button" class="pwd-modal-btn btn-secondary">Cancel</button>
                    <button type="submit" form="ep-rm-form" class="pwd-modal-btn btn-danger">Remove Protection</button>
                </div>
            </div>`);
        if (!m) return;
        const inp=m.querySelector('#ep-rm-inp'), err=m.querySelector('#ep-rm-err'),
              ld=m.querySelector('#ep-rm-ld'), sub=m.querySelector('[type="submit"]'),
              forgotBtn=m.querySelector('#ep-rm-forgot');
        if (forgotBtn) {
            forgotBtn.onclick = () => {
                m.remove();
                showAdminRemoveLock(vfsPath);
            };
        }
        setTimeout(() => inp && inp.focus(), 120);
        m.querySelector('#ep-rm-cancel').onclick = () => m.remove();
        m.querySelector('#ep-rm-form').onsubmit = e => {
            e.preventDefault();
            const pw = inp.value || '';
            if (!pw) return;
            err.style.display='none'; ld.style.display='block'; sub.disabled=true;
            rest('verifyAndRemovePassword', { vfsPath, currentPassword:pw })
            .then(r => {
                ld.style.display='none';
                if (r && r.success) {
                    clearCached(vfsPath); m.remove();
                    const t = Object.assign(document.createElement('div'), {
                        style:'position:fixed;bottom:24px;right:24px;background:#34a853;color:#fff;padding:12px 20px;border-radius:8px;font-size:13px;font-weight:600;z-index:99999999;box-shadow:0 4px 16px rgba(0,0,0,.3)',
                        textContent:'✅ Lock removed'
                    });
                    document.body.appendChild(t);
                    setTimeout(() => { t.remove(); refreshLocked().then(applyBadges); if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') HFS.reload(); else location.reload(); }, 600);
                } else {
                    err.textContent = (r && r.message) ? `❌ ${r.message}` : '❌ Incorrect password.';
                    err.style.display='block'; sub.disabled=false; inp.value=''; inp.focus();
                }
            })
            .catch(() => { ld.style.display='none'; sub.disabled=false; err.style.display='block'; inp.value=''; inp.focus(); });
        };
    };

    // ═══════════════════════════════════════════════════════════════
    //  MODAL: SET LOCK PASSWORD
    // ═══════════════════════════════════════════════════════════════
    const showSetLock = (vfsPath, isChange) => {
        const alreadyLocked = isLockedDirect(vfsPath) || isChange;
        const showCurrInput = alreadyLocked;

        const currHtml = showCurrInput
            ? '<input type="password" id="ep-sp-curr" class="pwd-modal-input" placeholder="Current folder password" required autocomplete="new-password"/>'
            : '';

        const m = mkOverlay('ep-setpwd-modal', `
            <div class="pwd-modal-card">
                <div class="pwd-modal-header">
                    <h2 class="pwd-modal-title">${alreadyLocked ? 'Change Lock Password' : 'Set Lock Password'}</h2></div>
                <div class="pwd-modal-body">
                    <p class="pwd-modal-text">Set a password for <strong>${esc(vfsPath)}</strong>.</p>
                    <form id="ep-sp-form" class="pwd-modal-form" autocomplete="off">
                        ${currHtml}
                        <input type="password" id="ep-sp-inp1" class="pwd-modal-input" placeholder="New folder password"      required autocomplete="new-password"/>
                        <input type="password" id="ep-sp-inp2" class="pwd-modal-input" placeholder="Confirm new password"  required autocomplete="new-password"/>
                        <div id="ep-sp-err" class="pwd-modal-error" style="display:none;"></div>
                        <div id="ep-sp-ld"  class="pwd-modal-loading" style="display:none;">⏳ Saving...</div>
                    </form>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-sp-cancel" type="button" class="pwd-modal-btn btn-secondary">Cancel</button>
                    <button id="ep-sp-sub"    type="submit" form="ep-sp-form" class="pwd-modal-btn btn-primary">Save Lock</button>
                </div>
            </div>`);
        if (!m) return;
        const i1=m.querySelector('#ep-sp-inp1'), i2=m.querySelector('#ep-sp-inp2'),
              err=m.querySelector('#ep-sp-err'), ld=m.querySelector('#ep-sp-ld'),
              sub=m.querySelector('#ep-sp-sub');
        setTimeout(() => i1 && i1.focus(), 120);
        m.querySelector('#ep-sp-cancel').onclick = () => m.remove();
        m.querySelector('#ep-sp-form').onsubmit = e => {
            e.preventDefault();
            const p1=i1.value.trim(), p2=i2.value.trim();
            if (!p1 || p1!==p2) { err.textContent = '❌ Passwords do not match.'; err.style.display='block'; return; }
            err.style.display='none'; ld.style.display='block'; sub.disabled=true;
            const currInp = m.querySelector('#ep-sp-curr');
            const params = { vfsPath, password:p1 };
            if (currInp && currInp.value) params.currentPassword = currInp.value;
            rest('setPassword', params)
            .then(r => {
                ld.style.display='none'; sub.disabled=false;
                if (r && r.success) {
                    m.remove();
                    window.enterpriseLockedPaths.add(normPath(vfsPath));
                    const t = Object.assign(document.createElement('div'), {
                        style:'position:fixed;bottom:24px;right:24px;background:#01a0e4;color:#fff;padding:12px 20px;border-radius:8px;font-size:13px;font-weight:600;z-index:99999999;box-shadow:0 4px 16px rgba(0,0,0,.3)',
                        textContent:'🔒 Lock set successfully'
                    });
                    document.body.appendChild(t);
                    setTimeout(() => { t.remove(); refreshLocked().then(applyBadges); if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') HFS.reload(); else location.reload(); }, 600);
                } else {
                    err.textContent = `❌ ${(r && r.message) || 'Unknown error'}`;
                    err.style.display='block';
                }
            })
            .catch(ex => { ld.style.display='none'; sub.disabled=false; err.textContent=`❌ ${ex}`; err.style.display='block'; });
        };
    };

    // ═══════════════════════════════════════════════════════════════
    //  SECTION A — TRACK LAST CLICKED ROW (FOLDER/FILE)
    //  Capture phase runs before HFS reacts.
    //  Stores the path of the entry whose menu was (likely) opened.
    // ═══════════════════════════════════════════════════════════════
    let _lastFolderPath = null;

    document.addEventListener('click', e => {
        // Accept any click inside any row-like element with a data-name / data-n
        const row = e.target.closest('[data-name],[data-n],tr[data-name],tr[data-n],[class*="entry"],[class*="Entry"],[class*="row"],[class*="Row"],[class*="item"],[class*="Item"]');
        if (!row) return;
        const rawName = row.getAttribute('data-name') || row.getAttribute('data-n')
                        || row.getAttribute('data-entry') || '';
        if (!rawName) return;
        const list  = (HFS.state && HFS.state.list) || [];
        const entry = list.find(x => nameKey(x.n) === nameKey(rawName));
        if (!entry) return;
        _lastFolderPath = entryPath(entry);
    }, true);

    // ═══════════════════════════════════════════════════════════════
    //  SECTION B — MULTI-FALLBACK PATH RESOLUTION
    //  Called when the menu dialog has opened.
    //  Returns the VFS path for the entry whose menu is open.
    // ═══════════════════════════════════════════════════════════════
    const findFolderNameInDialog = root => {
        if (!root || !root.querySelectorAll) return null;

        const attrEl = root.querySelector('[data-name],[data-n],[data-entry]');
        if (attrEl) {
            const rawName = attrEl.getAttribute('data-name') || attrEl.getAttribute('data-n') || attrEl.getAttribute('data-entry');
            if (rawName) return rawName;
        }

        const skip = new Set(['timestamp','creation','size','calculate','name','download','delete','rename','open','remove lock','set lock','cut','get list','comment','other','properties','details','zip','archive','copy','paste']);
        const texts = [];
        const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        while (tw.nextNode()) {
            const t = tw.currentNode.textContent.trim();
            if (t) texts.push(t);
        }

        const ni = texts.findIndex((t, i) => t.toLowerCase() === 'name' && texts[i + 1]);
        if (ni >= 0) {
            for (let j = ni + 1; j < texts.length; j++) {
                const candidate = texts[j].trim();
                if (!candidate) continue;
                const lower = candidate.toLowerCase();
                if (skip.has(lower)) continue;
                if (candidate.length > 200) break;
                if (/^\d{1,2}[\/\-]\d{1,2}[\/\-]/.test(candidate)) continue; // skip full date string
                return candidate; // Accepts numeric names like "146"!
            }
        }

        return null;
    };

    const resolveFolderPath = dialogRoot => {
        // 1️⃣ Extract name from dialog if available
        if (dialogRoot) {
            try {
                const folderName = findFolderNameInDialog(dialogRoot);
                if (folderName) {
                    const base = ((HFS.state && HFS.state.uri) || '/').replace(/\/?$/, '/');
                    const isFile = /\.[a-zA-Z0-9]{1,10}$/.test(folderName);
                    return `${base}${String(folderName).replace(/^\/|\/$/g, '')}${isFile ? '' : '/'}`;
                }
            } catch (_) {}
        }

        // 2️⃣ Pre-click capture
        if (_lastFolderPath) {
            return _lastFolderPath;
        }

        // 3️⃣ HFS state: currently selected entry
        try {
            const sel = HFS.state && (HFS.state.selected || HFS.state.selectedEntries);
            if (sel && sel.length === 1) {
                const en = sel[0];
                if (en) return entryPath(en);
            }
        } catch (_) {}

        return null;
    };

    // ═══════════════════════════════════════════════════════════════
    //  SECTION C — CLOSE DIALOG HELPER
    // ═══════════════════════════════════════════════════════════════
    const closeDialog = near => {
        const dlg = (near && near.closest('[role="dialog"],[class*="Dialog"],[class*="Modal"],[class*="Popover"]'))
                    || document.querySelector('[role="dialog"]');
        if (!dlg) { document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', bubbles:true })); return; }
        const closeBtn = dlg.querySelector('[aria-label="close" i],[aria-label="Close"],[class*="CloseButton"],[class*="closeButton"]');
        if (closeBtn) { closeBtn.click(); return; }
        const btns = Array.from(dlg.querySelectorAll('button'));
        const xBtn = btns.find(b => { const t=(b.textContent||'').trim(); return t==='✕'||t==='×'||t==='X'||t===''&&b.querySelector('svg'); });
        if (xBtn) { xBtn.click(); return; }
        document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', bubbles:true }));
    };

    // ═══════════════════════════════════════════════════════════════
    //  MODAL: SET STORAGE QUOTA
    // ═══════════════════════════════════════════════════════════════
    const showSetQuota = (vfsPath) => {
        const m = mkOverlay('ep-quota-modal', `
            <div class="pwd-modal-card">
                <div class="pwd-modal-header">
                    <h2 class="pwd-modal-title">Set Storage Quota</h2></div>
                <div class="pwd-modal-body">
                    <p class="pwd-modal-text">Enter the user and VFS path quota below.</p>
                    <form id="ep-q-form" class="pwd-modal-form" autocomplete="off">
                        <input type="text" id="ep-q-path" class="pwd-modal-input" placeholder="VFS Path (e.g. /hfspcm/)" value="${esc(vfsPath)}" required />
                        <input type="text" id="ep-q-user" class="pwd-modal-input" placeholder="Username" required />
                        <input type="number" id="ep-q-limit" class="pwd-modal-input" placeholder="Limit (MB)" value="1000" min="1" required />
                        <div id="ep-q-err" class="pwd-modal-error" style="display:none;"></div>
                        <div id="ep-q-ld"  class="pwd-modal-loading" style="display:none;">⏳ Saving...</div>
                    </form>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-q-cancel" type="button" class="pwd-modal-btn btn-secondary">Cancel</button>
                    <button id="ep-q-sub"    type="submit" form="ep-q-form" class="pwd-modal-btn btn-primary" style="display: inline-flex; align-items: center; justify-content: center; gap: 6px;"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>Save Quota</button>
                </div>
            </div>`);
        if (!m) return;
        const pathInput=m.querySelector('#ep-q-path'), user=m.querySelector('#ep-q-user'),
              limit=m.querySelector('#ep-q-limit'), err=m.querySelector('#ep-q-err'),
              ld=m.querySelector('#ep-q-ld'), sub=m.querySelector('#ep-q-sub');
        setTimeout(() => user && user.focus(), 120);
        m.querySelector('#ep-q-cancel').onclick = () => m.remove();
        m.querySelector('#ep-q-form').onsubmit = e => {
            e.preventDefault();
            const p = pathInput.value.trim();
            const u = user.value.trim();
            const lim = Number(limit.value);
            if (!p || !u || isNaN(lim) || lim < 1) return;
            err.style.display='none'; ld.style.display='block'; sub.disabled=true;
            
            // Call the storage-monitor setQuota REST API directly
            originalFetch('/~/api/_setQuota', {
                method: 'POST',
                headers: { 'content-type': 'application/json', 'x-hfs-anti-csrf': '1' },
                body: JSON.stringify({ vfsPath:p, username:u, limitMB:lim })
            })
            .then(r => r.json())
            .then(r => {
                ld.style.display='none'; sub.disabled=false;
                if (r && r.success) {
                    m.remove();
                    const t = Object.assign(document.createElement('div'), {
                        style:'position:fixed;bottom:24px;right:24px;background:#34a853;color:#fff;padding:12px 20px;border-radius:8px;font-size:13px;font-weight:600;z-index:99999999;box-shadow:0 4px 16px rgba(0,0,0,.3)',
                        textContent:'✅ Quota saved successfully'
                    });
                    document.body.appendChild(t);
                    setTimeout(() => { t.remove(); location.reload(); }, 1800);
                } else {
                    err.textContent = `❌ ${(r && r.message) || 'Unknown error'}`;
                    err.style.display='block';
                }
            })
            .catch(ex => { ld.style.display='none'; sub.disabled=false; err.textContent=`❌ ${ex}`; err.style.display='block'; });
        };
    };

    // ═══════════════════════════════════════════════════════════════
    //  SECTION D — INJECT SET LOCK & SET QUOTA BUTTONS INTO FOLDER MENU
    // ═══════════════════════════════════════════════════════════════
    const injectLockButton = root => {
        if (!root || !root.querySelectorAll) return false;
        if (root.querySelector('[data-ep-lock]')) return true; // already done

        // STEP 1 — Find the "Delete" text node
        let delTxt = null;
        const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        while (tw.nextNode()) {
            if (tw.currentNode.textContent.trim() === 'Delete') { delTxt = tw.currentNode; break; }
        }
        if (!delTxt) return false;

        // STEP 3 — Confirm it's the folder menu (Rename must also be present)
        if (!(root.textContent || '').includes('Rename')) return false;

        // STEP 2 — Walk up to clickable ancestor
        let delEl = delTxt.parentElement;
        for (let i = 0; i < 10; i++) {
            if (!delEl || delEl === root) { delEl = null; break; }
            const tag  = delEl.tagName || '';
            const role = delEl.getAttribute('role') || '';
            const tab  = delEl.getAttribute('tabindex');
            if (['A','BUTTON','LI'].includes(tag) || role==='button' || role==='menuitem' ||
                tab !== null || delEl.onclick) break;
            delEl = delEl.parentElement;
        }
        if (!delEl || delEl === root) return false;

        const actionsParent = delEl.parentElement;
        if (!actionsParent) return false;

        // STEP 4 — Resolve folder path
        const folderPath = resolveFolderPath(root);
        if (!folderPath) return false;

        const locked     = isLockedDirect(folderPath);

        // STEP 5 — Clone Delete → mutate into Set Lock / Remove Lock / Remove Folder Password
        const btn = delEl.cloneNode(true);
        btn.setAttribute('data-ep-lock', '1');
        btn.removeAttribute('href');

        // Remove any delete-related classes to prevent CSS icon injections
        const classesToRemove = Array.from(btn.classList).filter(c => 
            /delete|trash|remove|destroy|del/i.test(c)
        );
        for (const c of classesToRemove) {
            btn.classList.remove(c);
        }

        // Create the lock SVG icon
        const lockSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        lockSvg.setAttribute('viewBox', '0 0 24 24');
        lockSvg.setAttribute('fill', 'currentColor');

        const oldSvg = btn.querySelector('svg');
        if (oldSvg) {
            // Copy all attributes from the old SVG to preserve alignment, classes, etc.
            for (const attr of oldSvg.attributes) {
                lockSvg.setAttribute(attr.name, attr.value);
            }
            oldSvg.parentNode.replaceChild(lockSvg, oldSvg);
        } else {
            // Fallback styles if no SVG was found
            const oldIcons = btn.querySelectorAll('img, i, span.icon, span[class*="icon"], [class*="Icon"]');
            for (const icon of oldIcons) {
                icon.remove();
            }
            lockSvg.setAttribute('width', '24');
            lockSvg.setAttribute('height', '24');
            lockSvg.style.marginRight = '0.75em';
            lockSvg.style.flexShrink = '0';
            btn.insertBefore(lockSvg, btn.firstChild);
        }
        lockSvg.innerHTML = '<path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>';

        // Update the "Delete" text inside the clone
        const isAdmin = isCurrentUserAdmin();
        const cloneTw = document.createTreeWalker(btn, NodeFilter.SHOW_TEXT);
        while (cloneTw.nextNode()) {
            if (cloneTw.currentNode.textContent.trim() === 'Delete') {
                cloneTw.currentNode.textContent = locked
                    ? (isAdmin ? 'Admin Remove Folder Password' : 'Remove Lock')
                    : 'Set Lock';
                break;
            }
        }
        // Colour cue
        btn.style.setProperty('color', locked ? '#ea4335' : '#01a0e4', 'important');
        btn.style.cursor = 'pointer';

        btn.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
            closeDialog(btn);
            const p = folderPath;
            setTimeout(() => {
                if (locked) {
                    if (isAdmin) {
                        showAdminRemoveLock(p);
                    } else {
                        showRemoveLock(p);
                    }
                } else {
                    showSetLock(p, false);
                }
            }, 220);
        }, true);

        const disableOtherMenuActions = () => {
            const candidates = Array.from(actionsParent.querySelectorAll('a, button, [role="menuitem"], [role="option"], li'));
            const keep = new Set([btn, delEl]);
            for (const element of candidates) {
                if (keep.has(element)) continue;
                const text = (element.textContent || '').trim().toLowerCase();
                const aria = (element.getAttribute && String(element.getAttribute('aria-label') || '')).toLowerCase();
                const isClose = text === 'close' || text === '✕' || text === '×' || text === 'x' || aria.includes('close');
                if (isClose) continue;
                element.style.pointerEvents = 'none';
                element.style.opacity = '0.32';
                element.style.color = '#8a8a8a';
                element.setAttribute('aria-disabled', 'true');
                if (element.tabIndex >= 0) element.tabIndex = -1;
                if (element.tagName === 'A') element.removeAttribute('href');
                if (element.tagName === 'BUTTON') element.disabled = true;
                element.title = 'Disabled while folder is locked';
            }
        };

        if (locked) {
            disableOtherMenuActions();
        }

        // Insert immediately before the Delete button
        actionsParent.insertBefore(btn, delEl);

        return true; // ← injection succeeded
    };

    // ── Retry wrapper: tries up to 6 times, 300 ms apart ────────
    const injectWithRetry = (root, attempt = 0) => {
        if (attempt > 6) return;
        const ok = injectLockButton(root);
        if (!ok) setTimeout(() => injectWithRetry(root, attempt + 1), 300);
    };

    // ── MutationObserver: fires on every new DOM node ────────────
    new MutationObserver(mutations => {
        for (const m of mutations) {
            for (const n of m.addedNodes) {
                if (n.nodeType !== 1) continue;
                setTimeout(() => injectWithRetry(n), 100);
            }
        }
    }).observe(document.body, { childList: true, subtree: true });

    // ── Periodic scanner: catches any dialog that the observer missed ─
    setInterval(() => {
        document.querySelectorAll('[role="dialog"],[class*="Dialog"]').forEach(dlg => {
            if (!dlg.querySelector('[data-ep-lock]')) injectLockButton(dlg);
        });
    }, 400);

    // ═══════════════════════════════════════════════════════════════
    //  SECTION E — fileMenu EVENT
    //  In HFS 3.2.1, props.push() adds to the LEFT (properties)
    //  column only. We use it to show a visual lock indicator.
    //  The actual clickable button is injected via Section D above.
    // ═══════════════════════════════════════════════════════════════
    if (typeof HFS !== 'undefined' && typeof HFS.onEvent === 'function') {
        HFS.onEvent('fileMenu', ({ entry, props }) => {
            if (!entry || !props) return;
            const isFolder = entry.isFolder || /\/$/.test(entry.n || '');
            const path = entryPath(entry);
            _lastFolderPath = path; // also capture via event for reliability
            if (isLocked(path)) {
                props.push({ label: isFolder ? '🔒 This folder is LOCKED' : '🔒 This file is LOCKED' });
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════
    //  SECTION F — FETCH INTERCEPTOR
    //  • Catches 403 "locked" on GET → shows unlock modal
    //  • Catches 403 "locked" on DELETE → shows delete auth modal
    // ═══════════════════════════════════════════════════════════════
    const isSameOriginApi = urlStr => {
        try {
            const parsed = new URL(urlStr, location.href);
            const path = parsed.pathname;
            return parsed.origin === location.origin && (path.startsWith('/~/api/') || path.startsWith('/api/'));
        } catch (_) {
            return false;
        }
    };

    const extractLockedUrl = urlStr => {
        try {
            const parsed = new URL(urlStr, location.href);
            if (parsed.origin !== location.origin) return null;
            let targetPath = parsed.pathname.replace(/\\/g, '/');
            if (targetPath.startsWith('/~/api/')) {
                const param = parsed.searchParams.get('uri') || parsed.searchParams.get('uris') || parsed.searchParams.get('path');
                if (param) {
                    try {
                        const jsonVal = JSON.parse(param);
                        targetPath = Array.isArray(jsonVal) ? jsonVal[0] : String(jsonVal);
                    } catch (_) {
                        targetPath = param.split(',')[0];
                    }
                }
            }
            return isLocked(targetPath);
        } catch (_) {
            return null;
        }
    };

    const isJsonResponse = response => {
        if (!response || !response.headers || typeof response.headers.get !== 'function') return false;
        const ct = response.headers.get('content-type') || '';
        return /\bjson\b/i.test(ct);
    };

    const parseResponseJson = response => {
        if (!isJsonResponse(response)) return Promise.reject(new Error('Non-JSON response'));
        return response.clone().json();
    };

    const showErrorModal = (title, message) => {
        const m = mkOverlay('ep-error-modal', `
            <div class="pwd-modal-card border-danger" style="border: 2px solid #ea4335;">
                <div class="pwd-modal-header" style="border-bottom: 1px solid #ea4335; padding-bottom: 10px;">
                    <h2 class="pwd-modal-title" style="color: #ea4335;">${esc(title)}</h2></div>
                <div class="pwd-modal-body" style="padding-top: 15px;">
                    <p class="pwd-modal-text" style="color: #f1f1f1; font-weight: 500;">${esc(message)}</p>
                </div>
                <div class="pwd-modal-footer">
                    <button id="ep-err-ok" type="button" class="pwd-modal-btn btn-danger" style="background-color: #ea4335; border-color: #ea4335;">OK</button>
                </div>
            </div>`);
        if (!m) return;
        m.querySelector('#ep-err-ok').onclick = () => m.remove();
    };

    const collectLockedPathsForDelete = (primaryPath) => {
        const list = [];
        if (primaryPath) {
            const normPrimary = normPath(primaryPath);
            const l = isLocked(normPrimary);
            if (l) list.push(l);
            else list.push(normPrimary);
        }
        try {
            const sel = (HFS.state && (HFS.state.selected || HFS.state.selectedEntries)) || [];
            if (Array.isArray(sel)) {
                for (const item of sel) {
                    const ep = entryPath(item);
                    const l = isLocked(ep);
                    if (l) list.push(l);
                    else list.push(normPath(ep));
                }
            }
        } catch (_) {}
        return [...new Set(list.filter(Boolean).map(normPath))];
    };

    const showSequentialDeleteAuth = (lockedPaths, onAllOk, onCancel) => {
        if (!lockedPaths || lockedPaths.length === 0) {
            onAllOk();
            return;
        }
        let idx = 0;
        const next = () => {
            if (idx >= lockedPaths.length) {
                onAllOk();
                return;
            }
            const currentPath = lockedPaths[idx];
            showDeleteAuth(currentPath, () => {
                idx++;
                next();
            }, () => {
                if (typeof onCancel === 'function') onCancel();
                else location.reload();
            });
        };
        next();
    };

    const refreshLockedPathsCache = () => {
        refreshLocked();
    };

    window.fetch = function(url, options) {
        const urlStr = typeof url === 'string' ? url : (url && url.url) || '';
        if (urlStr.includes('login') || urlStr.includes('logout') || urlStr.includes('auth')) {
            if (urlStr.includes('logout')) {
                try { sessionStorage.removeItem(SS_KEY); } catch (_) {}
                const p = originalFetch(url, options);
                p.then(() => {
                    if (window.location.pathname !== '/' && window.location.pathname !== '') {
                        setTimeout(() => { window.location.href = window.location.origin + '/'; }, 100);
                    }
                }).catch(() => {
                    if (window.location.pathname !== '/' && window.location.pathname !== '') {
                        setTimeout(() => { window.location.href = window.location.origin + '/'; }, 100);
                    }
                });
                return p;
            }
            return originalFetch(url, options);
        }
        return originalFetch(url, options).then(response => {
            if (response.ok) {
                const method = ((options && options.method) || 'GET').toUpperCase();
                const isRenameOrMove = urlStr.includes('/rename') || urlStr.includes('/move') || urlStr.includes('/cut') || urlStr.includes('/paste');
                if (isRenameOrMove || method === 'POST' || method === 'PUT' || method === 'DELETE') {
                    setTimeout(refreshLockedPathsCache, 400);
                }
            }
            if (response.status === 403) {
                const urlStr = typeof url === 'string' ? url : (url && url.url) || '';
                const method = ((options && options.method) || 'GET').toUpperCase();
                const isDel  = method === 'DELETE' || (method === 'POST' && (
                    urlStr.includes('/api/delete') || urlStr.includes('/api/_delete') || urlStr.includes('/_delete') || urlStr.includes('delete')
                ));
                const isHfsApi = isSameOriginApi(urlStr);
                // lockedPath from local cache (may be null if cache is empty)
                let lockedPath = extractLockedUrl(urlStr);

                // ── CACHE-MISS FALLBACK ───────────────────────────────────────
                // If local cache doesn't know about this path (e.g. _getLockedPaths
                // returned 400 for unauthenticated users), extract the path directly
                // from the request URL so we can still show the unlock modal.
                if (!lockedPath && isHfsApi) {
                    try {
                        const parsedUrl = new URL(urlStr, location.href);
                        // get_file_list?uri=/some/path/  OR  ?uris=[...]
                        const uriParam = parsedUrl.searchParams.get('uri') ||
                                         parsedUrl.searchParams.get('uris') ||
                                         parsedUrl.searchParams.get('path');
                        if (uriParam) {
                            const candidate = normPath(uriParam);
                            if (candidate && candidate !== '/') {
                                lockedPath = candidate;
                                // Also add to cache so subsequent requests work
                                window.enterpriseLockedPaths.add(candidate);
                            }
                        }
                    } catch(_) {}
                }

                if (isHfsApi) {
                    return parseResponseJson(response).then(data => {
                        if (data && data.error === 'locked') {
                            if (data.reason === 'child_is_locked') {
                                showErrorModal('Deletion Denied', data.message || 'Cannot delete because a child folder is locked.');
                                return response;
                            }
                            const lockTarget = data.path || lockedPath;
                            if (lockTarget) {
                                clearCached(lockTarget);
                                // Add to local cache so future clicks work immediately
                                window.enterpriseLockedPaths.add(normPath(lockTarget));
                                const continueRequest = () => originalFetch(url, options);
                                if (isDel || (data.reason === 'delete_requires_auth')) {
                                    const allDeletePaths = collectLockedPathsForDelete(lockTarget);
                                    return new Promise((resolve, reject) => {
                                        showSequentialDeleteAuth(allDeletePaths, () => continueRequest().then(resolve).catch(reject), () => location.reload());
                                    });
                                } else {
                                    return new Promise((resolve, reject) => {
                                        showUnlock(lockTarget, () => continueRequest().then(resolve).catch(reject), () => resolve(response), isDel ? 'Confirm Delete' : undefined);
                                    });
                                }
                            }
                        } else if (lockedPath) {
                            // 403 but error is not 'locked' in JSON — still show unlock
                            // (happens when cache was empty and server blocked access)
                            clearCached(lockedPath);
                            window.enterpriseLockedPaths.add(normPath(lockedPath));
                            const continueRequest = () => originalFetch(url, options);
                            if (isDel) {
                                const allDeletePaths = collectLockedPathsForDelete(lockedPath);
                                return new Promise((resolve, reject) => {
                                    showSequentialDeleteAuth(allDeletePaths, () => continueRequest().then(resolve).catch(reject), () => location.reload());
                                });
                            }
                            return new Promise((resolve, reject) => {
                                showUnlock(lockedPath, () => continueRequest().then(resolve).catch(reject), () => resolve(response));
                            });
                        }
                        return response;
                    }).catch(() => {
                        if (isDel && lockedPath) {
                            clearCached(lockedPath);
                            const allDeletePaths = collectLockedPathsForDelete(lockedPath);
                            return new Promise((resolve, reject) => {
                                showSequentialDeleteAuth(allDeletePaths, () => originalFetch(url, options).then(resolve).catch(reject), () => location.reload());
                            });
                        } else if (lockedPath) {
                            clearCached(lockedPath);
                            window.enterpriseLockedPaths.add(normPath(lockedPath));
                            return new Promise((resolve, reject) => {
                                showUnlock(lockedPath, () => originalFetch(url, options).then(resolve).catch(reject), () => resolve(response));
                            });
                        }
                        return response;
                    });
                } else if (isDel && lockedPath) {
                    clearCached(lockedPath);
                    const allDeletePaths = collectLockedPathsForDelete(lockedPath);
                    return new Promise((resolve, reject) => {
                        showSequentialDeleteAuth(allDeletePaths, () => originalFetch(url, options).then(resolve).catch(reject), () => location.reload());
                    });
                } else if (lockedPath) {
                    clearCached(lockedPath);
                    return new Promise((resolve, reject) => {
                        showUnlock(lockedPath, () => originalFetch(url, options).then(resolve).catch(reject), () => resolve(response));
                    });
                }
            }
            return response;
        }).catch(err => {
            if (!navigator.onLine || (err && (err.name === 'TypeError' || err.message === 'Failed to fetch'))) {
                return new Response(JSON.stringify({ error: 'offline', message: 'System offline' }), {
                    status: 503,
                    headers: { 'content-type': 'application/json' }
                });
            }
            throw err;
        });
    };



    const extractLockedUriFromAnchor = href => {
        if (!href || href.startsWith('#')) return null;
        const normalizedHref = String(href).trim();
        if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\s*$/.test(normalizedHref)) return null;
        try {
            const url = new URL(href, location.href);
            if (url.origin !== location.origin) return null;
            if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;

            if (url.pathname.startsWith('/~/api/')) {
                const uri = url.searchParams.get('uri');
                if (uri) return uri;
                const uris = url.searchParams.get('uris');
                if (uris) {
                    try { const parsed = JSON.parse(uris); return Array.isArray(parsed) ? parsed[0] : uris.split(',')[0]; }
                    catch (_) { return uris.split(',')[0]; }
                }
                return null;
            }

            if (url.pathname.startsWith('/~/')) return null;
            return url.pathname.replace(/\\/g, '/');
        } catch (_) {
            return null;
        }
    };

    let __fpIgnoreClick = false;
    const triggerOriginalClick = element => {
        if (!element || typeof element.click !== 'function') return;
        __fpIgnoreClick = true;
        element.click();
        setTimeout(() => { __fpIgnoreClick = false; }, 300);
    };

    const findFirstUnauthorizedLockInSelection = targetPath => {
        if (targetPath) {
            const lock = getRequiredLock(targetPath);
            if (lock && !isCached(lock)) return lock;
        }

        try {
            const selected = HFS.state && (HFS.state.selected || HFS.state.selectedEntries);
            if (Array.isArray(selected) && selected.length > 0) {
                for (const item of selected) {
                    const ep = entryPath(item);
                    const lock = getRequiredLock(ep);
                    if (lock && !isCached(lock)) return lock;
                }
            }
        } catch (_) {}

        const currentLock = getRequiredLock(getCurrentUri());
        if (currentLock && !isCached(currentLock)) return currentLock;

        return null;
    };

    document.addEventListener('click', e => {
        if (__fpIgnoreClick || e.button !== 0 || e.defaultPrevented || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
        const clickable = e.target.closest('a[href],button,[data-href],[data-uri],[data-url],[onclick],[role="menuitem"],[role="option"],li,tr,[class*="item" i],[class*="Item" i],[class*="button" i],[class*="Button" i],div,span');
        if (!clickable) return;

        // Skip our own modal overlay elements
        if (clickable.closest('.pwd-modal-overlay')) return;

        const txt = (clickable.textContent || '').trim().toLowerCase();
        const label = (clickable.getAttribute('aria-label') || clickable.getAttribute('title') || '').toLowerCase();
        let href = clickable.getAttribute('href') || clickable.dataset.href || clickable.dataset.uri || clickable.dataset.url;
        if (!href && clickable.hasAttribute && clickable.hasAttribute('onclick')) {
            const onclick = String(clickable.getAttribute('onclick') || '');
            const match = onclick.match(/['"]([^'"\s]+)['"]/);
            href = match ? match[1] : href;
        }

        /* ═══════════════════════════════════════════════════════════
           FIX: never block logout — works even inside locked folders
           Enhanced detection: check aria/title/text, href, onclick content,
           and common data/class selectors used for logout buttons.
           ═══════════════════════════════════════════════════════════ */
        const isLogoutBtn = (
            txt === 'logout' || txt === 'log out' || txt === 'sign out' || txt === 'sign-off' ||
            label.includes('logout') || label.includes('sign out') || label.includes('sign-off') ||
            (href && (href.includes('/logout') || href.includes('/api/logout') || href.includes('/~/api/logout'))) ||
            clickable.closest('[data-logout],[data-hfs-logout],[data-signout],[data-user-logout],.user-logout,.logout-btn,.signout-btn,.sign-out')
        );
        // Also inspect inline onclick handlers for a logout-like function name or URL
        try {
            if (!isLogoutBtn && clickable.hasAttribute && clickable.hasAttribute('onclick')) {
                const oc = String(clickable.getAttribute('onclick') || '').toLowerCase();
                if (oc.includes('logout') || oc.includes('signout') || oc.includes('/api/logout')) {
                    try { sessionStorage.removeItem(SS_KEY); } catch (_) {}
                    if (window.location.pathname !== '/' && window.location.pathname !== '') {
                        setTimeout(() => { window.location.href = window.location.origin + '/'; }, 150);
                    }
                    return;
                }
            }
        } catch (_) {}
        if (isLogoutBtn) {
            try { sessionStorage.removeItem(SS_KEY); } catch (_) {}
            if (window.location.pathname !== '/' && window.location.pathname !== '') {
                setTimeout(() => { window.location.href = window.location.origin + '/'; }, 150);
            }
            return;
        }
        /* ═══════════════════════════════════════════════════════════ */

        const getActionSubmitLabel = (txt, label, href) => {
            const t = (txt || '').toLowerCase();
            const l = (label || '').toLowerCase();
            const h = (href || '').toLowerCase();

            if (t.includes('download') || l.includes('download') || h.includes('download')) return 'Confirm Download';
            if (t.includes('comment')  || l.includes('comment'))  return 'Confirm Comment';
            if (t.includes('open')     || l.includes('open'))     return 'Confirm Open';
            if (t.includes('delete')   || l.includes('delete'))   return 'Confirm Delete';
            if (t.includes('rename')   || l.includes('rename'))   return 'Confirm Rename';
            if (t.includes('cut')      || l.includes('cut'))      return 'Confirm Cut';
            if (t.includes('list')     || l.includes('list'))     return 'Confirm Get List';
            if (t.includes('zip') || t.includes('archive') || l.includes('zip') || l.includes('archive') || h.includes('zip') || h.includes('archive')) return 'Confirm Download';
            return undefined;
        };

        // ── 1. CONTEXT MENU DIALOG ACTION INTERCEPTION (ALL MENU OPTIONS) ─────
        const dialog = clickable.closest('[role="dialog"],[class*="Dialog"],[class*="Menu"],[class*="popover" i],[class*="Popover" i],[class*="paper" i],[class*="Paper" i]');
        if (dialog) {
            // Target ONLY specific action item elements (button, link, menuitem, li)
            const actionEl = e.target.closest('a, button, [role="menuitem"], [role="option"], li, [data-action], [class*="MenuItem" i], [class*="menuItem" i], [class*="menu-item" i]');
            if (!actionEl) return; // User clicked outside an action button, backdrop, or header area

            const isCustomLockBtn = !!actionEl.closest('[data-ep-lock],[data-ep-quota]');
            const isCloseBtn = label === 'close' || txt === '✕' || txt === '×' || txt === 'x';

            if (!isCustomLockBtn && !isCloseBtn) {
                // Ensure text is from the single action element, not a container with child nodes
                const itemTxt = (actionEl.textContent || '').trim().toLowerCase();
                const itemLabel = (actionEl.getAttribute('aria-label') || actionEl.getAttribute('title') || '').toLowerCase();

                // If element text is too long, it is a wrapper container, not an action button
                if (itemTxt.length > 50) return;

                const isDel = itemTxt === 'delete' || /^delete\b/i.test(itemTxt) || itemLabel === 'delete' || !!actionEl.closest('[class*="delete" i],[data-action="delete" i]');
                const isDownload = itemTxt.includes('download') || itemLabel.includes('download');
                const isComment = itemTxt.includes('comment') || itemLabel.includes('comment');
                const isOpen = itemTxt === 'open' || /^open\b/i.test(itemTxt) || itemLabel === 'open';
                const isRename = itemTxt.includes('rename') || itemLabel.includes('rename');
                const isCut = itemTxt === 'cut' || /^cut\b/i.test(itemTxt) || itemLabel === 'cut';
                const isGetList = itemTxt.includes('get list') || itemTxt === 'list' || itemLabel.includes('list');

                const isActionItem = isDel || isDownload || isComment || isOpen || isRename || isCut || isGetList;
                if (!isActionItem) return; // Ignore click-outside, header info, or non-action elements

                const folderPath = resolveFolderPath(dialog) || _lastFolderPath;
                const lock = isLocked(folderPath) || (folderPath && isLocked(folderPath));

                // If the folder itself is NOT directly locked, but its parent IS locked
                // and the parent lock is already cached (authorized), allow the action.
                const isDirectLock = folderPath && isLockedDirect(folderPath);
                if (lock && !isDirectLock && isCached(lock)) {
                    // Unlocked child inside authorized parent — let action through
                } else if (lock) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    const targetEl = actionEl;

                    if (isDel) {
                        setDeletePending();
                        // Capture the folder path BEFORE closing the dialog,
                        // because closeDialog() removes targetEl from the DOM.
                        const pathToDelete = folderPath;
                        closeDialog(targetEl);
                        showDeleteAuth(lock, () => {
                            // Call HFS native HTTP DELETE on the target path.
                            // Server middleware will verify the delete_auth_ token.
                            originalFetch(pathToDelete, {
                                method: 'DELETE',
                                headers: {
                                    'x-hfs-anti-csrf': '1'
                                },
                                credentials: 'same-origin'
                            }).then(r => {
                                clearCached(pathToDelete);
                                if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') {
                                    HFS.reload();
                                } else {
                                    location.reload();
                                }
                            }).catch(() => {
                                location.reload();
                            });
                        });
                        return;
                    }

                    const btnTitle = getActionSubmitLabel(itemTxt, itemLabel, href);
                    showUnlock(lock, () => {
                        triggerOriginalClick(targetEl);
                        setTimeout(() => closeDialog(targetEl), 150);
                    }, () => {}, btnTitle, true /* isMenuAction */);
                    return;
                }
            }
        }

        // ── 2. TOOLBAR / NAVIGATION ACTION INTERCEPTION (DOWNLOAD, COMMENT, OPEN, DELETE, RENAME, CUT, GET LIST, ZIP) ──
        // GUARD: only intercept real interactive elements, not plain div/span backdrops.
        // When the user clicks outside a dialog menu, the event.target is a backdrop div
        // whose textContent contains all menu words ("delete", "list", etc.) causing false triggers.
        const isRealInteractive = (
            clickable.tagName === 'BUTTON' ||
            clickable.tagName === 'A' ||
            clickable.getAttribute('role') === 'menuitem' ||
            clickable.getAttribute('role') === 'option' ||
            clickable.getAttribute('role') === 'button' ||
            clickable.tagName === 'LI' ||
            clickable.tagName === 'TR' ||
            clickable.hasAttribute('data-href') ||
            clickable.hasAttribute('data-uri') ||
            clickable.hasAttribute('data-url') ||
            clickable.hasAttribute('onclick') ||
            clickable.hasAttribute('data-action') ||
            (clickable.tabIndex >= 0 && clickable.tabIndex !== -1)
        );
        if (!isRealInteractive) {
            // Not a real button/link — skip Section 2 entirely.
            // This prevents clicks on the backdrop/overlay/info-panel from
            // accidentally triggering the delete/rename modal.
        } else {

        const isRenameBtn   = txt.includes('rename') || label.includes('rename');
        const isCutBtn      = txt.includes('cut') || label.includes('cut');
        const isZipBtn      = txt.includes('zip') || txt.includes('archive') || label.includes('zip') || label.includes('archive') || (href && (href.includes('zip') || href.includes('archive')));
        const isDeleteBtn   = txt.includes('delete') || label.includes('delete');
        const isDownloadBtn = txt.includes('download') || label.includes('download');
        const isCommentBtn  = txt.includes('comment') || label.includes('comment');
        const isGetListBtn  = txt.includes('get list') || txt.includes('list') || label.includes('get list') || label.includes('list');

        if (isRenameBtn || isCutBtn || isZipBtn || isDeleteBtn || isDownloadBtn || isCommentBtn || isGetListBtn) {
            const lock = isLocked(_lastFolderPath) || findFirstUnauthorizedLockInSelection(_lastFolderPath);

            // If the folder itself is NOT directly locked, but its parent IS locked
            // and the parent lock is already cached (authorized), let the action through.
            const isDirectLock = _lastFolderPath && isLockedDirect(_lastFolderPath);
            const skipAuth = lock && !isDirectLock && isCached(lock);

            if (lock && !skipAuth) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                const targetEl = clickable;
                if (isDeleteBtn) {
                    setDeletePending();
                    const targetPath = _lastFolderPath || findFirstUnauthorizedLockInSelection(_lastFolderPath);
                    showDeleteAuth(lock, () => {
                        const selectedUris = [];
                        try {
                            const sel = HFS.state && (HFS.state.selected || HFS.state.selectedEntries);
                            if (Array.isArray(sel) && sel.length > 0) {
                                for (const item of sel) {
                                    selectedUris.push(entryPath(item));
                                }
                            }
                        } catch (_) {}
                        const urisToDelete = selectedUris.length > 0 ? selectedUris : (targetPath ? [targetPath] : [lock]);
                        
                        Promise.all(urisToDelete.map(uri => 
                            originalFetch(uri, {
                                method: 'DELETE',
                                headers: {
                                    'x-hfs-anti-csrf': '1'
                                },
                                credentials: 'same-origin'
                            })
                        )).then(() => {
                            urisToDelete.forEach(clearCached);
                            if (typeof HFS !== 'undefined' && typeof HFS.reload === 'function') {
                                HFS.reload();
                            } else {
                                location.reload();
                            }
                        }).catch(() => {
                            location.reload();
                        });
                    });
                    return;
                }
                const btnTitle = getActionSubmitLabel(txt, label, href);
                showUnlock(lock, () => { triggerOriginalClick(targetEl); }, () => {}, btnTitle, true /* isMenuAction */);
                return;
            }
        }

        } // end isRealInteractive

        // ── 3. GENERAL LINK & ANCHOR INTERCEPTION ──────────────────────────────
        const targetUri = extractLockedUriFromAnchor(href);
        if (!targetUri) return;

        const lock = getRequiredLock(targetUri);
        if (!lock || isCached(lock)) return;

        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        const targetEl = clickable;
        showUnlock(lock, () => { triggerOriginalClick(targetEl); });
    }, true);

    if (window.XMLHttpRequest) {
        const originalXHROpen = window.XMLHttpRequest.prototype.open;
        const originalXHRSend = window.XMLHttpRequest.prototype.send;
        const originalXHRSetRequestHeader = window.XMLHttpRequest.prototype.setRequestHeader;

        window.XMLHttpRequest.prototype.open = function(method, url) {
            try {
                this._fpMethod = (method || 'GET').toUpperCase();
                this._fpUrl = String(url || '');
                if (this._fpUrl.includes('/api/logout')) {
                    sessionStorage.removeItem(SS_KEY);
                }
            } catch (_) {
                this._fpMethod = 'GET';
                this._fpUrl = '';
            }
            this._fpHeaders = this._fpHeaders || {};
            return originalXHROpen.apply(this, arguments);
        };

        window.XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
            try {
                this._fpHeaders = this._fpHeaders || {};
                this._fpHeaders[name] = value;
            } catch (_) {}
            return originalXHRSetRequestHeader.apply(this, arguments);
        };

        window.XMLHttpRequest.prototype.send = function(body) {
            this._fpBody = body;
            if (this._fpUrl && (this._fpUrl.includes('login') || this._fpUrl.includes('logout') || this._fpUrl.includes('auth'))) {
                if (this._fpUrl.includes('logout')) {
                    try { sessionStorage.removeItem(SS_KEY); } catch (_) {}
                    this.addEventListener('loadend', function() {
                        if (window.location.pathname !== '/' && window.location.pathname !== '') {
                            setTimeout(() => { window.location.href = window.location.origin + '/'; }, 100);
                        }
                    });
                }
                return originalXHRSend.apply(this, arguments);
            }
            const lockedPath = extractLockedUrl(this._fpUrl);
            const isDel = this._fpMethod === 'DELETE' || (this._fpMethod === 'POST' && this._fpUrl.includes('/api/delete'));
            if (isSameOriginApi(this._fpUrl) || lockedPath || isDel) {
                this.addEventListener('load', function() {
                    if (this.status !== 403) return;
                    const contentType = this.getResponseHeader('content-type') || '';
                    if (isSameOriginApi(this._fpUrl) && /\bjson\b/i.test(contentType)) {
                        try {
                            const data = JSON.parse(this.responseText || '{}');
                            if (data && data.error === 'locked') {
                                if (data.reason === 'child_is_locked') {
                                    showErrorModal('Deletion Denied', data.message || 'Cannot delete because a child folder is locked.');
                                } else if (data.path) {
                                    clearCached(data.path);
                                    const continueRequest = () => {
                                        originalFetch(this._fpUrl, {
                                            method: this._fpMethod,
                                            headers: this._fpHeaders,
                                            body: this._fpBody,
                                            credentials: 'same-origin'
                                        }).catch(() => {});
                                    };
                                    if (isDel || data.reason === 'delete_requires_auth') {
                                        showDeleteAuth(data.path, continueRequest, () => {});
                                    } else {
                                        showUnlock(data.path, continueRequest, () => {}, isDel ? 'Confirm Delete' : undefined);
                                    }
                                }
                            }
                        } catch (_) {}
                    } else if (isDel && lockedPath) {
                        clearCached(lockedPath);
                        showDeleteAuth(lockedPath, () => {
                            originalFetch(this._fpUrl, {
                                method: this._fpMethod,
                                headers: this._fpHeaders,
                                body: this._fpBody,
                                credentials: 'same-origin'
                            }).catch(() => {});
                        }, () => {});
                    } else if (lockedPath) {
                        clearCached(lockedPath);
                        showUnlock(lockedPath, () => {
                            originalFetch(this._fpUrl, {
                                method: this._fpMethod,
                                headers: this._fpHeaders,
                                body: this._fpBody,
                                credentials: 'same-origin'
                            }).catch(() => {});
                        }, () => {});
                    }
                });
            }
            return originalXHRSend.apply(this, arguments);
        };
    }


    // ═══════════════════════════════════════════════════════════════
    //  SECTION G — FOLDER ROW CLICK INTERCEPTOR
    //  Intercepts direct clicks on locked folder rows (not menu icon)
    //  and shows the unlock modal before navigating.
    // ═══════════════════════════════════════════════════════════════
    const isActionOrCheckbox = t => !!t.closest('[aria-haspopup="true"], [role="checkbox"], input[type="checkbox"], [data-menu]');

    document.addEventListener('click', e => {
        if (__fpIgnoreClick || e.button!==0 || e.defaultPrevented || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
        if (isActionOrCheckbox(e.target)) return;
        const row = e.target.closest('[data-name],[data-n],tr[data-name],tr[data-n]');
        if (!row) return;
        const rawName = row.getAttribute('data-name') || row.getAttribute('data-n');
        const list  = (HFS.state && HFS.state.list) || [];
        const entry = list.find(x => nameKey(x.n) === nameKey(rawName));
        if (!entry) return;
        const ep   = entryPath(entry);
        const lock = getRequiredLock(ep);
        if (!lock) return;



        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        const clickedEl = e.target;
        showUnlock(lock, () => {
            triggerOriginalClick(clickedEl);
        });
    }, true);

    // ═══════════════════════════════════════════════════════════════
    //  SECTION H — LOCK BADGES ON FILE ROWS
    // ═══════════════════════════════════════════════════════════════
    const applyBadges = () => {
        document.querySelectorAll('[data-name],[data-n],tr[data-name],tr[data-n]').forEach(row => {
            const nm = row.getAttribute('data-name') || row.getAttribute('data-n');
            const list = (HFS.state && HFS.state.list) || [];
            const en = list.find(x => nameKey(x.n) === nameKey(nm));
            if (!en) return;
            if (isLocked(entryPath(en))) row.classList.add('enterprise-row-locked');
            else row.classList.remove('enterprise-row-locked');
        });
    };
    new MutationObserver(applyBadges).observe(document.body, { childList: true, subtree: true });

    // ═══════════════════════════════════════════════════════════════
    //  SECTION I — HIDE DELETE & CUT BUTTONS IN MULTI-SELECT TOOLBAR
    // ═══════════════════════════════════════════════════════════════
    const hideSelectionDeleteAndCut = () => {
        // Ensure "Select" buttons and checkboxes are always unhidden and visible
        document.querySelectorAll('button, [role="button"], a, input[type="checkbox"], [role="checkbox"], [class*="select" i], [class*="Select" i]').forEach(el => {
            const txt = (el.textContent || '').trim().toLowerCase();
            const label = (el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase();
            if (txt.includes('select') || label.includes('select') || el.type === 'checkbox' || el.getAttribute('role') === 'checkbox') {
                el.style.removeProperty('display');
                el.style.removeProperty('visibility');
                const btn = el.closest('button, [role="button"], a, li');
                if (btn) {
                    btn.style.removeProperty('display');
                    btn.style.removeProperty('visibility');
                }
            }
        });

        // Hide ONLY Cut and Delete buttons in nav bar / toolbar
        const selectors = [
            '[role="toolbar"]',
            '[class*="toolbar" i]',
            '[class*="Toolbar" i]',
            '[class*="batch" i]',
            '[class*="Batch" i]',
            '[class*="actions" i]',
            '[class*="Actions" i]',
            '[class*="nav" i]',
            '[class*="Nav" i]'
        ];
        
        selectors.forEach(sel => {
            document.querySelectorAll(sel).forEach(container => {
                const els = container.querySelectorAll('button, [role="button"], a, [tabindex], div, span');
                els.forEach(el => {
                    const txt = (el.textContent || '').trim().toLowerCase();
                    const label = (el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase();

                    // Never hide select buttons
                    if (txt.includes('select') || label.includes('select')) return;

                    const isCut = txt === 'cut' || label === 'cut' || label.includes('cut');
                    const isDelete = txt === 'delete' || label === 'delete' || label.includes('delete');

                    if (isCut || isDelete) {
                        const btn = el.closest('button, [role="button"], a, li') || el;
                        btn.style.setProperty('display', 'none', 'important');
                        btn.style.setProperty('visibility', 'hidden', 'important');
                    }
                });
            });
        });
    };

    new MutationObserver(hideSelectionDeleteAndCut).observe(document.body, { childList: true, subtree: true });
    setInterval(hideSelectionDeleteAndCut, 250);

    window.showAdminRemoveLock = showAdminRemoveLock;
}