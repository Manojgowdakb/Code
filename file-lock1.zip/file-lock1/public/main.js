/**
 * HFS File Lock Plugin - Frontend
 * Place this file as: plugins/file-lock/public/main.js
 */

"use strict"; {
    const { React } = HFS
    const { config } = HFS.getPluginConfig()
    
    // ===== UTILITY FUNCTIONS =====
    
    function copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                HFS.notify('Copied to clipboard!', 'info')
            })
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea')
            textArea.value = text
            document.body.appendChild(textArea)
            textArea.select()
            document.execCommand('copy')
            document.body.removeChild(textArea)
            HFS.notify('Copied!', 'info')
        }
    }
    
    // ===== LOCK FILE DIALOG =====
    
    function showLockDialog(entry) {
        let password = ''
        let confirmPassword = ''
        let backupCodes = null
        let showBackupCodes = false
        let showSecurityQuestion = false
        let securityQuestion = ''
        let securityAnswer = ''
        let error = ''
        
        const updateDialog = () => dialog.update()
        
        const renderPasswordForm = () => {
            return HFS.h('div', { className: 'lock-dialog-form' },
                HFS.h('h3', null, '🔒 Lock File'),
                HFS.h('p', { className: 'file-name' }, entry.name),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Password:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'Enter password',
                        value: password,
                        onChange: (e) => { password = e.target.value; error = '' },
                        className: error ? 'input-error' : ''
                    })
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Confirm:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'Confirm password',
                        value: confirmPassword,
                        onChange: (e) => { confirmPassword = e.target.value; error = '' },
                        className: error ? 'input-error' : ''
                    })
                ),
                config.recoveryMethod === 'security_question' && HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Security Question Answer:'),
                    HFS.h('select', {
                        onChange: (e) => { securityQuestion = e.target.value }
                    },
                        HFS.h('option', null, 'Select a question...'),
                        HFS.h('option', { value: 'What is your favorite color?' }, 'What is your favorite color?'),
                        HFS.h('option', { value: 'What is your pet\'s name?' }, 'What is your pet\'s name?'),
                        HFS.h('option', { value: 'In what city were you born?' }, 'In what city were you born?')
                    ),
                    HFS.h('input', {
                        type: 'text',
                        placeholder: 'Your answer',
                        value: securityAnswer,
                        onChange: (e) => { securityAnswer = e.target.value }
                    })
                ),
                HFS.h('div', { className: 'password-requirements' },
                    HFS.h('small', null,
                        '✓ Minimum ' + config.minPasswordLength + ' characters\n',
                        config.requireMixedCase && '✓ Uppercase + lowercase letters\n',
                        config.requireNumbers && '✓ At least one number'
                    )
                ),
                error && HFS.h('div', { className: 'error-message' }, error),
                HFS.h('div', { className: 'dialog-buttons' },
                    HFS.h('button', {
                        onClick: attemptLock,
                        className: 'btn-primary'
                    }, 'Lock File'),
                    HFS.h('button', {
                        onClick: () => dialog.close(),
                        className: 'btn-cancel'
                    }, 'Cancel')
                )
            )
        }
        
        const renderBackupCodesView = () => {
            return HFS.h('div', { className: 'lock-backup-codes-view' },
                HFS.h('h3', null, '💾 Backup Recovery Codes'),
                HFS.h('p', null, 'Save these codes. You\'ll need one to recover your file if you forget the password:'),
                HFS.h('div', { className: 'codes-container' },
                    backupCodes && backupCodes.map((code, idx) => 
                        HFS.h('code', { key: idx, className: 'backup-code' }, code)
                    )
                ),
                HFS.h('div', { className: 'warning-box' },
                    HFS.h('strong', null, '⚠️ IMPORTANT:'),
                    HFS.h('ul', null,
                        HFS.h('li', null, 'Write these codes down or save them in a secure place'),
                        HFS.h('li', null, 'Each code can only be used once'),
                        HFS.h('li', null, 'They won\'t be shown again after you close this dialog'),
                        HFS.h('li', null, 'Keep them safe - anyone with a code can unlock your file')
                    )
                ),
                HFS.h('div', { className: 'dialog-buttons' },
                    HFS.h('button', {
                        onClick: () => {
                            copyToClipboard(backupCodes.join('\n'))
                        },
                        className: 'btn-secondary'
                    }, '📋 Copy All Codes'),
                    HFS.h('button', {
                        onClick: () => dialog.close(),
                        className: 'btn-primary'
                    }, '✅ Done - File Locked!')
                )
            )
        }
        
        const renderSecurityQuestionSetup = () => {
            return HFS.h('div', { className: 'lock-security-setup' },
                HFS.h('h3', null, '❓ Setup Security Question'),
                HFS.h('p', null, 'Select a security question to help you recover your password:'),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('select', {
                        value: securityQuestion,
                        onChange: (e) => { securityQuestion = e.target.value }
                    },
                        HFS.h('option', null, 'Select a question...'),
                        HFS.h('option', { value: 'What is your favorite color?' }, 'What is your favorite color?'),
                        HFS.h('option', { value: 'What is your pet\'s name?' }, 'What is your pet\'s name?'),
                        HFS.h('option', { value: 'In what city were you born?' }, 'In what city were you born?')
                    )
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Your Answer (case-insensitive):'),
                    HFS.h('input', {
                        type: 'text',
                        placeholder: 'Answer',
                        value: securityAnswer,
                        onChange: (e) => { securityAnswer = e.target.value }
                    })
                ),
                HFS.h('div', { className: 'dialog-buttons' },
                    HFS.h('button', {
                        onClick: submitSecurityQuestion,
                        className: 'btn-primary'
                    }, 'Set Question & Lock File'),
                    HFS.h('button', {
                        onClick: () => dialog.close(),
                        className: 'btn-cancel'
                    }, 'Cancel')
                )
            )
        }
        
        async function attemptLock() {
            // Validation
            if (!password) {
                error = 'Please enter a password'
                updateDialog()
                return
            }
            
            if (password !== confirmPassword) {
                error = 'Passwords do not match'
                updateDialog()
                return
            }
            
            if (config.recoveryMethod === 'security_question' && (!securityQuestion || !securityAnswer)) {
                error = 'Please select a question and provide an answer'
                updateDialog()
                return
            }
            
            try {
                const response = await HFS.apiCall('lockFile', {
                    uri: entry.uri,
                    password
                })
                
                if (!response.success) {
                    error = response.error
                    updateDialog()
                    return
                }
                
                // Show backup codes if applicable
                if (response.backupCodes && response.backupCodes.length > 0) {
                    backupCodes = response.backupCodes
                    showBackupCodes = true
                    updateDialog()
                } else if (config.recoveryMethod === 'security_question') {
                    showSecurityQuestion = true
                    updateDialog()
                } else {
                    HFS.notify('✅ ' + (response.message || 'File locked successfully!'), 'success')
                    dialog.close()
                }
            } catch (e) {
                error = 'Error: ' + (e.message || 'Failed to lock file')
                updateDialog()
            }
        }
        
        async function submitSecurityQuestion() {
            if (!securityQuestion || !securityAnswer) {
                error = 'Please complete all fields'
                updateDialog()
                return
            }
            
            try {
                // In a real implementation, this would be sent to the server
                HFS.notify('✅ File locked with security question!', 'success')
                dialog.close()
            } catch (e) {
                error = 'Error: ' + e.message
                updateDialog()
            }
        }
        
        const render = () => {
            if (showBackupCodes) {
                return renderBackupCodesView()
            } else if (showSecurityQuestion) {
                return renderSecurityQuestionSetup()
            } else {
                return renderPasswordForm()
            }
        }
        
        const dialog = HFS.showDialog(render)
    }
    
    // ===== UNLOCK FILE DIALOG =====
    
    function showUnlockDialog(entry) {
        let password = ''
        let showRecovery = false
        let recoveryMethod = config.recoveryMethod
        let recoveryInput = ''
        let recoveryNewPassword = ''
        let recoveryNewPasswordConfirm = ''
        let securityQuestion = ''
        let error = ''
        
        const updateDialog = () => dialog.update()
        
        const renderPasswordForm = () => {
            return HFS.h('div', { className: 'unlock-dialog-form' },
                HFS.h('h3', null, '🔓 Unlock File'),
                HFS.h('p', { className: 'file-name' }, entry.name),
                HFS.h('div', { className: 'info-box' },
                    HFS.h('small', null, 'This file is password protected')
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Password:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'Enter password',
                        autoFocus: true,
                        value: password,
                        onChange: (e) => { password = e.target.value; error = '' },
                        onKeyPress: (e) => {
                            if (e.key === 'Enter') attemptUnlock()
                        },
                        className: error ? 'input-error' : ''
                    })
                ),
                error && HFS.h('div', { className: 'error-message' }, error),
                HFS.h('div', { className: 'dialog-buttons' },
                    HFS.h('button', {
                        onClick: attemptUnlock,
                        className: 'btn-primary'
                    }, 'Unlock'),
                    HFS.h('button', {
                        onClick: () => dialog.close(),
                        className: 'btn-cancel'
                    }, 'Cancel'),
                    recoveryMethod !== 'admin_only' && HFS.h('button', {
                        onClick: () => { showRecovery = true; updateDialog() },
                        className: 'btn-secondary'
                    }, 'Forgot Password?')
                )
            )
        }
        
        const renderBackupCodeRecovery = () => {
            return HFS.h('div', { className: 'recovery-dialog-form' },
                HFS.h('h3', null, '🔑 Recovery - Backup Code'),
                HFS.h('p', null, 'Enter one of your backup codes to verify and set a new password:'),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Backup Code (e.g., XXXX-XXXX):'),
                    HFS.h('input', {
                        type: 'text',
                        placeholder: 'Enter backup code',
                        value: recoveryInput,
                        onChange: (e) => { recoveryInput = e.target.value.toUpperCase() },
                        className: error ? 'input-error' : ''
                    })
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'New Password:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'New password',
                        value: recoveryNewPassword,
                        onChange: (e) => { recoveryNewPassword = e.target.value }
                    })
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Confirm Password:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'Confirm new password',
                        value: recoveryNewPasswordConfirm,
                        onChange: (e) => { recoveryNewPasswordConfirm = e.target.value }
                    })
                ),
                error && HFS.h('div', { className: 'error-message' }, error),
                HFS.h('div', { className: 'dialog-buttons' },
                    HFS.h('button', {
                        onClick: verifyBackupCode,
                        className: 'btn-primary'
                    }, 'Verify & Reset'),
                    HFS.h('button', {
                        onClick: () => { showRecovery = false; updateDialog() },
                        className: 'btn-cancel'
                    }, 'Back')
                )
            )
        }
        
        const renderSecurityQuestionRecovery = () => {
            return HFS.h('div', { className: 'recovery-dialog-form' },
                HFS.h('h3', null, '❓ Recovery - Security Question'),
                HFS.h('p', { id: 'security-question-text' }, '...'),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Your Answer:'),
                    HFS.h('input', {
                        type: 'text',
                        placeholder: 'Answer',
                        value: recoveryInput,
                        onChange: (e) => { recoveryInput = e.target.value }
                    })
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'New Password:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'New password',
                        value: recoveryNewPassword,
                        onChange: (e) => { recoveryNewPassword = e.target.value }
                    })
                ),
                HFS.h('div', { className: 'form-group' },
                    HFS.h('label', null, 'Confirm Password:'),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'Confirm new password',
                        value: recoveryNewPasswordConfirm,
                        onChange: (e) => { recoveryNewPasswordConfirm = e.target.value }
                    })
                ),
                error && HFS.h('div', { className: 'error-message' }, error),
                HFS.h('div', { className: 'dialog-buttons' },
                    HFS.h('button', {
                        onClick: verifySecurityQuestion,
                        className: 'btn-primary'
                    }, 'Answer & Reset'),
                    HFS.h('button', {
                        onClick: () => { showRecovery = false; updateDialog() },
                        className: 'btn-cancel'
                    }, 'Back')
                )
            )
        }
        
        async function attemptUnlock() {
            if (!password) {
                error = 'Please enter a password'
                updateDialog()
                return
            }
            
            try {
                const response = await HFS.apiCall('unlockFile', {
                    uri: entry.uri,
                    password
                })
                
                if (!response.success) {
                    error = response.error || 'Unlock failed'
                    updateDialog()
                    return
                }
                
                HFS.notify('✅ File unlocked!', 'success')
                dialog.close()
            } catch (e) {
                error = 'Error: ' + (e.message || 'Failed to unlock')
                updateDialog()
            }
        }
        
        async function verifyBackupCode() {
            if (!recoveryInput || !recoveryNewPassword || !recoveryNewPasswordConfirm) {
                error = 'Please fill all fields'
                updateDialog()
                return
            }
            
            if (recoveryNewPassword !== recoveryNewPasswordConfirm) {
                error = 'New passwords do not match'
                updateDialog()
                return
            }
            
            try {
                const response = await HFS.apiCall('recoverWithBackupCode', {
                    uri: entry.uri,
                    code: recoveryInput
                })
                
                if (!response.success) {
                    error = response.error || 'Invalid code'
                    updateDialog()
                    return
                }
                
                HFS.notify('✅ Code verified! Password updated.', 'success')
                dialog.close()
            } catch (e) {
                error = 'Error: ' + e.message
                updateDialog()
            }
        }
        
        async function verifySecurityQuestion() {
            if (!recoveryInput || !recoveryNewPassword || !recoveryNewPasswordConfirm) {
                error = 'Please fill all fields'
                updateDialog()
                return
            }
            
            if (recoveryNewPassword !== recoveryNewPasswordConfirm) {
                error = 'New passwords do not match'
                updateDialog()
                return
            }
            
            try {
                const response = await HFS.apiCall('recoverWithSecurityQuestion', {
                    uri: entry.uri,
                    answer: recoveryInput,
                    newPassword: recoveryNewPassword
                })
                
                if (!response.success) {
                    error = response.error || 'Incorrect answer'
                    updateDialog()
                    return
                }
                
                HFS.notify('✅ Password reset! Use your new password.', 'success')
                dialog.close()
            } catch (e) {
                error = 'Error: ' + e.message
                updateDialog()
            }
        }
        
        // Load security question if needed
        if (recoveryMethod === 'security_question' && showRecovery) {
            setTimeout(async () => {
                try {
                    const response = await HFS.apiCall('getSecurityQuestion', { uri: entry.uri })
                    securityQuestion = response.question
                    const el = document.getElementById('security-question-text')
                    if (el) el.textContent = response.question || 'Question not set'
                } catch (e) {
                    console.error('Failed to load security question:', e)
                }
            }, 100)
        }
        
        const render = () => {
            if (!showRecovery) {
                return renderPasswordForm()
            } else if (recoveryMethod === 'backup_codes') {
                return renderBackupCodeRecovery()
            } else if (recoveryMethod === 'security_question') {
                return renderSecurityQuestionRecovery()
            } else {
                return HFS.h('div', null,
                    HFS.h('p', null, 'Please contact an administrator to reset your password.')
                )
            }
        }
        
        const dialog = HFS.showDialog(render)
    }
    
    // ===== FILE MENU INTEGRATION =====
    
    HFS.onEvent('fileMenu', ({ entries }) => {
        return entries.map(entry => {
            const isLocked = entry.locked
            return {
                label: isLocked ? '🔓 Unlock' : '🔒 Lock',
                icon: isLocked ? 'lock-open' : 'lock',
                action: () => {
                    if (isLocked) {
                        showUnlockDialog(entry)
                    } else {
                        showLockDialog(entry)
                    }
                }
            }
        })
    })
    
    // ===== FILE LIST INDICATOR =====
    
    HFS.onEvent('additionalEntryDetails', ({ entry }) => {
        if (entry.locked) {
            return HFS.h('span', { className: 'file-lock-badge' },
                HFS.hIcon('lock'),
                ' Locked'
            )
        }
        return null
    })
}