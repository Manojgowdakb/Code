/**
 * HFS File Lock Plugin - Complete Ready-Made Version
 * Features: Password protection, offline recovery, brute force protection
 * No external dependencies required (uses Node.js built-ins only)
 * Drop this file directly into plugins/file-lock/ directory
 */

const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

// ============================================================================
// CONFIGURATION
// ============================================================================

exports.version = 1.0
exports.description = "Password-protected file locking with offline recovery"
exports.apiRequired = 8.3
exports.frontend_js = "main.js"

// Admin configuration dialog
exports.configDialog = {
    sx: { maxWidth: '30em' },
}

exports.config = {
    minPasswordLength: {
        type: 'number',
        defaultValue: 6,
        min: 4,
        max: 128,
        label: 'Minimum password length',
        frontend: false,
    },
    
    requireMixedCase: {
        type: 'checkbox',
        defaultValue: false,
        label: 'Require uppercase + lowercase',
        frontend: false,
    },
    
    requireNumbers: {
        type: 'checkbox',
        defaultValue: false,
        label: 'Require numbers in password',
        frontend: false,
    },
    
    maxFailedAttempts: {
        type: 'number',
        defaultValue: 5,
        min: 1,
        max: 20,
        label: 'Max failed attempts before lockout',
        frontend: false,
    },
    
    lockoutDuration: {
        type: 'number',
        defaultValue: 15,
        min: 5,
        max: 120,
        label: 'Lockout duration (minutes)',
        frontend: false,
    },
    
    recoveryMethod: {
        type: 'select',
        options: {
            'backup_codes': 'Backup Codes (Generate one-time recovery codes)',
            'security_question': 'Security Questions (Answer to reset password)',
            'admin_only': 'Admin Only (Admin must manually reset)',
        },
        defaultValue: 'backup_codes',
        label: 'Password recovery method (offline-friendly)',
        frontend: false,
    },
    
    enableAuditLog: {
        type: 'checkbox',
        defaultValue: true,
        label: 'Enable audit logging for all lock operations',
        frontend: false,
    }
}

// ============================================================================
// STORAGE MANAGER - Simple file-based storage
// ============================================================================

class StorageManager {
    constructor() {
        this.lockDir = path.join(process.cwd(), '.hfs-locks')
        this.ensureDir()
    }
    
    ensureDir() {
        if (!fs.existsSync(this.lockDir)) {
            fs.mkdirSync(this.lockDir, { recursive: true })
        }
    }
    
    getLockPath(uri) {
        const hash = crypto.createHash('sha256').update(uri).digest('hex').slice(0, 16)
        return path.join(this.lockDir, `lock_${hash}.json`)
    }
    
    readLock(uri) {
        try {
            const lockPath = this.getLockPath(uri)
            if (fs.existsSync(lockPath)) {
                return JSON.parse(fs.readFileSync(lockPath, 'utf8'))
            }
        } catch (e) {
            console.error('Error reading lock:', e.message)
        }
        return null
    }
    
    writeLock(uri, data) {
        try {
            const lockPath = this.getLockPath(uri)
            fs.writeFileSync(lockPath, JSON.stringify(data, null, 2), 'utf8')
            return true
        } catch (e) {
            console.error('Error writing lock:', e.message)
            return false
        }
    }
    
    deleteLock(uri) {
        try {
            const lockPath = this.getLockPath(uri)
            if (fs.existsSync(lockPath)) {
                fs.unlinkSync(lockPath)
            }
        } catch (e) {
            console.error('Error deleting lock:', e.message)
        }
    }
    
    appendAuditLog(entry) {
        try {
            const logPath = path.join(this.lockDir, 'audit.log')
            const line = JSON.stringify(entry) + '\n'
            fs.appendFileSync(logPath, line, 'utf8')
        } catch (e) {
            console.error('Error writing audit log:', e.message)
        }
    }
    
    getAllLocks() {
        try {
            const files = fs.readdirSync(this.lockDir)
            return files
                .filter(f => f.startsWith('lock_') && f.endsWith('.json'))
                .map(f => {
                    try {
                        return JSON.parse(fs.readFileSync(path.join(this.lockDir, f), 'utf8'))
                    } catch {
                        return null
                    }
                })
                .filter(Boolean)
        } catch (e) {
            console.error('Error reading locks:', e.message)
            return []
        }
    }
}

const storage = new StorageManager()

// ============================================================================
// PASSWORD MANAGER - Offline-friendly bcrypt alternative using crypto
// ============================================================================

class PasswordManager {
    // Simple PBKDF2-based password hashing (Node.js built-in)
    hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
        const hash = crypto
            .pbkdf2Sync(password, salt, 100000, 64, 'sha512')
            .toString('hex')
        return `${salt}:${hash}`
    }
    
    verifyPassword(password, storedHash) {
        try {
            const [salt, hash] = storedHash.split(':')
            const newHash = crypto
                .pbkdf2Sync(password, salt, 100000, 64, 'sha512')
                .toString('hex')
            return newHash === hash
        } catch {
            return false
        }
    }
    
    validateStrength(password, config) {
        const errors = []
        
        if (password.length < config.minPasswordLength) {
            errors.push(`Minimum ${config.minPasswordLength} characters`)
        }
        
        if (config.requireMixedCase) {
            if (!/[a-z]/.test(password) || !/[A-Z]/.test(password)) {
                errors.push('Mix of uppercase and lowercase letters')
            }
        }
        
        if (config.requireNumbers) {
            if (!/\d/.test(password)) {
                errors.push('At least one number')
            }
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors.length > 0 ? 'Password must contain: ' + errors.join(', ') : null
        }
    }
}

const pwManager = new PasswordManager()

// ============================================================================
// RECOVERY MANAGER - Offline password recovery
// ============================================================================

class RecoveryManager {
    generateBackupCodes(count = 10) {
        const codes = []
        for (let i = 0; i < count; i++) {
            const code = crypto.randomBytes(4).toString('hex').toUpperCase()
            codes.push(`${code.slice(0, 4)}-${code.slice(4)}`)
        }
        return codes
    }
    
    hashBackupCode(code) {
        return crypto.createHash('sha256').update(code).digest('hex')
    }
    
    verifyBackupCode(code, lockData) {
        if (!lockData.backupCodes) return false
        
        const hashedCode = this.hashBackupCode(code.toUpperCase())
        const index = lockData.backupCodes.findIndex(bc => bc.used === false && bc.hash === hashedCode)
        
        if (index !== -1) {
            lockData.backupCodes[index].used = true
            return true
        }
        return false
    }
    
    getSecurityQuestions() {
        return [
            'What is your favorite color?',
            'What is your pet\'s name?',
            'In what city were you born?',
            'What was your first school?',
            'What is your mother\'s maiden name?',
            'What street did you grow up on?',
            'What is your favorite food?',
            'What year did you graduate?'
        ]
    }
}

const recovery = new RecoveryManager()

// ============================================================================
// LOCK MANAGER - Main business logic
// ============================================================================

class LockManager {
    lockFile(uri, password, config) {
        // Validate password
        const validation = pwManager.validateStrength(password, config)
        if (!validation.isValid) {
            return { success: false, error: validation.errors }
        }
        
        // Create lock record
        const lockData = {
            uri,
            locked: true,
            passwordHash: pwManager.hashPassword(password),
            createdAt: Date.now(),
            updatedAt: Date.now(),
            createdBy: 'user',
            failedAttempts: 0,
            lockedUntil: null,
            backupCodes: [],
            securityQuestion: null,
            securityAnswer: null,
            hint: `${password.length} characters`,
            lastUnlock: null
        }
        
        // Generate recovery codes based on config
        if (config.recoveryMethod === 'backup_codes') {
            const codes = recovery.generateBackupCodes(10)
            lockData.backupCodes = codes.map(code => ({
                code,
                hash: recovery.hashBackupCode(code),
                used: false,
                createdAt: Date.now()
            }))
            lockData.unlockedCodes = codes // Show to user once
        } else if (config.recoveryMethod === 'security_question') {
            lockData.securityQuestion = recovery.getSecurityQuestions()[0]
            lockData.securityAnswer = null // Will be set by user
        }
        
        if (storage.writeLock(uri, lockData)) {
            this.auditLog('lock_created', uri, null, 'success', config)
            return { 
                success: true, 
                backupCodes: lockData.unlockedCodes || null,
                securityQuestion: lockData.securityQuestion || null,
                message: config.recoveryMethod === 'backup_codes' 
                    ? 'File locked. Save these codes for recovery!'
                    : 'File locked. Set security question answer below.'
            }
        }
        
        return { success: false, error: 'Failed to save lock' }
    }
    
    unlockFile(uri, password, config) {
        const lockData = storage.readLock(uri)
        
        if (!lockData || !lockData.locked) {
            return { success: false, error: 'File is not locked' }
        }
        
        // Check brute force lockout
        if (lockData.lockedUntil && lockData.lockedUntil > Date.now()) {
            const minutesLeft = Math.ceil((lockData.lockedUntil - Date.now()) / 60000)
            return { 
                success: false, 
                error: `Too many attempts. Try again in ${minutesLeft} minutes.`,
                lockedOut: true
            }
        }
        
        // Verify password
        if (!pwManager.verifyPassword(password, lockData.passwordHash)) {
            lockData.failedAttempts++
            
            if (lockData.failedAttempts >= config.maxFailedAttempts) {
                lockData.lockedUntil = Date.now() + (config.lockoutDuration * 60 * 1000)
                storage.writeLock(uri, lockData)
                this.auditLog('unlock_attempt', uri, null, 'failed_lockout', config)
                
                const minutesLeft = config.lockoutDuration
                return {
                    success: false,
                    error: `Locked out. Try again in ${minutesLeft} minutes.`,
                    lockedOut: true
                }
            }
            
            storage.writeLock(uri, lockData)
            this.auditLog('unlock_attempt', uri, null, 'failed_password', config)
            
            const attemptsLeft = config.maxFailedAttempts - lockData.failedAttempts
            return {
                success: false,
                error: `Wrong password. ${attemptsLeft} attempts remaining.`,
                attemptsLeft
            }
        }
        
        // Success
        lockData.failedAttempts = 0
        lockData.lockedUntil = null
        lockData.lastUnlock = Date.now()
        storage.writeLock(uri, lockData)
        
        this.auditLog('unlock_success', uri, null, 'success', config)
        
        // Create session token (valid for 1 hour)
        const token = crypto.randomBytes(32).toString('hex')
        const tokenData = {
            token,
            uri,
            createdAt: Date.now(),
            expiresAt: Date.now() + (60 * 60 * 1000), // 1 hour
            ip: 'offline' // No IP tracking in offline mode
        }
        
        const tokenPath = path.join(process.cwd(), '.hfs-locks', `token_${token}.json`)
        fs.writeFileSync(tokenPath, JSON.stringify(tokenData, null, 2))
        
        return { success: true, token, message: 'File unlocked' }
    }
    
    recoverWithBackupCode(uri, code, config) {
        const lockData = storage.readLock(uri)
        
        if (!lockData) {
            return { success: false, error: 'File is not locked' }
        }
        
        if (!recovery.verifyBackupCode(code, lockData)) {
            return { success: false, error: 'Invalid backup code' }
        }
        
        storage.writeLock(uri, lockData)
        this.auditLog('recovery_backup_code', uri, null, 'success', config)
        
        return { 
            success: true, 
            message: 'Backup code verified. You can now set a new password.',
            uri
        }
    }
    
    recoverWithSecurityQuestion(uri, answer, newPassword, config) {
        const lockData = storage.readLock(uri)
        
        if (!lockData) {
            return { success: false, error: 'File is not locked' }
        }
        
        // Admin must have set the answer
        if (!lockData.securityAnswer) {
            return { success: false, error: 'Security question not configured. Contact admin.' }
        }
        
        // Verify answer (case-insensitive, trim whitespace)
        if (answer.toLowerCase().trim() !== lockData.securityAnswer.toLowerCase().trim()) {
            return { success: false, error: 'Incorrect answer' }
        }
        
        // Validate new password
        const validation = pwManager.validateStrength(newPassword, config)
        if (!validation.isValid) {
            return { success: false, error: validation.errors }
        }
        
        // Update password
        lockData.passwordHash = pwManager.hashPassword(newPassword)
        lockData.failedAttempts = 0
        lockData.lockedUntil = null
        storage.writeLock(uri, lockData)
        
        this.auditLog('recovery_security_question', uri, null, 'success', config)
        
        return { success: true, message: 'Password changed successfully' }
    }
    
    isFileLocked(uri) {
        const lockData = storage.readLock(uri)
        return lockData && lockData.locked === true
    }
    
    getLockInfo(uri) {
        return storage.readLock(uri)
    }
    
    auditLog(operation, uri, user, result, config) {
        if (!config.enableAuditLog) return
        
        storage.appendAuditLog({
            timestamp: new Date().toISOString(),
            operation,
            uri,
            user: user || 'system',
            result,
            ip: 'offline'
        })
    }
    
    getBackupCodes(uri) {
        const lockData = storage.readLock(uri)
        if (lockData && lockData.backupCodes) {
            return lockData.backupCodes
                .filter(bc => !bc.used)
                .map(bc => ({ code: bc.code }))
        }
        return []
    }
    
    getSecurityQuestion(uri) {
        const lockData = storage.readLock(uri)
        return lockData?.securityQuestion || null
    }
}

const lockManager = new LockManager()

// ============================================================================
// API ENDPOINTS
// ============================================================================

exports.apiRoutes = {
    // Lock a file
    lockFile(ctx) {
        const { uri, password } = ctx.req.body
        const config = HFS.config
        
        const result = lockManager.lockFile(uri, password, config)
        
        if (result.success) {
            ctx.json(result)
        } else {
            ctx.res.status(400).json(result)
        }
    },
    
    // Unlock a file
    unlockFile(ctx) {
        const { uri, password } = ctx.req.body
        const config = HFS.config
        
        const result = lockManager.unlockFile(uri, password, config)
        
        if (result.success) {
            ctx.json(result)
        } else {
            ctx.res.status(400).json(result)
        }
    },
    
    // Check lock status
    checkLockStatus(ctx) {
        const { uri } = ctx.req.body
        const isLocked = lockManager.isFileLocked(uri)
        ctx.json({ locked: isLocked })
    },
    
    // Get backup codes (for recovery setup)
    getBackupCodes(ctx) {
        const { uri } = ctx.req.body
        const codes = lockManager.getBackupCodes(uri)
        ctx.json({ codes })
    },
    
    // Verify and use backup code for recovery
    recoverWithBackupCode(ctx) {
        const { uri, code } = ctx.req.body
        const config = HFS.config
        
        const result = lockManager.recoverWithBackupCode(uri, code, config)
        
        if (result.success) {
            ctx.json(result)
        } else {
            ctx.res.status(400).json(result)
        }
    },
    
    // Get security question
    getSecurityQuestion(ctx) {
        const { uri } = ctx.req.body
        const question = lockManager.getSecurityQuestion(uri)
        ctx.json({ question })
    },
    
    // Recover using security question
    recoverWithSecurityQuestion(ctx) {
        const { uri, answer, newPassword } = ctx.req.body
        const config = HFS.config
        
        const result = lockManager.recoverWithSecurityQuestion(uri, answer, newPassword, config)
        
        if (result.success) {
            ctx.json(result)
        } else {
            ctx.res.status(400).json(result)
        }
    },
    
    // Admin: View all locks
    adminListLocks(ctx) {
        const locks = storage.getAllLocks().map(lock => ({
            uri: lock.uri,
            locked: lock.locked,
            createdAt: new Date(lock.createdAt).toLocaleString(),
            failedAttempts: lock.failedAttempts,
            unlockedCodesRemaining: lock.backupCodes ? lock.backupCodes.filter(c => !c.used).length : 0
        }))
        ctx.json({ locks })
    },
    
    // Admin: Set security question answer
    adminSetSecurityAnswer(ctx) {
        const { uri, question, answer } = ctx.req.body
        const lockData = storage.readLock(uri)
        
        if (!lockData) {
            return ctx.res.status(404).json({ error: 'Lock not found' })
        }
        
        lockData.securityQuestion = question
        lockData.securityAnswer = answer
        storage.writeLock(uri, lockData)
        
        ctx.json({ success: true, message: 'Security question set' })
    },
    
    // Admin: Regenerate backup codes
    adminRegenerateBackupCodes(ctx) {
        const { uri } = ctx.req.body
        const lockData = storage.readLock(uri)
        
        if (!lockData) {
            return ctx.res.status(404).json({ error: 'Lock not found' })
        }
        
        const codes = recovery.generateBackupCodes(10)
        lockData.backupCodes = codes.map(code => ({
            code,
            hash: recovery.hashBackupCode(code),
            used: false,
            createdAt: Date.now()
        }))
        
        storage.writeLock(uri, lockData)
        
        ctx.json({ success: true, codes })
    },
    
    // Admin: Manually reset password
    adminResetPassword(ctx) {
        const { uri, newPassword } = ctx.req.body
        const config = HFS.config
        
        const lockData = storage.readLock(uri)
        if (!lockData) {
            return ctx.res.status(404).json({ error: 'Lock not found' })
        }
        
        const validation = pwManager.validateStrength(newPassword, config)
        if (!validation.isValid) {
            return ctx.res.status(400).json({ error: validation.errors })
        }
        
        lockData.passwordHash = pwManager.hashPassword(newPassword)
        lockData.failedAttempts = 0
        lockData.lockedUntil = null
        storage.writeLock(uri, lockData)
        
        ctx.json({ success: true, message: 'Password reset by admin' })
    }
}

// ============================================================================
// MIDDLEWARE - Intercept file operations
// ============================================================================

exports.middlewares = {
    async onSendFile(ctx) {
        const filePath = ctx.req.url.replace(/^\//, '')
        
        if (lockManager.isFileLocked(filePath)) {
            return ctx.res.status(423).json({
                error: 'File is password protected',
                locked: true
            })
        }
    },
    
    async onBeforeVfsOperation(ctx) {
        const { path: filePath, operation } = ctx.req.body
        
        if (['move', 'copy', 'rename', 'delete'].includes(operation)) {
            if (lockManager.isFileLocked(filePath)) {
                return ctx.res.status(423).json({
                    error: 'This file is password protected',
                    locked: true
                })
            }
        }
    }
}

// ============================================================================
// EVENTS - UI Integration
// ============================================================================

exports.eventHandlers = {
    onFileMenu(ctx) {
        const { entries } = ctx
        
        return entries.map(entry => {
            const isLocked = lockManager.isFileLocked(entry.uri)
            
            return {
                label: isLocked ? '🔓 Unlock' : '🔒 Lock',
                action: isLocked ? 'unlockFile' : 'lockFile',
                icon: isLocked ? 'lock-open' : 'lock'
            }
        })
    },
    
    onListEntryDetails(ctx) {
        const { entry } = ctx
        const isLocked = lockManager.isFileLocked(entry.uri)
        
        if (isLocked) {
            return {
                icon: 'lock',
                text: 'Protected',
                class: 'file-lock-indicator'
            }
        }
        return null
    }
}

// ============================================================================
// FRONTEND CODE - Embedded in plugin.js
// ============================================================================

exports.frontend_js_content = `
"use strict"; {
    const { React } = HFS
    const { config } = HFS.getPluginConfig()
    
    // Lock file dialog
    function showLockDialog(entry) {
        let password = ''
        let confirm = ''
        let backupCodes = null
        let showCodes = false
        let error = ''
        
        const render = () => HFS.h('div', { className: 'lock-dialog-container' },
            !showCodes ? renderLockForm() : renderBackupCodes()
        )
        
        const renderLockForm = () => HFS.h('div', null,
            HFS.h('h3', null, '🔒 Lock File'),
            HFS.h('p', null, \`Protect: \${entry.name}\`),
            HFS.h('input', {
                type: 'password',
                placeholder: 'Enter password',
                onChange: (e) => password = e.target.value,
                className: error ? 'error' : ''
            }),
            HFS.h('input', {
                type: 'password',
                placeholder: 'Confirm password',
                onChange: (e) => confirm = e.target.value,
                className: error ? 'error' : ''
            }),
            HFS.h('div', { className: 'password-hint' },
                HFS.h('small', null, \`Min \${config.minPasswordLength} characters\`)
            ),
            error && HFS.h('div', { className: 'error-msg' }, error),
            HFS.h('div', { className: 'dialog-buttons' },
                HFS.h('button', {
                    onClick: attemptLock,
                    className: 'btn-primary'
                }, 'Lock File'),
                HFS.h('button', { onClick: () => dialog.close() }, 'Cancel')
            )
        )
        
        const renderBackupCodes = () => HFS.h('div', null,
            HFS.h('h3', null, '💾 Backup Codes'),
            HFS.h('p', null, 'Save these codes. You\'ll need one to recover if you forget the password:'),
            HFS.h('div', { className: 'backup-codes' },
                backupCodes.map(code => HFS.h('code', null, code))
            ),
            HFS.h('p', { className: 'warning' }, '⚠️ Write these down! They won\'t be shown again.'),
            HFS.h('div', { className: 'dialog-buttons' },
                HFS.h('button', {
                    onClick: () => {
                        copyToClipboard(backupCodes.join('\\n'))
                        HFS.notify('Codes copied to clipboard')
                    },
                    className: 'btn-primary'
                }, 'Copy All'),
                HFS.h('button', {
                    onClick: () => dialog.close(),
                    className: 'btn-success'
                }, 'Done - File Locked!')
            )
        )
        
        async function attemptLock() {
            if (!password || password !== confirm) {
                error = 'Passwords do not match'
                dialog.update()
                return
            }
            
            try {
                const response = await HFS.apiCall('lockFile', {
                    uri: entry.uri,
                    password
                })
                
                if (response.backupCodes) {
                    backupCodes = response.backupCodes
                    showCodes = true
                    dialog.update()
                } else {
                    HFS.notify('✅ File locked!')
                    dialog.close()
                }
            } catch (e) {
                error = e.message
                dialog.update()
            }
        }
        
        const dialog = HFS.showDialog(render)
    }
    
    // Unlock file dialog
    function showUnlockDialog(entry) {
        let password = ''
        let error = ''
        let showRecovery = false
        
        const render = () => !showRecovery ? renderPasswordForm() : renderRecovery()
        
        const renderPasswordForm = () => HFS.h('div', null,
            HFS.h('h3', null, '🔓 Unlock File'),
            HFS.h('p', null, entry.name),
            HFS.h('input', {
                type: 'password',
                placeholder: 'Password',
                autoFocus: true,
                onChange: (e) => password = e.target.value,
                onKeyPress: (e) => e.key === 'Enter' && attemptUnlock(),
                className: error ? 'error' : ''
            }),
            error && HFS.h('div', { className: 'error-msg' }, error),
            HFS.h('div', { className: 'dialog-buttons' },
                HFS.h('button', {
                    onClick: attemptUnlock,
                    className: 'btn-primary'
                }, 'Unlock'),
                HFS.h('button', { onClick: () => dialog.close() }, 'Cancel'),
                config.recoveryMethod !== 'admin_only' && HFS.h('button', {
                    onClick: () => { showRecovery = true; dialog.update() }
                }, 'Forgot Password?')
            )
        )
        
        const renderRecovery = () => HFS.h('div', null,
            HFS.h('h3', null, '🔑 Recover Password'),
            config.recoveryMethod === 'backup_codes' ? 
                HFS.h('div', null,
                    HFS.h('label', null, 'Enter a backup code:'),
                    HFS.h('input', {
                        type: 'text',
                        placeholder: 'e.g., XXXX-XXXX',
                        onChange: (e) => password = e.target.value
                    }),
                    HFS.h('button', {
                        onClick: verifyBackupCode,
                        className: 'btn-primary'
                    }, 'Verify Code')
                )
            :
                HFS.h('div', null,
                    HFS.h('p', { id: 'security-question' }, 'Loading...'),
                    HFS.h('input', {
                        type: 'text',
                        placeholder: 'Answer',
                        id: 'security-answer',
                        onChange: (e) => password = e.target.value
                    }),
                    HFS.h('input', {
                        type: 'password',
                        placeholder: 'New password',
                        id: 'new-password',
                        onChange: (e) => confirm = e.target.value
                    }),
                    HFS.h('button', {
                        onClick: verifySecurityQuestion,
                        className: 'btn-primary'
                    }, 'Reset Password')
                )
        )
        
        async function attemptUnlock() {
            try {
                const response = await HFS.apiCall('unlockFile', {
                    uri: entry.uri,
                    password
                })
                HFS.notify('✅ File unlocked!')
                dialog.close()
            } catch (e) {
                error = e.message
                dialog.update()
            }
        }
        
        async function verifyBackupCode() {
            try {
                await HFS.apiCall('recoverWithBackupCode', {
                    uri: entry.uri,
                    code: password
                })
                HFS.notify('Code verified! You can now set a new password.')
                dialog.close()
            } catch (e) {
                error = e.message
                dialog.update()
            }
        }
        
        async function verifySecurityQuestion() {
            try {
                const newPwd = document.getElementById('new-password')?.value
                await HFS.apiCall('recoverWithSecurityQuestion', {
                    uri: entry.uri,
                    answer: password,
                    newPassword: newPwd
                })
                HFS.notify('✅ Password reset! Use your new password to unlock.')
                dialog.close()
            } catch (e) {
                error = e.message
                dialog.update()
            }
        }
        
        // Load security question if needed
        if (config.recoveryMethod === 'security_question') {
            HFS.apiCall('getSecurityQuestion', { uri: entry.uri }).then(res => {
                const el = document.getElementById('security-question')
                if (el) el.textContent = res.question || 'Security question not set'
            })
        }
        
        const dialog = HFS.showDialog(render)
    }
    
    // File menu integration
    HFS.onEvent('fileMenu', ({ entries }) => {
        return entries.map(entry => ({
            label: entry.locked ? '🔓 Unlock' : '🔒 Lock',
            action: () => entry.locked ? showUnlockDialog(entry) : showLockDialog(entry)
        }))
    })
    
    // Lock indicator in file list
    HFS.onEvent('additionalEntryDetails', ({ entry }) => {
        if (entry.locked) {
            return HFS.h('span', { className: 'file-lock-badge' }, '🔒 Locked')
        }
    })
    
    // Utility
    function copyToClipboard(text) {
        navigator.clipboard?.writeText(text)
    }
}
`

// ============================================================================
// FRONTEND STYLES - Embedded
// ============================================================================

exports.frontend_css_content = `
.lock-dialog-container {
    padding: 20px;
    min-width: 350px;
}

.lock-dialog-container h3 {
    margin: 0 0 15px 0;
    color: #333;
}

.lock-dialog-container input {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    box-sizing: border-box;
}

.lock-dialog-container input.error {
    border-color: #d32f2f;
    background-color: #ffebee;
}

.error-msg {
    color: #d32f2f;
    font-size: 13px;
    margin: 10px 0;
    padding: 8px;
    background: #ffebee;
    border-radius: 4px;
    border-left: 3px solid #d32f2f;
}

.backup-codes {
    background: #f5f5f5;
    padding: 15px;
    border-radius: 4px;
    margin: 15px 0;
}

.backup-codes code {
    display: block;
    padding: 8px;
    margin: 5px 0;
    background: white;
    border: 1px solid #ddd;
    border-radius: 3px;
    font-family: monospace;
    font-weight: bold;
    user-select: all;
}

.password-hint {
    color: #666;
    font-size: 12px;
    margin: 8px 0;
}

.warning {
    color: #ff6f00;
    font-weight: bold;
    margin: 10px 0;
}

.dialog-buttons {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    justify-content: flex-end;
}

.dialog-buttons button {
    padding: 10px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
}

.btn-primary {
    background: #2196f3;
    color: white;
}

.btn-primary:hover {
    background: #1976d2;
}

.btn-success {
    background: #4caf50;
    color: white;
}

.btn-success:hover {
    background: #45a049;
}

.file-lock-badge {
    color: #ff9800;
    font-weight: bold;
    margin-left: 8px;
}

.file-lock-indicator {
    color: #d32f2f;
}
\`

// ============================================================================
// ADMIN PANEL CODE
// ============================================================================

exports.adminPanel_vue_component = \`
<template>
  <div class="lock-admin-panel">
    <h2>🔐 File Lock Management</h2>
    
    <div v-if="!locks.length" class="info-box">
      No locked files yet
    </div>
    
    <div v-else class="locks-list">
      <div v-for="lock in locks" :key="lock.uri" class="lock-item">
        <div class="lock-header">
          <span class="lock-uri">{{ lock.uri }}</span>
          <span class="lock-date">{{ lock.createdAt }}</span>
        </div>
        <div class="lock-actions">
          <span v-if="lock.unlockedCodesRemaining > 0" class="badge">
            {{ lock.unlockedCodesRemaining }} codes
          </span>
          <button @click="regenerateCodes(lock.uri)">Regenerate Codes</button>
          <button @click="resetPassword(lock.uri)">Reset Password</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      locks: []
    }
  },
  mounted() {
    this.loadLocks()
  },
  methods: {
    async loadLocks() {
      try {
        const res = await HFS.apiCall('adminListLocks', {})
        this.locks = res.locks
      } catch(e) {
        alert('Error loading locks: ' + e.message)
      }
    },
    async regenerateCodes(uri) {
      if (!confirm('Generate new backup codes?')) return
      try {
        const res = await HFS.apiCall('adminRegenerateBackupCodes', { uri })
        alert('New codes:\\n' + res.codes.join('\\n'))
        this.loadLocks()
      } catch(e) {
        alert('Error: ' + e.message)
      }
    },
    async resetPassword(uri) {
      const newPwd = prompt('Enter new password:')
      if (!newPwd) return
      try {
        await HFS.apiCall('adminResetPassword', { uri, newPassword: newPwd })
        alert('Password reset!')
        this.loadLocks()
      } catch(e) {
        alert('Error: ' + e.message)
      }
    }
  }
}
</script>

<style scoped>
.lock-admin-panel {
  padding: 20px;
}

.info-box {
  background: #e3f2fd;
  padding: 15px;
  border-radius: 4px;
  color: #1976d2;
}

.locks-list {
  margin-top: 20px;
}

.lock-item {
  background: #f5f5f5;
  padding: 15px;
  margin: 10px 0;
  border-radius: 4px;
  border-left: 4px solid #2196f3;
}

.lock-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.lock-uri {
  font-weight: bold;
  color: #333;
  word-break: break-all;
}

.lock-date {
  font-size: 12px;
  color: #999;
}

.lock-actions {
  display: flex;
  gap: 10px;
  align-items: center;
}

.badge {
  background: #ff9800;
  color: white;
  padding: 4px 8px;
  border-radius: 3px;
  font-size: 12px;
  font-weight: bold;
}

button {
  padding: 6px 12px;
  background: #2196f3;
  color: white;
  border: none;
  border-radius: 3px;
  cursor: pointer;
  font-size: 12px;
}

button:hover {
  background: #1976d2;
}
</style>
`

// ============================================================================
// Export ready-made plugin
// ============================================================================

console.log('✅ File Lock Plugin loaded successfully')
console.log('📁 Lock storage: .hfs-locks/')
console.log('🔐 Password hashing: PBKDF2-SHA512')
console.log('💾 Recovery: Offline-friendly backup codes or security questions')