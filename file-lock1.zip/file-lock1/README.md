# File Lock Plugin

Password protection plugin for HFS.

Features

- Lock files
- Password protection
- Download protection
- ZIP protection
- Folder scan