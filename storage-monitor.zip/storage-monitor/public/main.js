

"use strict";
{
    // ═══════════════════════════════════════════════════════════════
    //  QUOTA CACHE
    // ═══════════════════════════════════════════════════════════════
    window.enterpriseRemainingQuota = undefined;
    window.enterpriseFullQuotaData  = null;

    const formatMB = bytes => (bytes / (1024 * 1024)).toFixed(2);
    // Store the true native fetch before any plugin overrides it.
    // Both plugins use the same shared reference so they don't double-intercept each other.
    window._hfsNativeFetch = window._hfsNativeFetch || window.fetch.bind(window);
    const originalFetch = window._hfsNativeFetch;

    const fetchWithTimeout = (url, opts = {}, timeoutMs = 3000) => {
        if (typeof AbortController === 'undefined') {
            return Promise.race([
                originalFetch(url, opts),
                new Promise((_, reject) => setTimeout(() => reject(new Error('network-timeout')), timeoutMs))
            ]);
        }
        const controller = new AbortController();
        const signal = controller.signal;
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        return originalFetch(url, Object.assign({}, opts, { signal })).finally(() => clearTimeout(timer));
    };

    const getQuotaInfo = () => {
        if (typeof HFS !== 'undefined' && typeof HFS.customRestCall === 'function') {
            try {
                const maybe = HFS.customRestCall('getQuota');
                return Promise.resolve(maybe).then(d => d || {}).catch(() => {
                    return fetchWithTimeout('/~/api/_getQuota', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({}) }, 3000).then(async response => { const text = await response.text(); return text ? JSON.parse(text) : {}; });
                });
            } catch (e) {
                return fetchWithTimeout('/~/api/_getQuota', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({}) }, 3000).then(async response => { const text = await response.text(); return text ? JSON.parse(text) : {}; });
            }
        }
        return fetchWithTimeout('/~/api/_getQuota', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({}) }, 3000).then(async response => { const text = await response.text(); return text ? JSON.parse(text) : {}; });
    };

    const refreshQuotaCache = () => {
        getQuotaInfo()
            .then(data => {
                if (data && data.limit > 0) {
                    window.enterpriseRemainingQuota = data.remaining;
                    window.enterpriseFullQuotaData  = data;
                    window.lastQuotaData            = data;
                } else {
                    window.enterpriseRemainingQuota = undefined;
                    window.enterpriseFullQuotaData  = null;
                    window.lastQuotaData            = null;
                }
            })
            .catch(err => {
                // Keep existing cached data if offline or network error occurs
                if (navigator.onLine === false || (err && (err.name === 'TypeError' || err.message === 'Failed to fetch'))) {
                    return;
                }
                window.enterpriseRemainingQuota = undefined;
                window.enterpriseFullQuotaData  = null;
                window.lastQuotaData            = null;
            });
    };

    const setupStateWatcher = () => {
        if (typeof HFS !== 'undefined' && typeof HFS.watchState === 'function') {
            HFS.watchState('username', refreshQuotaCache);
            HFS.watchState('uri',      refreshQuotaCache);
            return;
        }

        let lastUsername = typeof HFS !== 'undefined' && HFS.state ? HFS.state.username : null;
        let lastUri      = typeof HFS !== 'undefined' && HFS.state ? HFS.state.uri : null;

        setInterval(() => {
            if (typeof HFS === 'undefined' || !HFS.state) return;
            const currentUsername = HFS.state.username;
            const currentUri      = HFS.state.uri;
            if (currentUsername !== lastUsername || currentUri !== lastUri) {
                lastUsername = currentUsername;
                lastUri      = currentUri;
                refreshQuotaCache();
            }
        }, 1500);
    };

    // Sync quota every 20 seconds
    setInterval(refreshQuotaCache, 20000);
    setupStateWatcher();
    setTimeout(refreshQuotaCache, 600);

    // Quota bar removed from nav bar — shown only in user panel popup via custom.html

    // ═══════════════════════════════════════════════════════════════
    //  QUOTA BLOCKED POPUP MODAL
    // ═══════════════════════════════════════════════════════════════
    const formatStorage = bytes => {
        if (!bytes || isNaN(bytes)) return '0.00 MB';
        const tb = 1099511627776;
        const gb = 1073741824;
        const mb = 1048576;
        if (bytes >= tb) return (bytes / tb).toFixed(2) + ' TB';
        if (bytes >= gb) return (bytes / gb).toFixed(2) + ' GB';
        return (bytes / mb).toFixed(2) + ' MB';
    };

    const showQuotaBlockedPopup = (selectedSize, remainingSize) => {
        const existing = document.getElementById('enterprise-quota-modal');
        if (existing) existing.remove();

        const selectedStr  = formatStorage(selectedSize);
        const remainingStr = formatStorage(remainingSize);

        const modal = document.createElement('div');
        modal.id        = 'enterprise-quota-modal';
        modal.className = 'quota-modal-overlay';
        modal.innerHTML = `
            <div class="quota-modal-card">
                <div class="quota-modal-header">
                    <h2 class="quota-modal-title">Upload Blocked</h2>
                </div>
                <div class="quota-modal-body">
                    <p class="quota-modal-text">File size exceeds remaining upload storage size.</p>
                    <p class="quota-modal-text">Selected: <strong>${selectedStr}</strong> &nbsp;|&nbsp; Remaining: <strong>${remainingStr}</strong></p>
                </div>
                <div class="quota-modal-footer">
                    <button id="quota-modal-ok-btn" class="quota-modal-btn">OK, Understood</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        const closeAndReload = () => {
            modal.remove();
            try {
                window.onbeforeunload = null;
            } catch (_) {}
            location.reload();
        };

        document.getElementById('quota-modal-ok-btn').onclick = closeAndReload;
        modal.addEventListener('click', e => { if (e.target === modal) closeAndReload(); });
    };

    // ═══════════════════════════════════════════════════════════════
    //  QUOTA CHECK — used by both XHR and fetch interceptors
    // ═══════════════════════════════════════════════════════════════
    const checkAndBlockUpload = (totalSize, abort) => {
        const remaining = window.enterpriseRemainingQuota;
        if (remaining === undefined || remaining === null) return false; // No quota set

        if (totalSize > remaining) {
            abort();
            showQuotaBlockedPopup(totalSize, remaining);

            // Report to server
            if (typeof HFS !== 'undefined' && typeof HFS.customRestCall === 'function') {
                HFS.customRestCall('logQuotaViolation', { size: totalSize, remaining }).catch(() => {});
            }
            return true; // Blocked
        }
        return false; // Allowed
    };

    // ═══════════════════════════════════════════════════════════════
    //  XMLHttpRequest INTERCEPTION
    // ═══════════════════════════════════════════════════════════════
    const originalXhrOpen = XMLHttpRequest.prototype.open;
    const originalXhrSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url, ...args) {
        this._xm = method ? method.toUpperCase() : 'GET';
        this._xu = url;
        return originalXhrOpen.apply(this, [method, url, ...args]);
    };

    XMLHttpRequest.prototype.send = function(body) {
        const xhr = this;

        let totalSize = 0;
        let isUpload  = false;

        if (xhr._xm === 'POST' && body instanceof FormData) {
            isUpload = true;
            for (const [, value] of body.entries()) {
                if (value instanceof File) totalSize += value.size;
            }
        } else if (xhr._xm === 'PUT' && (body instanceof Blob || body instanceof ArrayBuffer)) {
            isUpload = true;
            totalSize = body instanceof Blob ? body.size : body.byteLength;
        }

        if (isUpload && totalSize > 0) {
            const blocked = checkAndBlockUpload(totalSize, () => xhr.abort());
            if (blocked) return;
        }

        // After upload completes — refresh quota cache
        if (isUpload) {
            xhr.addEventListener('load', () => {
                if (xhr.status < 300) {
                    setTimeout(refreshQuotaCache, 1000);
                }
            });
        }

        return originalXhrSend.apply(this, [body]);
    };

    // ═══════════════════════════════════════════════════════════════
    //  FETCH INTERCEPTION  (HFS 3.x may use fetch for file uploads)
    // ═══════════════════════════════════════════════════════════════
    window.fetch = function(url, options) {
        const urlStr = typeof url === 'string' ? url : (url && url.url) || '';
        // Reject empty URL quickly to avoid hanging fetches
        if (!urlStr) return Promise.reject(new TypeError('Invalid URL')); 
        if (urlStr.includes('/api/login') || urlStr.includes('/api/auth')) {
            return originalFetch(url, options);
        }
        const method = ((options && options.method) || 'GET').toUpperCase();
        const body   = options && options.body;

        if (method === 'POST' || method === 'PUT') {
            let totalSize = 0;
            let isUpload  = false;

            if (body instanceof FormData) {
                isUpload = true;
                for (const [, value] of body.entries()) {
                    if (value instanceof File) totalSize += value.size;
                }
            } else if (body instanceof Blob) {
                isUpload  = true;
                totalSize = body.size;
            } else if (body instanceof ArrayBuffer) {
                isUpload  = true;
                totalSize = body.byteLength;
            }

            if (isUpload && totalSize > 0) {
                let blocked = false;
                checkAndBlockUpload(totalSize, () => { blocked = true; });
                if (blocked) {
                    // Return a resolved promise with a synthetic 413 response
                    return Promise.resolve(new Response(
                        JSON.stringify({ error: 'Upload Blocked', reason: 'File size exceeds remaining upload storage size' }),
                        { status: 413, headers: { 'content-type': 'application/json' } }
                    ));
                }
            }
        }

        return originalFetch(url, options).then(response => {
            // Quota cache refresh on any successful write
            if (response.ok && (method === 'POST' || method === 'PUT' || method === 'DELETE')) {
                setTimeout(refreshQuotaCache, 800);
            }
            // Handle server-side 413 (quota exceeded — backend rejection)
            if (response.status === 413) {
                response.clone().json().then(data => {
                    if (data && data.error === 'Upload Blocked') {
                        const remaining = window.enterpriseRemainingQuota || 0;
                        const requested = data.requested || 0;
                        showQuotaBlockedPopup(requested, remaining);
                    }
                }).catch(() => {});
            }
            return response;
        }).catch(err => {
            if (!navigator.onLine || (err && (err.name === 'TypeError' || err.message === 'Failed to fetch'))) {
                return new Response(JSON.stringify({ error: 'offline', message: 'System offline' }), {
                    status: 503,
                    headers: { 'content-type': 'application/json' }
                });
            }
            throw err;
        });
    };
}
