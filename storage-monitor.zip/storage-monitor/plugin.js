// Enterprise HFS 3.2.1 Security Plugin Suite
// Plugin: Storage Monitor  v2.0
// File: plugins/storage-monitor/plugin.js
//
// CHANGELOG v2.0:
//   - Promise coalescing: concurrent users share one scan per user (no I/O explosion)
//   - Pessimistic reservation system: deducts expected bytes before upload commits
//     (prevents multiple concurrent uploads from exceeding quota together)
//   - VFS path resolution improved: handles nested VFS nodes correctly
//   - Middleware: detects both multipart/form-data AND application/octet-stream uploads
//   - uploadFinished event: logs username/filename/size/remaining to HFS log
//   - getAdminQuotaReport REST: admin can see all users' current usage
//   - Quota cache TTL exposed as configurable option

const fs   = require('fs');
const path = require('path');

exports.description = "Calculates, monitors, and enforces per-user upload quotas. v2.0: concurrent-safe with pessimistic reservation.";
exports.version      = 2.0;
// Helper to parse existing VFS paths from config.yaml dynamically
function getVfsPaths() {
    const paths = ['/'];
    try {
        const configPath = path.join(process.cwd(), 'config.yaml');
        if (!fs.existsSync(configPath)) return paths;
        const content = fs.readFileSync(configPath, 'utf8');
        const lines = content.split('\n');
        
        let inVfs = false;
        const stack = [];
        
        for (const line of lines) {
            const indent = line.search(/\S/);
            if (indent === -1) continue;
            const trimmed = line.trim();
            
            if (trimmed.startsWith('vfs:')) {
                inVfs = true;
                continue;
            }
            
            if (inVfs && indent === 0 && !trimmed.startsWith('vfs:') && !trimmed.startsWith('#')) {
                inVfs = false;
            }
            
            if (!inVfs) continue;
            
            if (trimmed.startsWith('- name:') || trimmed.startsWith('name:')) {
                const name = trimmed.split(/name:\s*/)[1].trim();
                
                while (stack.length > 0 && stack[stack.length - 1].indent >= indent) {
                    stack.pop();
                }
                
                stack.push({ indent, name });
                const pathParts = stack.map(x => x.name);
                paths.push('/' + pathParts.join('/') + '/');
            }
        }
    } catch (_) {}
    return [...new Set(paths)];
}

exports.apiRequired  = 8.0;

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN CONFIGURATION
// ─────────────────────────────────────────────────────────────────────────────
exports.config = {
    quotas: {
        type:       'array',
        label:      'User Quotas & Folders',
        helperText: 'Associate username → VFS path → limit (MB) for each user.',
        fields: {
            username:  { type: 'string', required: true, label: 'Username' },
            vfsPath:   { type: 'select', required: true, label: 'VFS Path', options: getVfsPaths(), defaultValue: '/' },
            limitMB:   { type: 'number', required: true, label: 'Quota Limit (MB)', min: 1, defaultValue: 1000 }
        }
    },
    defaultLimitMB: {
        type:        'number',
        defaultValue: 100,
        label:       'Default Quota Limit (MB)',
        helperText:  'Fallback quota for users not listed above.'
    },
    cacheTTLSeconds: {
        type:        'number',
        defaultValue: 10,
        min:          2,
        max:          60,
        label:       'Quota Cache TTL (seconds)',
        helperText:  'How long to cache folder size scans. Lower = more accurate, higher = less I/O.'
    }
};

exports.configDialog = { sx: { maxWidth: '42em' } };

// ─────────────────────────────────────────────────────────────────────────────
//  RUNTIME STATE
// ─────────────────────────────────────────────────────────────────────────────

// Quota info cache — avoids repeated disk scans
// Format: { [username]: { limit, used, remaining, percentage, vfsPath, physicalPath, lastScanTime } }
const storageCache = {};

// Promise coalescing map — prevents simultaneous duplicate scans for the same user
// Format: { [username]: Promise<quotaInfo> }
const pendingScans = {};

// Pessimistic reservation map — "holds" bytes during an active upload
// Format: { [username]: number (bytes reserved) }
const pendingReservations = {};

// ─────────────────────────────────────────────────────────────────────────────
//  VFS PATH RESOLUTION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Resolves a VFS path to its physical disk path using the HFS VFS config.
 * Handles nested VFS nodes (e.g. /hfspcm/subdir/ even if only /hfspcm/ has a source).
 *
 * @param {string} vfsPath  Virtual path like '/hfspcm/reports/'
 * @param {object} vfsConfig  HFS VFS configuration root object
 * @returns {string|null}  Absolute Windows path or null
 */
function resolveVfsPath(vfsPath, vfsConfig) {
    if (!vfsPath || !vfsConfig) return null;

    const normPath = '/' + vfsPath.replace(/\\/g, '/').split('/').filter(Boolean).join('/');
    const parts    = normPath.split('/').filter(Boolean);
    let   current  = vfsConfig;

    for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (!current || !current.children) break;
        const child = current.children.find(c =>
            (c.name || '').toLowerCase() === part.toLowerCase()
        );
        if (child) {
            if (child.source) {
                // Found a physical mount point — append remaining path segments
                const remainder = parts.slice(i + 1);
                return remainder.length > 0
                    ? path.join(child.source, ...remainder)
                    : child.source;
            }
            current = child;
        } else {
            break;
        }
    }
    return null;
}

// ─────────────────────────────────────────────────────────────────────────────
//  FOLDER SIZE SCANNER (recursive)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Recursively sums file sizes in a directory.
 * @param {string} dirPath       Absolute path to scan
 * @param {string[]} [excludedPaths]  Normalized (lowercase, forward-slash) paths to skip
 * @returns {Promise<number>}  Total bytes
 */
async function getFolderSize(dirPath, excludedPaths) {
    let total = 0;
    try {
        const entries = await fs.promises.readdir(dirPath, { withFileTypes: true });
        const tasks   = entries.map(async entry => {
            const full = path.join(dirPath, entry.name);
            if (entry.isDirectory()) {
                // Skip sub-directories that are independently mounted VFS nodes
                // (e.g. a user's folder nested inside the admin's root folder)
                if (excludedPaths && excludedPaths.length > 0) {
                    const fullNorm = full.replace(/\\/g, '/').toLowerCase().replace(/\/$/, '');
                    if (excludedPaths.some(ep => fullNorm === ep || fullNorm.startsWith(ep + '/'))) {
                        return 0;
                    }
                }
                return getFolderSize(full, excludedPaths);
            } else if (entry.isFile()) {
                try {
                    const stat = await fs.promises.stat(full);
                    return stat.size;
                } catch (_) { return 0; }
            }
            return 0;
        });
        const sizes = await Promise.all(tasks);
        total = sizes.reduce((acc, s) => acc + s, 0);
    } catch (_) { /* directory may not exist yet */ }
    return total;
}

/**
 * Returns the list of physical paths that are VFS-mounted INSIDE `physicalPath`
 * but as independent nodes (i.e. another user's directory mounted as a child).
 * These must be excluded from the parent user's quota scan so quotas stay isolated.
 *
 * @param {string} physicalPath  Absolute physical path of the user being scanned
 * @param {object} api           HFS plugin API
 * @returns {string[]}           Array of normalized (lowercase, forward-slash) excluded paths
 */
function getExcludedSubPaths(physicalPath, api) {
    const excluded = [];
    try {
        const vfsConfig = api.getHfsConfig('vfs');
        if (!vfsConfig || !vfsConfig.children) return excluded;
        const myNorm = physicalPath.replace(/\\/g, '/').replace(/\/$/, '').toLowerCase();

        const scanVfsChildren = children => {
            for (const child of (children || [])) {
                if (child.source) {
                    const childNorm = child.source.replace(/\\/g, '/').replace(/\/$/, '').toLowerCase();
                    // Include only if it's a STRICT sub-path of ours (not equal)
                    if (childNorm !== myNorm && childNorm.startsWith(myNorm + '/')) {
                        excluded.push(childNorm);
                    }
                }
                // Recurse into nested VFS definitions
                if (child.children && child.children.length > 0) {
                    scanVfsChildren(child.children);
                }
            }
        };

        scanVfsChildren(vfsConfig.children);
    } catch (_) {}
    return excluded;
}

// ─────────────────────────────────────────────────────────────────────────────
//  QUOTA RESOLUTION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Gets quota info for a user. Uses:
 *   1. In-memory cache (if within TTL)
 *   2. Promise coalescing (if a scan is already running for this user)
 *   3. Fresh disk scan (otherwise)
 *
 * @param {string} username
 * @param {object} api  HFS plugin API
 * @returns {Promise<object>}  Quota details
 */
function getPluginConfigValue(api, key) {
    if (typeof api.getConfig === 'function') {
        const value = api.getConfig(key);
        if (value !== undefined) return value;
    }
    if (typeof api.getHfsConfig === 'function') {
        const directValue = api.getHfsConfig(`plugins.storage-monitor.${key}`);
        if (directValue !== undefined) return directValue;

        const legacyValue = api.getHfsConfig(`plugins_config.storage-monitor.${key}`);
        if (legacyValue !== undefined) return legacyValue;

        const pluginsConfig = api.getHfsConfig('plugins_config');
        if (pluginsConfig && pluginsConfig['storage-monitor'] && pluginsConfig['storage-monitor'][key] !== undefined) {
            return pluginsConfig['storage-monitor'][key];
        }
    }
    return undefined;
}

function setPluginConfigValue(api, key, value) {
    if (typeof api.setConfig === 'function') {
        api.setConfig(key, value);
    }
    if (typeof api.setHfsConfig === 'function') {
        api.setHfsConfig(`plugins.storage-monitor.${key}`, value);
        api.setHfsConfig(`plugins_config.storage-monitor.${key}`, value);
    }
}

/**
 * Dynamically resolves the VFS path assigned to a user by inspecting:
 *  1. accounts[username].redirect property in config.yaml (e.g. crl -> Family/, wnn -> BIBI Ayesha/)
 *  2. VFS tree permissions (can_read / can_upload / can_see)
 *  3. Fallback to /${username}/
 */
function resolveUserVfsPath(username, api) {
    if (!username) return null;
    const normUser = String(username).toLowerCase();

    try {
        const accounts = api.getHfsConfig('accounts') || {};
        const acc = accounts[username] || accounts[normUser];
        if (acc && acc.redirect) {
            const cleanRedir = '/' + acc.redirect.replace(/\\/g, '/').split('/').filter(Boolean).join('/') + '/';
            if (cleanRedir !== '/') return cleanRedir;
        }
    } catch (_) {}

    try {
        const vfsConfig = api.getHfsConfig('vfs');
        if (vfsConfig && vfsConfig.children) {
            const findVfsForUser = children => {
                for (const child of children) {
                    const canRead = (child.can_read || []).map(x => String(x).toLowerCase());
                    const canUpload = (child.can_upload || []).map(x => String(x).toLowerCase());
                    const canSee = (child.can_see || []).map(x => String(x).toLowerCase());
                    if (canRead.includes(normUser) || canUpload.includes(normUser) || canSee.includes(normUser)) {
                        return '/' + (child.name || '') + '/';
                    }
                    if (child.children && child.children.length > 0) {
                        const res = findVfsForUser(child.children);
                        if (res) return res;
                    }
                }
                return null;
            };
            const found = findVfsForUser(vfsConfig.children);
            if (found) return found;
        }
    } catch (_) {}

    return `/${username}/`;
}

async function getUserQuotaInfo(username, api) {
    if (!username) return { limit: 0, used: 0, remaining: 0, percentage: 0 };

    // Step 1: Return cached value if still fresh
    const cacheTTL = (getPluginConfigValue(api, 'cacheTTLSeconds') || 10) * 1000;
    const now      = Date.now();
    const cached   = storageCache[username];
    if (cached && (now - cached.lastScanTime < cacheTTL)) return cached;

    // Step 2: Coalesce — if a scan is already in progress for this user, await that same promise
    if (pendingScans[username]) return pendingScans[username];

    // Step 3: Launch a new scan
    pendingScans[username] = (async () => {
        try {
            const quotas = getPluginConfigValue(api, 'quotas') || [];
            const defaultLimitMB = getPluginConfigValue(api, 'defaultLimitMB') || 100;

            const userEntry  = quotas.find(q => (q.username || '').toLowerCase() === username.toLowerCase());
            const limitMB    = userEntry ? (userEntry.limitMB || userEntry.limit || defaultLimitMB) : defaultLimitMB;
            const limitBytes = limitMB * 1024 * 1024;
            const vfsPath    = userEntry ? userEntry.vfsPath : resolveUserVfsPath(username, api);

            const vfsConfig      = api.getHfsConfig('vfs');
            const physicalPath   = resolveVfsPath(vfsPath, vfsConfig);

            let usedBytes = 0;
            if (physicalPath && fs.existsSync(physicalPath)) {
                // Exclude any VFS sub-mounts that belong to other users so quotas
                // remain fully isolated (e.g. admin scan won't count user uploads).
                const excludedPaths = getExcludedSubPaths(physicalPath, api);
                usedBytes = await getFolderSize(physicalPath, excludedPaths);
            }

            const remainingBytes = Math.max(0, limitBytes - usedBytes);
            const percentage     = limitBytes > 0 ? (usedBytes / limitBytes) * 100 : 0;

            const info = {
                limit:        limitBytes,
                used:         usedBytes,
                remaining:    remainingBytes,
                percentage,
                vfsPath,
                physicalPath,
                lastScanTime: Date.now()
            };

            storageCache[username] = info;
            return info;
        } finally {
            delete pendingScans[username];
        }
    })();

    return pendingScans[username];
}

/**
 * Gets the effective remaining bytes for a user, accounting for pending reservations.
 * This prevents concurrent uploads from each seeing the same "full" quota.
 *
 * @param {string} username
 * @param {object} api
 * @returns {Promise<number>}  True remaining bytes (quota.remaining − pendingReservations)
 */
async function getEffectiveRemaining(username, api) {
    const info      = await getUserQuotaInfo(username, api);
    const reserved  = pendingReservations[username] || 0;
    return Math.max(0, info.remaining - reserved);
}

/**
 * Reserves bytes for an in-progress upload (pessimistic concurrency control).
 * Must be paired with releaseReservation() in all cases.
 */
function addReservation(username, bytes) {
    pendingReservations[username] = (pendingReservations[username] || 0) + bytes;
}

/**
 * Releases previously reserved bytes (called on upload success or failure).
 */
function releaseReservation(username, bytes) {
    const current = pendingReservations[username] || 0;
    const next    = current - bytes;
    if (next <= 0) {
        delete pendingReservations[username];
    } else {
        pendingReservations[username] = next;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  PLUGIN INITIALISATION
// ─────────────────────────────────────────────────────────────────────────────
exports.init = api => {
    api.log("[storage-monitor v2.0] Initializing...");

    return {
        frontend_js:  'main.js',
        frontend_css: 'style.css',

        // ── Cross-plugin API ──────────────────────────────────────────────────
        customApi: {
            async getQuotaInfo(username) {
                return await getUserQuotaInfo(username, api);
            }
        },

        // ── REST endpoints ────────────────────────────────────────────────────
        customRest: {

            /**
             * GET quota metrics for the currently logged-in user.
             */
            async getQuota(params, ctx) {
                const username = api.getCurrentUsername(ctx);
                return await getUserQuotaInfo(username, api);
            },

            /**
             * CHECK if a planned upload fits the remaining quota (with reservation awareness).
             */
            async checkUploadQuota({ size }, ctx) {
                const username = api.getCurrentUsername(ctx);
                if (!username) return { allowed: true };

                const effectiveRemaining = await getEffectiveRemaining(username, api);
                const allowed            = (size || 0) <= effectiveRemaining;

                return {
                    allowed,
                    remaining:  effectiveRemaining,
                    requested:  size || 0
                };
            },

            /**
             * LOG a client-detected quota violation (audit trail).
             */
            async logQuotaViolation({ size, remaining }, ctx) {
                const username = api.getCurrentUsername(ctx) || 'Guest';
                api.log(`[storage-monitor][SECURITY] Quota violation by '${username}'. Attempted: ${size} bytes, Remaining: ${remaining} bytes.`);

                try {
                    api.customApiCall('logAuditEvent', {
                        username,
                        ip:     ctx.ip,
                        action: 'Upload Quota Violation',
                        result: 'Blocked',
                        reason: `Client attempted ${size} bytes but only ${remaining} bytes remained.`
                    });
                } catch (_) {}

                return { logged: true };
            },

            /**
             * SET QUOTA — Admins can set storage quotas directly from the VFS view.
             */
            async setQuota({ vfsPath, username, limitMB }, ctx) {
                const currentUser = api.getCurrentUsername(ctx);
                if (currentUser !== 'admin') {
                    ctx.status = 403;
                    return { success: false, message: 'Only administrators can configure quotas.' };
                }

                if (!vfsPath || !username || isNaN(Number(limitMB))) {
                    return { success: false, message: 'Invalid quota parameters.' };
                }

                // Standardize path with trailing and leading slash
                let cleanPath = '/' + vfsPath.replace(/\\/g, '/').split('/').filter(Boolean).join('/');
                if (cleanPath !== '/') cleanPath += '/';

                const quotas = getPluginConfigValue(api, 'quotas') || [];
                const index = quotas.findIndex(q => 
                    (q.username || '').toLowerCase() === username.toLowerCase() && 
                    (q.vfsPath || '').toLowerCase() === cleanPath.toLowerCase()
                );
 
                if (index !== -1) {
                    quotas[index].limitMB = Number(limitMB);
                } else {
                    quotas.push({ username, vfsPath: cleanPath, limitMB: Number(limitMB) });
                }
 
                setPluginConfigValue(api, 'quotas', quotas);
                if (typeof api.saveConfig === 'function') {
                    await api.saveConfig();
                }

                // Clear cache so changes take effect immediately
                delete storageCache[username];

                return { success: true };
            },

            /**
             * ADMIN REPORT — returns quota usage for all configured users.
             * Only accessible by logged-in users (no guest access).
             */
            async getAdminQuotaReport(params, ctx) {
                const caller = api.getCurrentUsername(ctx);
                if (!caller) {
                    ctx.status = 401;
                    return { error: 'Unauthorized' };
                }

                const quotas  = getPluginConfigValue(api, 'quotas') || [];
                const report  = [];

                for (const entry of quotas) {
                    try {
                        const info = await getUserQuotaInfo(entry.username, api);
                        report.push({
                            username:   entry.username,
                            vfsPath:    info.vfsPath,
                            limitMB:    (info.limit    / 1048576).toFixed(2),
                            usedMB:     (info.used     / 1048576).toFixed(2),
                            remainingMB:(info.remaining / 1048576).toFixed(2),
                            percentage: info.percentage.toFixed(1),
                            reserved:   ((pendingReservations[entry.username] || 0) / 1048576).toFixed(2)
                        });
                    } catch (_) {}
                }

                return { report, generatedAt: new Date().toISOString() };
            }
        },

        // ── Koa Middleware ────────────────────────────────────────────────────
        middleware: ctx => {
            return (async () => {
                const contentType    = (ctx.headers['content-type'] || '').toLowerCase();
                const isMultipart    = contentType.startsWith('multipart/form-data');
                const isOctetStream  = contentType.startsWith('application/octet-stream');
                const isPut          = ctx.method === 'PUT' && !ctx.path.startsWith('/~/');
                const isPost         = ctx.method === 'POST';

                const isUpload = (isPost && isMultipart) || isPut || (isPost && isOctetStream);

                if (!isUpload) {
                    // Upstream only: invalidate quota cache on any successful write
                    return () => {
                        if (ctx.status < 300) {
                            const username = api.getCurrentUsername(ctx);
                            if (username && (ctx.method === 'POST' || ctx.method === 'PUT' || ctx.method === 'DELETE')) {
                                delete storageCache[username];
                            }
                        }
                    };
                }

                // ── DOWNSTREAM: Block uploads that exceed quota ───────────────
                const username      = api.getCurrentUsername(ctx) || '';
                const contentLength = parseInt(ctx.headers['content-length'] || '0', 10);

                if (username && contentLength > 0) {
                    const quotaInfo = await getUserQuotaInfo(username, api);

                    if (quotaInfo && quotaInfo.limit > 0) {
                        const effectiveRemaining = Math.max(0, quotaInfo.remaining - (pendingReservations[username] || 0));

                        if (contentLength > effectiveRemaining) {
                            ctx.status = 413; // Payload Too Large
                            ctx.body   = {
                                error:     'Upload Blocked',
                                reason:    'File size exceeds remaining upload storage size',
                                remaining: effectiveRemaining,
                                requested: contentLength
                            };

                            try {
                                api.customApiCall('logAuditEvent', {
                                    username,
                                    ip:     ctx.ip,
                                    action: 'Upload Blocked',
                                    result: 'Rejected',
                                    reason: `Upload of ${contentLength} bytes blocked. Effective remaining: ${effectiveRemaining} bytes.`
                                });
                            } catch (_) {}

                            api.log(`[storage-monitor][SECURITY] Blocked upload from '${username}'. Size: ${contentLength}, Remaining: ${effectiveRemaining}.`);
                            ctx.stop();
                            return;
                        }

                        // Reserve bytes for this upload
                        addReservation(username, contentLength);

                        // ── UPSTREAM: Release reservation and invalidate cache ─
                        return () => {
                            releaseReservation(username, contentLength);
                            if (ctx.status < 300) {
                                // Successful write — bust the cache immediately
                                delete storageCache[username];
                                api.log(`[storage-monitor] Upload success for '${username}'. Cache invalidated. Uploaded: ${contentLength} bytes.`);
                            }
                        };
                    }
                }

                // No quota config for this user — upstream cache invalidation only
                return () => {
                    if (ctx.status < 300) {
                        const u = api.getCurrentUsername(ctx);
                        if (u) delete storageCache[u];
                    }
                };
            })();
        }
    };
};
